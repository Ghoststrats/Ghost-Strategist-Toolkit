#!/usr/bin/env bash
set -euo pipefail
if (( EUID == 0 )); then echo 'Run as your normal desktop user, not sudo.' >&2; exit 1; fi
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}"
APP_DIR="$DATA_DIR/ghoststrats-toolkit"
BIN_FILE="$HOME/.local/bin/ghoststrats-toolkit"
DESKTOP_FILE="$DATA_DIR/applications/ghoststrats-toolkit.desktop"
if [[ "${1:-}" != '--yes' ]]; then
  echo 'Uninstall GhostStrats Toolkit for this user? [y/N]'
  read -r confirm || true
  [[ "$confirm" == 'y' || "$confirm" == 'Y' ]] || { echo 'Cancelled.'; exit 0; }
fi
rm -f -- "$BIN_FILE" "$DESKTOP_FILE"
rm -rf -- "$APP_DIR"
echo 'GhostStrats Toolkit removed from this user account.'
echo 'User-created logs and external dependency packages were left untouched.'
