#!/usr/bin/env python3
"""GS BugOut: bounded, opt-in user session cleanup followed by normal poweroff.
No blanket process kill, /tmp wipe, browser-profile erase or secure-wipe claim.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from gs_brand import print_gs as print

APPS = {'firefox','firefox-bin','chrome','chromium','chromium-browser',
        'brave','brave-browser','librewolf','thunderbird','vlc','spotify',
        'discord','steam','gimp','xed','mousepad','kate','gedit','soffice.bin',
        'libreoffice','evince','atril','celluloid','eog','ristretto',
        'obs','obs-studio','code','codium'}
USER_SERVICES = {'syncthing.service','dropbox.service','nextcloud-client.service',
                 'onedrive.service','megasync.service'}
PURPLE='\033[38;5;141m'; GRAY='\033[38;5;245m'; RED='\033[91m'; RESET='\033[0m'

def label(stage, kind, message):
    color = RED if kind in ('ERROR','WARNING') else GRAY
    color = color if sys.stdout.isatty() and not os.environ.get('NO_COLOR') else ''
    print(f'{color}  [{stage}] {kind}: {message}{RESET if color else ""}')

def cmd(args, timeout=7, input_data=None):
    try:
        return subprocess.run(args, input=input_data, text=True, capture_output=True,
                              check=False, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return None

def parent_pids():
    result={os.getpid()}; pid=os.getpid()
    while pid > 1:
        try:
            data=Path(f'/proc/{pid}/status').read_text(errors='replace')
            ppid=int(next(s for s in data.splitlines() if s.startswith('PPid:')).split()[1])
        except (OSError, ValueError, StopIteration):
            break
        if ppid <= 0 or ppid in result: break
        result.add(ppid); pid=ppid
    return result

def running_apps():
    safe=parent_pids(); found=[]
    try: entries=list(Path('/proc').iterdir())
    except OSError: return found
    for path in entries:
        if not path.name.isdecimal() or int(path.name) in safe: continue
        try:
            status=(path/'status').read_text(errors='replace')
            uid=int(next(s for s in status.splitlines() if s.startswith('Uid:')).split()[1])
            name=(path/'comm').read_text(errors='replace').strip().lower()
            if uid==os.getuid() and name in APPS:
                found.append((int(path.name), name))
        except (OSError,ValueError,StopIteration): continue
    return sorted(found)

def close_applications(preview):
    apps=running_apps(); count=0
    if preview:
        label('1/8','PREVIEW',f'Graceful SIGTERM for {len(apps)} recognized user applications')
        for pid,name in apps[:12]: label('1/8','INFO',f'{name} (PID {pid})')
    else:
        for pid,name in apps:
            try:
                current=Path(f'/proc/{pid}')
                status=(current/'status').read_text()
                uid=int(next(s for s in status.splitlines() if s.startswith('Uid:')).split()[1])
                if uid==os.getuid() and (current/'comm').read_text().strip().lower()==name:
                    os.kill(pid,signal.SIGTERM); count+=1
            except (OSError, ValueError, StopIteration): pass
        label('1/8','DONE',f'Asked {count} user apps to close; no forced kill')
    if not shutil.which('systemctl'):
        label('1/8','SKIPPED','User-service manager unavailable'); return
    r=cmd(['systemctl','--user','list-units','--type=service','--state=running',
           '--no-legend','--no-pager'],timeout=5)
    if r is None or r.returncode: return
    services=sorted({line.split()[0] for line in r.stdout.splitlines() if line.split()
                     and line.split()[0] in USER_SERVICES})
    for unit in services:
        if preview: label('1/8','PREVIEW',f'Would stop optional user service {unit}')
        else:
            stopped=cmd(['systemctl','--user','stop',unit],timeout=6)
            label('1/8','DONE' if stopped and stopped.returncode==0 else 'WARNING',
                  f'User service {unit}: stop requested')

def selected_cache_dirs(home, cache):
    dirs=[cache/'thumbnails',home/'.thumbnails',cache/'fontconfig',
          cache/'mesa_shader_cache',cache/'gs-bugout']
    for prefix in ('mozilla/firefox','chromium','google-chrome','BraveSoftware/Brave-Browser'):
        base=cache/prefix
        if base.is_symlink() or not base.is_dir(): continue
        try: profiles=list(base.iterdir())
        except OSError: continue
        for profile in profiles:
            if profile.is_symlink() or not profile.is_dir(): continue
            dirs.append(profile/('cache2' if prefix=='mozilla/firefox' else 'Cache'))
    return dirs

def safe_cache_root(folder, home, cache):
    try:
        if not folder.is_dir() or folder.is_symlink() or cache.is_symlink(): return False
        h=home.resolve(strict=True); c=cache.resolve(strict=True)
        p=folder.resolve(strict=True)
        return c.is_relative_to(h) and p.is_relative_to(h) and (
            p.is_relative_to(c) or p == h/'.thumbnails')
    except (OSError,RuntimeError,ValueError): return False

def cache_cleanup(preview, home=None, cache=None):
    home=Path(home or Path.home()); cache=Path(cache or os.environ.get('XDG_CACHE_HOME',home/'.cache'))
    if not home.is_dir(): return
    files=errors=folders=0
    for root in set(selected_cache_dirs(home,cache)):
        if not safe_cache_root(root,home,cache): continue
        folders+=1
        # Bound work and do not follow symlinks. Do not remove the cache directories.
        for current,dirs,names in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if not (Path(current)/d).is_symlink()]
            for name in names:
                if files+errors>=10000: errors+=1; break
                path=Path(current)/name
                try:
                    info=path.lstat()
                    if info.st_uid!=os.getuid() or path.is_symlink() or not path.is_file(): continue
                    if not preview: path.unlink()
                    files+=1
                except OSError: errors+=1
    label('3/8','PREVIEW' if preview else 'DONE',
          f'{files} files in {folders} approved cache folders; {errors} errors. Profiles/history/cookies kept')

def temp_cleanup(preview):
    # Generic /tmp contents may belong to other running apps. Never bulk erase it.
    count=0
    for p in Path('/tmp').glob(f'gs-bugout-{os.getuid()}-*'):
        try:
            if p.is_file() and not p.is_symlink() and p.stat().st_uid==os.getuid():
                if not preview: p.unlink()
                count+=1
        except OSError: pass
    label('2/8','PREVIEW' if preview else 'DONE',
          f'{count} BugOut-owned /tmp files; other /tmp content remains untouched')

def clipboard_clear(preview):
    if os.environ.get('WAYLAND_DISPLAY') and shutil.which('wl-copy'):
        cmdline=['wl-copy','--clear']; stdin=None
    elif os.environ.get('DISPLAY') and shutil.which('xclip'):
        cmdline=['xclip','-selection','clipboard']; stdin=''
    elif os.environ.get('DISPLAY') and shutil.which('xsel'):
        cmdline=['xsel','--clipboard','--clear']; stdin=None
    else:
        label('4/8','SKIPPED','No existing compatible clipboard tool'); return
    if preview: label('4/8','PREVIEW',f'Would clear clipboard with {cmdline[0]}'); return
    r=cmd(cmdline,timeout=4,input_data=stdin)
    label('4/8','DONE' if r and r.returncode==0 else 'WARNING',
          'Clipboard clear attempted; clipboard managers may retain copies')

def network_off(preview):
    for command,description in [(['nmcli','networking','off'],'NetworkManager connections'),
                                (['nmcli','radio','wifi','off'],'Wi-Fi'),
                                (['nmcli','radio','wwan','off'],'mobile broadband'),
                                (['rfkill','block','all'],'software radios')]:
        if not shutil.which(command[0]):
            label('5/8','SKIPPED',f'{description}: {command[0]} unavailable'); continue
        if preview: label('5/8','PREVIEW',f'Would disable {description}'); continue
        r=cmd(command)
        label('5/8','DONE' if r and r.returncode==0 else 'WARNING',
              f'{description}: {"command succeeded" if r and r.returncode==0 else "not confirmed"}')

def removable_disks():
    if not shutil.which('lsblk'): return []
    r=cmd(['lsblk','-J','-o','PATH,TYPE,TRAN,RM,MOUNTPOINTS'],timeout=5)
    if not r or r.returncode: return []
    try: devices=json.loads(r.stdout).get('blockdevices',[])
    except (ValueError,AttributeError,TypeError): return []
    user=os.environ.get('USER','')
    if not user: return []
    roots=(f'/media/{user}/',f'/run/media/{user}/')
    toolkit=Path(__file__).resolve(); found=[]
    def inspect(device, upstream=False):
        removable=upstream or device.get('tran')=='usb' or device.get('rm') in (True,'1',1)
        mounts=device.get('mountpoints') or []
        if isinstance(mounts,str): mounts=[mounts]
        for path in mounts:
            if not path or not any(str(path).startswith(prefix) for prefix in roots): continue
            try:
                mounted=Path(path).resolve()
                if removable and device.get('path') and not toolkit.is_relative_to(mounted):
                    found.append((device['path'],str(mounted)))
            except (OSError,ValueError): continue
        for child in device.get('children',[]) or []: inspect(child,removable)
    for device in devices: inspect(device)
    return found

def unmount_usb(preview):
    candidates=removable_disks()
    if not candidates: label('6/8','SKIPPED','No eligible removable USB mounts; toolkit USB protected'); return
    if not preview and shutil.which('sync'): cmd(['sync'],timeout=8)
    for device,mount in candidates:
        if preview: label('6/8','PREVIEW',f'Would attempt unmount {mount}')
        elif shutil.which('udisksctl'):
            r=cmd(['udisksctl','unmount','-b',device,'--no-user-interaction'],timeout=8)
            label('6/8','DONE' if r and r.returncode==0 else 'WARNING',
                  f'{mount}: {"unmounted" if r and r.returncode==0 else "still mounted"}')
        else: label('6/8','SKIPPED',f'{mount}: no existing udisksctl (never force unmount)')

def poweroff(preview):
    if preview: label('8/8','PREVIEW','Would request normal systemctl poweroff'); return True
    r=cmd(['systemctl','poweroff'],timeout=10) if shutil.which('systemctl') else None
    if r and r.returncode==0:
        label('8/8','DONE','systemd accepted the poweroff request'); return True
    label('8/8','ERROR','Shutdown refused/unavailable. Earlier steps may have changed settings.'); return False

def preview():
    print('\nGS BUGOUT — READ-ONLY PREVIEW\n  No settings, tasks, files or power state are changed.')
    for f in (close_applications,temp_cleanup,cache_cleanup,clipboard_clear,network_off,unmount_usb):
        try: f(True)
        except (OSError,ValueError) as exc: label('PREVIEW','WARNING',f'{f.__name__}: {exc}')
    label('7/8','PREVIEW','systemd handles remaining user sessions and system services during shutdown')
    poweroff(True)

def execute():
    if os.environ.get('GHOSTSTRAT_TEST_MODE')=='1':
        print('GS BugOut TEST MODE: no shutdown or cleanup; preview only.'); preview(); return 0
    if os.geteuid()==0: label('SAFETY','ERROR','Run as regular user, not root'); return 2
    if os.environ.get('SSH_TTY') or os.environ.get('SSH_CONNECTION'):
        label('SAFETY','ERROR','Use a local terminal, not an SSH session'); return 2
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        label('SAFETY','ERROR','An interactive local terminal is required'); return 2
    if not shutil.which('systemctl'):
        label('SAFETY','ERROR','systemctl unavailable; no cleanup begun'); return 2
    print('\nGS BUGOUT — FULL SESSION EXIT')
    print('WARNING: UNSAVED WORK MAY BE LOST. CACHE DELETIONS CANNOT BE UNDONE.')
    print('Networking/radios may remain disabled after reboot. USBs may unmount.')
    try: answer=input('  Type BUGOUT to confirm full cleanup + shutdown: ').strip()
    except (EOFError,KeyboardInterrupt): return 10
    if answer!='BUGOUT': label('SAFETY','SKIPPED','Cancelled; no changes'); return 10
    print('  Ctrl+C during the three-second countdown cancels BEFORE changes begin.')
    try:
        for seconds in (3,2,1):
            print(f'  GS BugOut begins in {seconds}...',flush=True)
            time.sleep(1)
    except KeyboardInterrupt:
        label('SAFETY','SKIPPED','Cancelled during countdown. Nothing changed.'); return 130
    print('\n  GS BUGOUT ACTIVE — CLEANUP THEN POWER OFF')
    for f in (close_applications,temp_cleanup,cache_cleanup,clipboard_clear,network_off,unmount_usb):
        try: f(False)
        except Exception as exc:
            label('STAGE','WARNING',f'{f.__name__} incomplete: {type(exc).__name__}')
    label('7/8','INFO','Normal systemd poweroff will stop remaining users/system tasks')
    return 0 if poweroff(False) else 1

def main():
    parser=argparse.ArgumentParser(description='GS BugOut full session exit')
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preview',action='store_true',help='Read-only preview')
    mode.add_argument('--execute',action='store_true',help='Confirm, countdown and shutdown')
    args=parser.parse_args()
    if args.preview:
        preview()
        return 0
    return execute()

if __name__=='__main__':
    try: raise SystemExit(main())
    except KeyboardInterrupt:
        print('GS BugOut interrupted. Previous stages, if any, cannot be undone.')
        raise SystemExit(130)
