#!/usr/bin/env python3
"""GhostStrats Snake: local, standard-library-only terminal Easter egg.

Only terminal state is changed. Collisions immediately return to the caller.
No score files, network calls, package installations, or system changes.
"""

from collections import deque
import random
import sys
import time


class SnakeGame:
    """Game rules separated from curses for deterministic safety tests."""

    VECTORS = {'UP': (0, -1), 'DOWN': (0, 1),
               'LEFT': (-1, 0), 'RIGHT': (1, 0)}

    def __init__(self, width=36, height=15, *, rng=None):
        if width < 8 or height < 6:
            raise ValueError('Snake board too small')
        self.width = width
        self.height = height
        mid = (width // 2, height // 2)
        self.snake = deque((mid, (mid[0] - 1, mid[1]), (mid[0] - 2, mid[1])))
        self.direction = 'RIGHT'
        self.turned = False
        self.score = 0
        self.finished = False
        self.rng = rng or random.Random()
        self.food = self._next_food()

    def _next_food(self):
        occupied = set(self.snake)
        available = [(x, y) for y in range(self.height)
                     for x in range(self.width) if (x, y) not in occupied]
        return self.rng.choice(available) if available else None

    def turn(self, direction):
        if direction not in self.VECTORS or self.turned or self.finished:
            return False
        dx, dy = self.VECTORS[direction]
        odx, ody = self.VECTORS[self.direction]
        if dx == -odx and dy == -ody:
            return False
        self.direction = direction
        self.turned = True
        return True

    def step(self):
        """Return 'alive', 'crash', or 'win'; crash needs no extra input."""
        if self.finished:
            return 'crash'
        dx, dy = self.VECTORS[self.direction]
        x, y = self.snake[0]
        head = (x + dx, y + dy)
        self.turned = False
        if not (0 <= head[0] < self.width and 0 <= head[1] < self.height):
            self.finished = True
            return 'crash'
        grow = head == self.food
        # Moving into the departing tail is legal if we are not growing.
        body = set(self.snake if grow else list(self.snake)[:-1])
        if head in body:
            self.finished = True
            return 'crash'
        self.snake.appendleft(head)
        if grow:
            self.score += 1
            self.food = self._next_food()
            if self.food is None:
                self.finished = True
                return 'win'
        else:
            self.snake.pop()
        return 'alive'


def _run_curses(screen):
    """Runs Snake in the active terminal; wrapper restores terminal modes."""
    import curses
    curses.curs_set(0)
    screen.keypad(True)
    screen.timeout(45)
    rows, cols = screen.getmaxyx()
    width = min(48, cols - 4)
    height = min(17, rows - 7)
    if width < 12 or height < 8:
        # Too small for a safely playable game: just return to main menu.
        return 'small-terminal'
    left = (cols - width - 2) // 2
    top = 2
    game = SnakeGame(width, height)
    colors = False
    try:
        if curses.has_colors():
            curses.start_color()
            curses.use_default_colors()
            curses.init_pair(1, curses.COLOR_MAGENTA, -1)
            curses.init_pair(2, curses.COLOR_GREEN, -1)
            curses.init_pair(3, curses.COLOR_RED, -1)
            colors = True
    except curses.error:
        pass

    def draw():
        screen.erase()
        title = 'GS SNAKE  |  GHOSTSTRATS HIDDEN GAME'
        screen.addnstr(0, max(0, (cols - len(title)) // 2), title, cols - 1,
                       curses.color_pair(1) | curses.A_BOLD if colors else curses.A_BOLD)
        sub = f'SCORE: {game.score}   ARROWS/WASD MOVE   Q/ESC EXIT'
        screen.addnstr(1, max(0, (cols - len(sub)) // 2), sub, cols - 1)
        # Bounded frame; no writes to the bottom-right terminal cell.
        screen.addstr(top, left, '+' + '-' * width + '+')
        for y in range(height):
            screen.addch(top + 1 + y, left, ord('|'))
            screen.addch(top + 1 + y, left + width + 1, ord('|'))
        screen.addstr(top + height + 1, left, '+' + '-' * width + '+')
        if game.food:
            fx, fy = game.food
            screen.addch(top + 1 + fy, left + 1 + fx, ord('*'),
                         curses.color_pair(3) | curses.A_BOLD if colors else curses.A_BOLD)
        for index, (x, y) in enumerate(game.snake):
            screen.addch(top + 1 + y, left + 1 + x,
                         ord('@' if index == 0 else 'o'),
                         curses.color_pair(2) | curses.A_BOLD if colors else curses.A_BOLD)
        footer = 'CRASH = IMMEDIATE RETURN TO MAIN MENU'
        if top + height + 3 < rows:
            screen.addnstr(top + height + 3, max(0, (cols - len(footer)) // 2),
                           footer, cols - 1)
        screen.refresh()

    keys = {
        curses.KEY_UP: 'UP', curses.KEY_DOWN: 'DOWN',
        curses.KEY_LEFT: 'LEFT', curses.KEY_RIGHT: 'RIGHT',
        ord('w'): 'UP', ord('s'): 'DOWN', ord('a'): 'LEFT', ord('d'): 'RIGHT',
        ord('W'): 'UP', ord('S'): 'DOWN', ord('A'): 'LEFT', ord('D'): 'RIGHT',
    }
    next_step = time.monotonic() + 0.18
    draw()
    while True:
        pressed = screen.getch()
        if pressed in (ord('q'), ord('Q'), 27):
            return 'quit'
        if pressed == curses.KEY_RESIZE:
            # Avoid incorrectly drawing off screen after resize; return safely.
            return 'resized'
        if pressed in keys:
            game.turn(keys[pressed])
        if time.monotonic() >= next_step:
            result = game.step()
            if result != 'alive':
                return result  # NO game-over prompt; return directly to menu.
            next_step = time.monotonic() + max(0.075, 0.18 - game.score * 0.004)
            draw()


def play():
    """Return after collision or quit; fail safely if interactive curses is absent."""
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return 'not-a-terminal'
    try:
        import curses  # Provided by standard Linux Python; no pip needed.
        return curses.wrapper(_run_curses)
    except Exception as exc:
        # A broken/unsupported TERM must never crash the parent toolkit.
        # KeyboardInterrupt is deliberately not caught here.
        print(f'GS Snake unavailable in this terminal ({type(exc).__name__}).')
        return 'unavailable'
