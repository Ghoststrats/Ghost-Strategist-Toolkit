# Ghost Strategist Toolkit

## V81 — GS Drone Detector: BLE always enabled in Turbo

Turbo now automatically attempts passive BLE drone detection alongside Wi-Fi. The old `--no-ble` and `--ble-only` command-line switches are removed. Nothing automatically disables or enables the Bluetooth radio; if the driver or Bleak dependency is unavailable, the scanner reports **BLE unavailable** and continues its Wi-Fi drone scan. Esc still stops scanning and returns to the main toolkit menu.


**Privacy Is an Illusion. Awareness Is a Choice.**

*A practical Linux terminal toolkit featuring GS Drone Detector, privacy controls, network and system inspection, and wireless awareness.*

**Current release: V81 · Linux Toolkit · Linux Mint / Kali Linux / Parrot OS / Tails restricted mode · Educational use only**

### V80 — GS Drone Detector: Turbo-only, one-key exit

**[6] GS Drone Detector immediately starts one continuous TURBO scan.** There is **no longer a detector submenu** and no pairing/connection option. The scanner listens for supported drone clues via nearby Wi-Fi network identifiers and Bluetooth Low Energy advertisements (if optional hardware/software are present). Supported Open Drone ID messages may be decoded when received through compatible hardware.

- **Esc** stops the scan, closes its active Wi-Fi scan subprocess, releases BLE listening, restores the terminal, and returns straight to the **toolkit main menu**, without pressing Enter.
- **Ctrl+C** is also supported for a manual stop.
- Turbo requests Wi-Fi rescans every **3 seconds**, refreshes the dashboard every **0.15 seconds**, and uses **0.5-second channel dwell** with an explicitly configured monitor-mode adapter. Adapter/driver limitations still apply.
- Drone-only candidate filtering, Remote ID decoding, visual alerts and green/yellow/red signal bars remain. A strong signal does not prove the drone is close or approaching.
- No auto-pairing, jamming, flight controls, or unrelated-device alerts.

Run the toolkit with `ghoststrats-toolkit` and choose **[6]**, or launch the standalone detector with `bash gs-drone-detector.sh`. For offline testing only, use `bash gs-drone-detector.sh test`.

### Historical release notes (earlier interfaces)

### V79 — Reliable menus and keyboard recovery

The home menu no longer uses a separate raw-keyboard loop or periodically moves
its cursor to repaint the NullOut status. Its screen remains **static while you
type**. All toolkit-owned menu prompts now use a single input reader, and the
60-second GS NullOut watchdog continues running through its timed input checks.

This fixes a known cause of **flashing, blanking, looping menus, and lost number
keys after returning from other tools**, especially on small terminals and
remote console emulators. Empty Enter and bare Esc on the home screen no longer
force another full-screen redraw. The home screen displays the NullOut timer as
a status snapshot until the next real navigation event.

If your current terminal was damaged by an older build, exit with Ctrl+C and
run `stty sane` in the shell if keyboard echo is still missing. If screen output
was paused using Ctrl+S, use Ctrl+Q to resume it. The V79 change does not alter
device controls, network settings, or drone detection behavior. It passed
**204 automated tests** and repeated pseudo-terminal navigation in a separate
non-root test session; actual user desktop tests are still recommended.

### V78 — Drone-only BLE awareness and optional owned-device pairing

GS Drone Detector now **filters out RC cars and unrelated Wi-Fi/Bluetooth devices** from its match dashboard, alerts and device history. A dedicated **[10] BLE DRONE SCAN** continuously listens for drone-related BLE advertisements and supported Remote ID 0xFFFA service data, applying the same red/yellow/green signal warnings. **[11] Pair/connect my OWN BLE drone** is a separate, opt-in BlueZ helper requiring the chosen address and an explicit ownership confirmation. Pairing is not needed for detection, is not universally supported, and does not provide drone controls.

### V77 — Faster Drone Detector live scans

GS Drone Detector **[6]** now offers three real-time scanning profiles: **FAST** (menu [1], active Wi-Fi scan requests every 5 seconds, 0.75-second channel dwell, ~0.25-second screen refresh), **BALANCED** (menu [8], 12-second Wi-Fi scans and 3-second dwell) and **TURBO** (menu [9], Wi-Fi scan requests every 3 seconds, 0.5-second dwell and ~0.15-second screen refresh). BLE scanning listens continuously when Bleak is available. Packet-queue limits and beacon deduplication reduce UI delays under heavy radio traffic.

**Scan rate is a request, not an actual guaranteed rate.** NetworkManager, Wi-Fi drivers and connected-adapter scanning restrictions may throttle or delay requests. Frequent Wi-Fi rescans may disrupt a Wi-Fi connection or drain batteries. A spare monitor-capable adapter is recommended for raw beacon capture. Faster channel hopping can also miss short transmissions; use one specified channel for best sensitivity to a known transmitter. The detector does not find every drone or calculate actual drone distance from RSSI.

### V76 — Drone Detector signal warning colors

GS Drone Detector [6] now provides green, yellow and red strength indicators, plus an explicit **"possibly close"** red warning at peak strength. Demonstration mode shows all three levels. Strength alone cannot establish drone distance, approach speed, or danger.

### V75 — Stable menu input and terminal recovery

This maintenance release corrects a bug where keystrokes might stop registering or appear blank after returning from some live views. Live Task Manager and hidden-screen readers now use unbuffered TTY input; the toolkit also remembers and restores normal terminal input/echo settings after menu actions and external tools finish (including failed or interrupted actions). Existing menu numbering [1–19] is unchanged.

If an **older V74 terminal** is stuck, press **Ctrl+C** to exit, then run `stty sane` in the shell if typed commands are still invisible. Relaunch **V80**. This repair does not force an active external scan to end; use its own exit command or Ctrl+C first.


GhostStrats Toolkit brings system information, network discovery, device controls, privacy checks, file inspection, a drone-detection experiment, and carefully explained lockdown tools into one black-and-purple command center. Instead of memorizing dozens of Linux commands, choose an option, read what it does, and decide whether to run it.

**This is not an operating system, antivirus, anonymity guarantee, secure-wipe solution, or replacement for professional security monitoring.** It is a learning and troubleshooting toolkit. Some actions can disconnect devices, close applications, change firewall rules, delete certain caches, or shut down your computer. Read the on-screen explanations and save your work before using those options.

> **A message from GhostStrats:** Safety is an illusion. That doesn't mean giving up. It means learning how your systems work, understanding their limits, and taking responsibility for what you can control.

## Contents

- [Linux compatibility](#linux-compatibility)
- [Quick start](#quick-start)
- [Main menu](#main-menu)
- [1–6: GhostStrats Tools](#ghoststrats-tools-1-6)
- [7–10: Discovery & Scanning](#discovery--scanning-7-10)
- [11–15: Device & Access Control](#device--access-control-11-15)
- [16–19: System & Utilities](#system--utilities-16-19)
- [Help, keyboard controls and Easter eggs](#help-keyboard-controls-and-easter-eggs)
- [Dependencies and compatibility](#dependencies-and-compatibility)
- [Testing and limitations](#testing-and-limitations)
- [Project structure](#project-structure)
- [Safety, privacy and responsible use](#safety-privacy-and-responsible-use)

## Linux compatibility

GhostStrats Toolkit is a **Linux toolkit**. V80 selects an installation and runtime profile based on `/etc/os-release` and (on Tails) the Tails version marker. Distribution detection is not proof that optional system utilities are available.

| Linux system | Installer | What to expect |
| --- | --- | --- |
| **Linux Mint** | Install & Run ZIP or `.deb` | Primary development system; hardware-specific actions still need validation. |
| **Kali Linux** | Install & Run ZIP or `.deb` | Interactive terminal and most modules; controls require installed services and hardware support. |
| **Parrot OS** | Install & Run ZIP or `.deb` | Interactive terminal and most modules; Wayland/X11 differences apply. |
| **Tails** | **Per-user Install & Run ZIP only** | Restricted session: inspection tools only. Firewall, device/radio changes, shutdown, DHCP, drone capture and active scanning are blocked in the toolkit menu. Normally does **not** survive reboot. |
| Other Linux distributions | Experimental per-user install | Requires Bash and Python 3; some commands/features may be absent. |

**Tails permitted main-menu options:** `[3] GS Threat Analysis`, `[5] GS Network Intelligence`, `[9] File Explorer`, `[13] MAC Address Inspector` (Wi-Fi AP scan blocked), `[16] Startup & Privacy Audit`, `[18] System Overview`, and `[H] Help`. The other options appear disabled and cannot be selected through the menu. **This restriction is a convenience/safety guard, not a sandbox.** Running bundled scripts directly would bypass menu guards. The toolkit does not change or override Tails' networking rules, nor does it certify anonymity. On Tails, any writes to nonpersistent storage are normally erased on shutdown; deliberately placing toolkit files in Persistent Storage would change that.

**Wayland:** Recent Parrot KDE and some Kali sessions use Wayland. GS NullOut's X11 idle listener cannot run under Wayland. It refuses to arm there. Use an X11 session for this specific feature, after checking availability of X11 screensaver libraries. All other functions depend on the corresponding local hardware and utilities, not on the distribution name alone.

## Quick start

Use your **normal desktop user account**, not sudo/root, from an interactive Linux terminal. The installer does not require administrator rights, connect to the internet, or automatically install third-party packages.

### Option A — Install & Run (recommended)

1. Download the latest release ZIP and **extract the complete folder**. Do not run a single script directly from inside the ZIP.
2. Open a terminal in the extracted `Ghost-Strategist-Toolkit` directory.
3. Run:

```bash
./Install-and-Run.sh
```

**Check your system first without installing:**

```bash
./Install-and-Run.sh --check
```

**Install and start automatically:** `./Install-and-Run.sh` (requires an interactive terminal).

This is a **per-user installation**: it copies the toolkit into `~/.local/share/ghoststrats-toolkit`, creates the command `~/.local/bin/ghoststrats-toolkit`, adds a *GhostStrats Toolkit* applications-menu launcher, and launches the toolkit. **No sudo is needed for installation.** Installing does not activate BlackOut, NullOut, scanners, or other system-changing functions.

After installation, open **GhostStrats Toolkit** from the Linux applications menu, or run:

```bash
ghoststrats-toolkit
```

If your shell doesn't find the command yet, run `~/.local/bin/ghoststrats-toolkit` or reopen your terminal.

**Install without launching:** `./Install-and-Run.sh --install-only`  
**Uninstall this per-user copy:** `./Uninstall-GhostStrats.sh`

### Option B — Portable (no installation)

```bash
./Run-Portable.sh
```

Or launch directly using Bash:

```bash
bash gs.sh
```

Keep all the accompanying `.py` and `.sh` files in the same extracted folder. The toolkit needs Python 3 and Bash; optional features require the commands or libraries described below.

### Option C — Debian `.deb` package (Mint / Kali / Parrot)

For Mint, Kali and Parrot, the **V80 `.deb` package** is a second installation choice. It installs the toolkit for all local users and requires package-manager administration rights. It does **not** run the program automatically, change firewall settings or install optional scanner dependencies.

```bash
sudo apt install ./ghoststrats-toolkit_8.0.0_all.deb
ghoststrats-toolkit
```

To uninstall that system package: `sudo apt remove ghoststrats-toolkit`.

**Do not install the `.deb` on Tails.** Use the per-user script instead. Also, don't mix the system `.deb` with the per-user installer unless you know which `ghoststrats-toolkit` command your shell launches.

> **Important:** Run the toolkit as a regular user, **not** using `sudo`. Individual privileged actions ask for authorization if they need it. **Do not launch BlackOut, remote-access lockdown, firewall changes, or BugOut from SSH or remote desktop.**

## Main menu

The V80 home screen groups **19 numbered tools** into four sections. The numbers below are the *actual current shortcuts*.

```text
GHOSTSTRATS TOOLS                    DISCOVERY & SCANNING
[ 1] GS BlackOut                      [ 7] Wireless & LAN Discovery
[ 2] GS NullOut                       [ 8] Built-in Network Tools
[ 3] GS Threat Analysis               [ 9] File Explorer
[ 4] GS BugOut                         [10] Network & IP Settings
[ 5] GS Network Intelligence
[ 6] GS Drone Detector

DEVICE & ACCESS CONTROL              SYSTEM & UTILITIES
[11] Wi-Fi & Bluetooth                [16] Startup & Privacy Audit
[12] Camera, Mic & Audio              [17] Task Manager
[13] MAC Address Inspector            [18] System & Device Overview
[14] Firewall & Port Security         [19] Turn It All On
[15] Remote Access Lockdown

[H] Help & Diagnostics                [0] Exit
```

*Select a numbered entry to open its guided submenu. No scans, shutdowns, or lockdowns start just because you opened the toolkit.*

## GhostStrats Tools (1–6)

### [1] GS BlackOut — supported privacy lockdown

One place to attempt a **controlled, reversible software lockdown**, with a saved snapshot of recognized settings. Designed for situations where you want to deliberately restrict supported interfaces—not to promise complete isolation.

| Submenu | What it does |
| --- | --- |
| **[1] Activate GS BlackOut** | Asks for confirmation, captures relevant previous states, then attempts to disable Wi-Fi, Bluetooth, NetworkManager networking/WWAN, mute the default microphone and speakers, restrict a compatible webcam driver, stop recognized SSH/Samba and Avahi/CUPS services and their activation units, and add a tagged incoming UFW deny rule where supported. |
| **[2] Turn It All On** | Attempts to reverse **only the changes recorded by the current BlackOut session**, without blindly enabling devices that were already disabled before activation. |
| **[3] Verify BlackOut Status** | Read-only verification of what Linux actually reports for radios, networking, audio, compatible cameras, services/sockets, and UFW restrictions. |
| **[4] Review GS BlackOut Backup** | Displays the saved before-state to help you understand what BlackOut changed and what can be restored. |

**Limits:** Some controls require administrator access or are hardware-dependent; software mute is not a physical microphone kill switch. Existing firewall exceptions can affect enforcement. An *unknown* status does **not** mean a device is disabled. Do not run over a remote connection.

### [2] GS NullOut — inactivity-triggered shutdown

An **optional 60-second system-wide idle monitor** for supported X11 desktops. When armed, it requests a normal computer shutdown after 60 seconds without detected activity.

| Submenu | What it does |
| --- | --- |
| **[1] Enable 60-Second Shutdown** | Checks supported X11 idle detection and explicitly arms the timer. |
| **[2] Disable GS NullOut** | Stops the armed timer within the running toolkit. |
| **[3] Check Timer Status** | Reports whether the timer is active and its estimated remaining seconds. |

It is **off by default**. An automatic poweroff is **not** a secure RAM wipe or file destruction. Save work before arming it. To try the toolkit's protected test behavior, launch with `GHOSTSTRAT_TEST_MODE=1 bash gs.sh`—this prevents NullOut's real shutdown request, but **does not turn all other tools into simulations**.

### [3] GS Threat Analysis — educational security review

A guided **read-only check of locally observable exposure**, with plain-English interpretation and an educational rating. It does **not** scan remote machines or remove threats.

| Submenu | What it does |
| --- | --- |
| **[1] Run Complete Threat Review** | Collects supported details about listening ports, established connections, firewall status, remote-access processes, radio/audio/camera status, and related local findings; includes suggested next steps. |
| **[2] Understand Threat Rating** | Explains the LOW / MODERATE / ELEVATED / HIGH heuristic and why it is not a certified security score. |
| **[3] Listening Ports and Exposure** | Lists visible TCP/UDP listening sockets and binding addresses. |
| **[4] Active TCP Connections** | Shows established connections this system can observe. |
| **[5] Privacy and Device Status** | Reviews radios, default audio mute, recognized camera device nodes, and DNS configuration. |

A listening port doesn't necessarily mean a vulnerability. This is **not antivirus or malware detection**; missing data is labeled rather than fabricated.

### [4] GS BugOut — confirmed session cleanup and shutdown

A manual **session-exit workflow**, intended to be previewed and understood before use. **This can close apps, delete selected caches and power off your computer.**

| Submenu | What it does |
| --- | --- |
| **[1] Activate Full GS BugOut** | Requires typing `BUGOUT`, then gives a cancelable countdown before starting the cleanup and shutdown sequence. |
| **[2] Preview GS BugOut** | Read-only preview of recognized user applications, eligible cache paths, network controls, and removable devices. |

The sequence attempts to: gracefully close selected non-system user applications and sync services; remove **only BugOut-owned temporary files**; clean supported thumbnails/font/shader/browser **content caches** (not browser accounts, history or cookies); clear the clipboard using an installed tool; disable supported software radios/networking; safely unmount eligible removable drives (not the toolkit drive, and not busy drives); and request a normal system shutdown. Unavailable operations are reported or skipped. **No undo** exists for deleted caches. This is **not a secure erase, memory wipe, or anonymity guarantee**.

### [5] GS Network Intelligence — local network facts

A **read-only** overview of what *your own computer* knows about its network configuration. It is not a LAN attack tool and does not actively probe external hosts.

| Submenu | What it does |
| --- | --- |
| **[1] Full Local Network Readout** | Runs all available local informational categories. |
| **[2] Interfaces and IP Addresses** | Shows device names, assigned IP addresses, and connection state. |
| **[3] Routes, Gateways and Neighbors** | Reads route tables and cached ARP/IPv6 neighbors; no LAN sweep. |
| **[4] DNS and DHCP** | Checks local resolvers and known NetworkManager/DHCP details. |
| **[5] Sockets and Listening Ports** | Displays available TCP/UDP socket information. |
| **[6] Hardware, VPN and Traffic** | Describes radio/virtual interfaces and available adapter counters. |
| **[7] Firewall and Local Security** | Summarizes accessible firewall and link status. |

These reports may contain sensitive addresses. Redact them before sharing screenshots.

### [6] GS Drone Detector — Turbo-only drone radio awareness

Selecting **[6]** starts a continuous **TURBO drone-only scanner** immediately; there is **no detector submenu**. Press **Esc once** to stop Wi-Fi and BLE scanning and return directly to the toolkit main menu. The scanner restores the original terminal mode so your keyboard works when you return. `Ctrl+C` also stops the scanner.

The dashboard automatically combines supported Wi-Fi name/manufacturer clues, BLE drone-related advertisements and supported Open Drone ID messages received from compatible hardware. Unrelated wireless devices are filtered out of matches and warnings.

| Feature | Behavior |
|---|---|
| Turbo Wi-Fi surveys | Requests a new scan every **3 seconds**, subject to NetworkManager/driver throttling |
| BLE listening | Always attempted during Turbo scans; requires BlueZ/Bleak and a compatible receiver |
| Raw Remote ID Wi-Fi beacons | Optional command-line `--monitor IFACE` with dedicated compatible adapter, Scapy and appropriate privileges |
| Channel dwell | **0.5 seconds** when advanced monitor mode is configured |
| Dashboard refresh | Approximately **0.15 seconds** |
| Stop and return | **Esc** directly returns to the toolkit main menu and stops capture |
| Signal levels | Green **0–49** weak, yellow **50–89** moderate, red **90–100** strong, with a peak warning at 100 |
| Device details | Available broadcast identifier, signal strength, advertised names, decoded supported Remote ID fields and timestamps |

The signal-strength indicator is **not a distance or time-to-arrival measurement**. Brand/name matches are not proof of a drone. Unsupported proprietary links, including some DJI communications, may be invisible. BLE scanning does not require pairing. The detector does not offer pairing or control options.

**Run standalone:** `bash gs-drone-detector.sh`  
**Offline decoder test:** `bash gs-drone-detector.sh test`  
**Detailed setup:** [`GS_Drone_Detector_README.md`](GS_Drone_Detector_README.md)

### [7] Wireless & LAN Discovery

Guided nearby-device and basic authorized-network discovery tools.

| Submenu | What it does |
| --- | --- |
| **[1] Nearby Wi-Fi Networks** | Displays visible network advertisements and reported signal quality; may ask before enabling Wi-Fi. |
| **[2] Nearby Bluetooth Devices** | Searches for nearby Bluetooth advertisements; may ask before enabling Bluetooth. |
| **[3] Network Neighbor Cache** | Lists neighbors already known to the computer; not an exhaustive inventory. |
| **[4] Check Local TCP Ports** | Connect-tests selected common ports on **127.0.0.1** (your own computer). |
| **[5] Scan Authorized LAN Host** | Checks selected common ports on **one private IPv4 host** after you explicitly confirm permission. |
| **[6] Watch Traffic Counters** | Samples adapter byte counters to estimate transfer rates; doesn't capture packet contents. |

Only scan networks and devices that you own or have permission to assess.

### [8] Built-in Network Tools — 19 Linux command shortcuts

These launch existing, generally **read-only Linux utilities** with human-readable explanations. Missing commands are reported; the toolkit doesn't silently install them.

| # | Shortcut | What it shows |
| --- | --- | --- |
| 1 | Show IP Addresses | Interface/IP summary (`ip -brief address`). |
| 2 | Show Network Interfaces | Link-level interfaces and MAC details (`ip link show`). |
| 3 | Show Routes and Gateway | IPv4 route table and default route (`ip route show`). |
| 4 | Known LAN Neighbors | Already learned ARP/IPv6 neighbors (`ip neigh show`). |
| 5 | Listening Ports | Locally listening TCP/UDP sockets (`ss -tuln`). |
| 6 | Active Connections | Socket/connection information where accessible (`ss -tunap`). |
| 7 | Wi-Fi Access Points | Visible SSIDs, BSSIDs, channels, frequencies, signal and security (`nmcli`). |
| 8 | Network Adapters | NetworkManager device state (`nmcli device status`). |
| 9 | Saved Connection Profiles | Known NetworkManager profiles; not passwords. |
| 10 | Network DNS Settings | Device-level resolver, gateway and connection details. |
| 11 | Local IP Summary | Host IP addresses (`hostname -I`). |
| 12 | Resolve Domain Name | Resolves an example domain through configured name services (`getent`). **May trigger normal DNS network traffic.** |
| 13 | Check Local Gateway | Determines Linux's selected route (`ip route get`), without sending packets. |
| 14 | Interface Traffic Counters | Kernel receive/transmit counters (`/proc/net/dev`). |
| 15 | Radio Block Status | Hardware/software wireless block state (`rfkill list`). |
| 16 | Network Manager Radio Status | NetworkManager radio controls (`nmcli radio all`). |
| 17 | IPv6 Addresses | IPv6 interface addresses (`ip -6 address show`). |
| 18 | IPv6 Routes | IPv6 routing table (`ip -6 route show`). |
| 19 | Kernel Network Statistics | Kernel IP/TCP/UDP counters (`/proc/net/snmp`). |

### [9] File Explorer — read-only local file analysis

A keyboard-driven explorer that **opens directly into a browseable folder view**, including support for hidden entries, bounded searches, and metadata inspection.

**Browser controls:**

| Control | What it does |
| --- | --- |
| **[1–10]** | Open a displayed numbered folder or inspect the selected file (numbers depend on visible entries). |
| **[11] / [12]** | Next / previous results page. |
| **[13]** | Go up one folder. |
| **[14]** | Go to home folder. |
| **[15]** | Show a bounded folder tree. |
| **[16]** | Display current folder details/permissions. |
| **[17]** | Search file names (case-insensitive; bounded). |
| **[18]** | Open a specified folder path. |
| **[19]** | Show or hide dotfiles. |
| **[0]** | Return to toolkit. |

**File inspection actions:** Full file information (type, size, owner/group, permissions, timestamps, symlink details); optional **SHA-256** checksum; optional **text preview** with confirmation; optional **first 256 bytes as hexadecimal**. The explorer can also inspect a folder tree or file from the command line:

```bash
python3 gs_file_explorer.py --tree ~/Documents --depth 3
python3 gs_file_explorer.py --inspect ~/Documents/example.txt
```

The explorer is designed to avoid modifying files. Reading can still update filesystem access timestamps, and previews may expose secrets. Broad searches skip special virtual locations such as `/proc`, `/sys`, `/dev` and `/run` and do not traverse symlinked directories. A hash doesn't tell you whether a file is malicious.

### [10] Network & IP Settings

Read network configuration and make **explicit, optional DHCP changes**.

| Submenu | What it does |
| --- | --- |
| **[1] List Interfaces and IP Addresses** | Read-only local interface/address list. |
| **[2] Show Connection Status** | Read-only NetworkManager connection status. |
| **[3] Renew Current DHCP Lease** | Requests a fresh local DHCP lease; your router may assign the **same** IP. |
| **[4] Request Different Local IP** | Tries a different DHCP client identity with a backed-up profile setting; changing the address is **not guaranteed**. |
| **[5] Restore Original DHCP Identity** | Restores the previous client-identity profile setting and reconnects; not necessarily the old IP address. |

This affects **local** network configuration, not your public internet IP. It can disconnect you; use the local console.

## Device & Access Control (11–15)

### [11] Wi-Fi & Bluetooth

| Submenu | What it does |
| --- | --- |
| **[1] Check Radio Status** | Read-only state of recognized Wi-Fi/Bluetooth radios. |
| **[2] Disable Wi-Fi** | Requests a software Wi-Fi radio block/off state. |
| **[3] Enable Wi-Fi** | Requests Wi-Fi back on; reconnection isn't guaranteed. |
| **[4] Disable Bluetooth** | Requests Bluetooth soft block or controller power-off, depending on support. |
| **[5] Enable Bluetooth** | Attempts to unblock/power on Bluetooth; paired devices may need reconnecting. |

A **soft block** is a software-requested disable state; it is not the same as a physical hardware switch.

### [12] Camera, Mic & Audio

| Submenu | What it does |
| --- | --- |
| **[1] View Device Status** | Inspects recognized audio mute and camera/driver states. |
| **[2] Mute Microphone** | Software-mutes the *default* microphone input. |
| **[3] Unmute Microphone** | Unmutes the default input, where supported. |
| **[4] Disable Camera** | Attempts to unload the supported `uvcvideo` webcam driver. |
| **[5] Enable Camera** | Attempts to reload that driver. |
| **[6] Mute Speakers** | Mutes the default audio output. |
| **[7] Unmute Speakers** | Unmutes the default audio output. |

USB webcams using other drivers, additional microphones, and other audio sinks may not be affected. Software controls are **not** guaranteed physical isolation.

### [13] MAC Address Inspector

**Read-only:** no spoofing or randomization is performed by this menu.

| Submenu | What it does |
| --- | --- |
| **[1] Current Interface MAC Addresses** | Lists current adapter addresses and link states. |
| **[2] Permanent Hardware MAC Addresses** | Compares current and permanent addresses when Linux/`ethtool` exposes them. |
| **[3] Known Neighbor MAC Addresses** | Displays the existing IPv4/IPv6 neighbor cache. |
| **[4] Interface Statistics** | Inspects byte counters and link statistics. |
| **[5] Wi-Fi Access Point BSSIDs** | Shows visible access-point MAC addresses/signal information through NetworkManager. |
| **[6] NetworkManager Device Details** | Shows available per-device properties and identifiers. |

Modern devices may randomize MAC addresses, and the neighbor cache doesn't list every nearby device.

### [14] Firewall & Port Security

Combines inspection with **clearly identified firewall-changing options**. UFW must be installed and supported for UFW actions.

| Submenu | What it does |
| --- | --- |
| **[1] Firewall Status** | Checks current UFW enforcement. |
| **[2] Listening Ports** | Shows locally listening TCP/UDP sockets. |
| **[3] Detailed Rules** | Inspects verbose UFW policies and known rules. |
| **[4] Enable UFW** | Activates your **existing** firewall policy; existing allow exceptions remain. |
| **[5] Block Common Remote Ports** | Applies GS-tagged inbound restrictions for a defined collection of common remote-service ports. |
| **[6] Block New Incoming Traffic** | Attempts a broader GS-managed incoming traffic restriction. |
| **[7] Restore GS Port Rules** | Removes recorded GS-managed port rules without intentionally deleting unrelated rules. |
| **[8] Disable UFW (Advanced)** | Disables UFW enforcement, which can expose network services. |

Read-only status is **not** proof that a host is unreachable from every network. Any firewall changes may disrupt LAN sharing, remote sessions, or permitted services. Do not confuse firewall rule removal with GS BlackOut's separate recorded recovery process.

### [15] Remote Access Lockdown

A guided workflow for **recognized** SSH, Samba, remote desktop and relevant service/socket states. Not every third-party remote-access program can be recognized.

| Submenu | What it does |
| --- | --- |
| **[1] View Remote Access Status** | Summarizes recognized remote services, listening sockets, UFW state, and whether a restore snapshot is pending. |
| **[2] Apply Remote Access Lockdown** | Saves previous supported states, then attempts to stop known services and restrict incoming access using supported UFW settings. |
| **[3] Restore Previous Remote Settings** | Restores the standalone remote-lockdown snapshot, if present. |
| **[4] Technical Details** | Shows recognized service lists, listening sockets, and relevant firewall information. |

The tool refuses to overwrite certain pending backups, reducing the risk of losing your return path. **If GS BlackOut owns the snapshot, use [19] Turn It All On** instead of this standalone restore. Existing UFW allow rules may remain effective. This does not guarantee all remote software is disabled or that outbound sessions have stopped.

## System & Utilities (16–19)

### [16] Startup & Privacy Audit

A **read-only** educational review of common Linux persistence locations and local data residue. It does **not** declare something malicious simply because it starts automatically.

| Submenu | What it does |
| --- | --- |
| **[1] Startup Applications** | Lists metadata for desktop autostart entries. |
| **[2] Enabled Background Services** | Inspects enabled system/user `systemd` services where visible. |
| **[3] Scheduled Tasks** | Reviews known system timers and cron entry counts, without dumping cron command contents. |
| **[4] Login & Persistence Hooks** | Examines common shell profiles and user service locations by name/metadata. |
| **[5] Recent Configuration Changes** | Shows timestamps for known package/startup configuration files. |
| **[6] Privacy Residue** | Checks for common shell history, thumbnail, recently-used, browser-profile and trash paths using metadata/counts; doesn't erase or display private contents. |

A timestamp change cannot establish who changed a file or whether the change was malicious. This is not full digital forensics.

### [17] Task Manager

| Submenu | What it does |
| --- | --- |
| **[1] Open Live Process Viewer** | Built-in periodically updating process view with PID, CPU and memory usage. Use `R` to refresh or `Q`/`0` to exit. |
| **[2] Show Process Snapshot** | One-time `ps` listing of processes and their CPU/memory utilization. |

These views are designed for inspection, **not bulk process termination**. Permissions can limit visibility into other users' tasks.

### [18] System & Device Overview

| Submenu | What it does |
| --- | --- |
| **[1] System Information** | Kernel/system details, current user, uptime, and available memory. |
| **[2] Privacy Device Status** | Current recognized Wi-Fi, Bluetooth, audio, and camera-driver states. |
| **[3] Network Interfaces** | Local adapters and assigned addresses. |
| **[4] Toolkit Diagnostics** | Checks available commands, compatibility clues, and missing dependencies without altering the system. |

### [19] Turn It All On — reverse GS BlackOut only

| Submenu | What it does |
| --- | --- |
| **[1] Inspect BlackOut Backup** | Shows what the most recent supported BlackOut activation recorded. |
| **[2] Turn It All On — Undo BlackOut** | Requests confirmation and attempts to reverse **only saved GS BlackOut changes** to recognized radios, audio, cameras, services, networking and firewall. |

**Despite the name, this is not a reset button.** It does **not** reverse BugOut, restore DHCP identities, repair unrelated network issues, clear all firewall history, or force every device on. Without a valid BlackOut backup, no device-state restoration is attempted. Partial restore failures need attention.

## Help, keyboard controls and Easter eggs

### [H] Help & Diagnostics

Available from the main screen. Eight guided topics:

1. **Getting Started** — launch, navigation, and feature basics.
2. **Ghost Privacy Controls** — BlackOut, NullOut and what software-only controls cannot guarantee.
3. **Network & Scanning Basics** — interpreting ports, radios, and local findings.
4. **Why True Privacy Is Difficult** — practical limitations and tradeoffs.
5. **Safety & Troubleshooting** — safe use and recovery reminders.
6. **Persistence & Privacy Awareness** — startup points and metadata residue.
7. **Toolkit Diagnostics** — supported-command/compatibility checks.
8. **Guided Workflow by Feature** — suggested order for learning each section.

**Keyboard:** Enter menu numbers as prompted; `0` returns/back or exits at top level. Supported menus accept `Esc` to return toward the toolkit home and `?` for context help. Active external programs or sudo prompts retain control of the keyboard; use their normal exit keys or `Ctrl+C` as appropriate.

### Easter eggs

There are **hidden GhostStrats and community Easter eggs** tucked into this project. Some are little discoveries. Some are messages. A few may surprise you.

**No cheat sheet here. No spoilers. Good luck finding them.** 👻

## Dependencies and compatibility

**Basic requirements:** Linux desktop (Mint, Kali, Parrot; Tails restricted), interactive terminal, **Bash 4+**, **Python 3**, and the toolkit files together in the same folder. Run as a normal user. Use `./Install-and-Run.sh --check` for automatic distribution/session reporting.

**Feature-dependent Linux commands may include:** `ip`, `ss`, `nmcli`/NetworkManager, `rfkill`, `systemctl`, `pactl`, `ufw`, `ethtool`, `bluez`, and `iw`. Camera, audio, radio and firewall behavior depends on hardware, permissions, distro versions, and the installed services. The toolkit reports unsupported checks instead of assuming they succeeded. On some systems, `sudo` is requested **only for the selected privileged action**.

**Optional drone features:**

```bash
sudo apt update
sudo apt install network-manager bluez iw python3-scapy ieee-data
# Optional on distros that package it:
sudo apt install python3-bleak
```

For the **advanced Wi-Fi Beacon Remote ID** mode, a **separate compatible Wi-Fi adapter** supporting monitor mode is strongly recommended. Normal Wi-Fi discovery and a drone name match are **not** equivalent to decoded Remote ID telemetry. No extra packages are installed automatically merely by opening the detector. See its [dedicated guide](GS_Drone_Detector_README.md) before using advanced capture.

## Testing and limitations

The V80 source passes its regression tests, including drone-only candidate filtering, BLE Remote ID decoding with synthetic advertisements, Turbo-only scanning, Esc exit handling, and earlier signal-warning tests. Mint/Kali/Parrot/Tails hardware-specific behavior still requires physical testing. Tests include menu numbering and dispatch, scanner integration, file browsing, and supported state/recovery logic. You can run the tests locally:

```bash
python3 -m unittest discover -s tests -q
bash gs-drone-detector.sh test
```

**Tests are not a guarantee on every Linux system**. Software simulation cannot establish that a physical Bluetooth adapter works, a camera is electrically disabled, UFW rules have the intended effect on every topology, or a particular DJI Neo transmits a receivable signal. Observe real state reports and validate on noncritical hardware first.

## Project structure

| File or module | Role |
| --- | --- |
| `gs.sh`, `gs.py`, `gs_keys.py`, `gs_brand.py`, `gs_platform.py` | Bash entry point, main terminal interface, keyboard navigation and branding. |
| `Install-and-Run.sh`, `Run-Portable.sh`, `Uninstall-GhostStrats.sh` | Per-user installer, standalone launcher, and per-user uninstall script. |
| `blackout-*.sh`, `device-controls.sh`, `restore-all.sh`, `startup_settings.py` | BlackOut, device controls, scoped undo and initial settings capture. |
| `gs_bugout.py` | GS BugOut preview, staged cleanup and shutdown. |
| `threat-analysis.py`, `network-intelligence.py`, `diagnostics.py` | Local exposure report, network readout and toolkit diagnostics. |
| `gs-drone-detector.sh`, `GS_Drone_Detector_README.md` | Experimental drone-only wireless awareness scanner and setup guide. |
| `scanning.py`, `network-adapters.sh`, `ip-changer.py`, `mac-controls.py` | Discovery, adapter management, DHCP identity and MAC inspection. |
| `firewall-controls.py`, `gs-port-lockdown.sh`, `remote-lockdown.sh` | Firewall and recognized remote-access controls. |
| `gs_file_explorer.py`, `persistence_privacy.py`, `task_manager.py` | File explorer, startup/privacy metadata audit, process views. |
| `easter_eggs.py`, `gs_snake.py` | The secret stuff. (Still not giving you the answers.) |
| `tests/` | Automated unit and regression tests. |

## Safety, privacy and responsible use

- **Read before applying.** Privacy/control actions may change networking or hardware settings. BugOut can remove selected caches and request shutdown; NullOut may shut down automatically after an idle timeout. Always save work and have a recovery plan.
- **Permission matters.** Only scan networks, devices and computers you own or are authorized to inspect. No active jamming, interception bypass, or drone control is included.
- **Don't mistake a label for proof.** A radio-name match, risk rating, local socket, or missing status signal does not conclusively establish a drone, malicious process, real vulnerability, or complete privacy protection.
- **Keep reports private.** Your terminal can display IPs, MAC addresses, hostnames, process names, and file paths. Drone logs, if enabled, may contain broadcast device IDs and location coordinates. Share sanitized screenshots.
- **Offline-first by design.** Core local tools do not require a cloud account. Some operations—such as optional manufacturer-database updates or ordinary domain resolution—may use a network connection. Third-party Linux programs obey their own behavior.
- **No warranty of security.** This is an educational project provided as-is, not a replacement for an independent security review or safety-critical equipment. Tails restricted mode is a menu guard only, not OS-level confinement.

## About the project

Created by **GhostStrats** for people who want to **understand their technology instead of blindly trusting it**—from Linux beginners learning how a firewall works to experienced users exploring wireless systems, network visibility, and practical privacy controls.

YouTube: [@GhostStrats](https://www.youtube.com/@GhostStrats)

**Privacy Is an Illusion. Knowledge Is a Tool.**

---

**License:** No software license has been selected for this repository yet. A public GitHub repository does *not* automatically grant others permission to copy, modify or redistribute the source. The repository owner should choose and add a `LICENSE` file before inviting redistribution or contributions.
