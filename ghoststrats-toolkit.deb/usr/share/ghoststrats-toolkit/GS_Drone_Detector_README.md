# V81 Bluetooth behavior

BLE drone scanning is always attempted automatically in Turbo mode. No BLE-disable option remains. If Bluetooth hardware, BlueZ, or `python3-bleak` is unavailable, the dashboard reports that BLE reception is unavailable and Wi-Fi scanning can continue. This tool does not turn the Bluetooth radio off or on. Press Esc to end both scans and return to the toolkit main menu.

# GS Drone Detector v2.6 — TURBO Only (Ghost Strategist Toolkit V80)

**Drone-only passive radio awareness** using the available computer hardware on Linux Mint, Kali and Parrot. This is an experimental detector, not a safety-of-flight system, a universal drone detector or a distance meter.

## Start — no extra menu

Open the **Ghost Strategist Toolkit** and press **[6] GS Drone Detector**. The continuous Turbo scan begins immediately. No other detector menus or pairing commands appear.

**To stop:** press **Esc once, without Enter**. This stops the Wi-Fi scan process and BLE discovery, restores keyboard settings, and returns to the toolkit **main menu**. **Ctrl+C** also stops the scan.

Standalone from the extracted folder:

```bash
bash gs-drone-detector.sh
```

To run without radio hardware for a decoder check:

```bash
bash gs-drone-detector.sh test
```

## Scan schedule and source types

The single TURBO profile uses **3-second requests** for Wi-Fi survey rescan, **0.15-second terminal refresh**, and **0.5-second channel dwell only if using a dedicated monitor-mode adapter**. Wi-Fi drivers and NetworkManager may throttle or take longer than requested. Constantly displaying a fast dashboard does not imply new radio data has arrived.

- **Wi-Fi:** Recognizes possible drone SSID patterns and manufacturer names from available NetworkManager surveys. Ordinary Wi-Fi name discovery can transmit scan requests and is not strictly passive.
- **BLE:** Listens continuously to supported BLE advertisements with the optional `bleak` library and BlueZ. Non-drone-related BLE devices stay hidden.
- **Remote ID:** Attempts to decode supported Open Drone ID messages when they appear in supported BLE service data, or Wi-Fi vendor-specific beacons from a compatible monitor-mode receiver. A normal Wi-Fi survey alone does not decode all Remote ID traffic.
- **Display:** Provides possible model/vendor clues, source type, signal meter, radio identifiers and available supported Remote ID fields. No Bluetooth pairing is attempted or offered.

Optional dependencies on Debian-based Linux:

```bash
sudo apt install network-manager bluez iw python3-scapy
sudo apt install python3-bleak  # if offered by your distro
```

Use a spare, monitor-capable adapter for raw Wi-Fi Remote ID reception, if desired, from a local authorized environment. Technical CLI interface:

```bash
sudo bash gs-drone-detector.sh scan --monitor wlan1
```

This is still the **same Turbo scan**, but adds an optional monitor-mode receiver. Elevated permissions are required for this option and may interfere with networking if the adapter is not dedicated to monitoring.

## Signal warnings and their meaning

| Bar | Index | Label |
|---|---|---|
| Green | 0–49 | Weak signal; distance unknown |
| Yellow | 50–89 | Moderate signal; proximity uncertain |
| Red | 90–99 | Strong signal; possibly close |
| Red | 100 | DANGER: MAX SIGNAL — POSSIBLY CLOSE |

The percentages are an approximate display index, especially for dBm values. Signal strength is influenced by power, antennas, reflections and obstacles. **It cannot reliably predict distance, approach time or collision risk.** A possible drone match is not confirmation of a drone.

## DJI Neo test

Your DJI Neo may not advertise Remote ID in the mode or region where you test. Put it in a manufacturer-supported local wireless mode while following its operating instructions. A missing result does not mean a drone is not nearby or that the scanner is malfunctioning.

## Limitations and safety

This tool is not affiliated with any drone company. It cannot detect every drone, authenticate every Remote ID message, decode proprietary digital control links, jam radios, fly aircraft or provide a verified safety alert. Only scan radio/network environments you are permitted to inspect. The included Tails toolkit mode intentionally blocks active scanning.

## Troubleshooting

- **Scanner stays empty:** Check `nmcli`, BLE support, permissions, your adapter and whether the drone transmits any detectable supported identifiers. The offline `test` command confirms decoder logic, not live hardware.
- **Screen refresh seems fast but detections delayed:** The actual adapter/driver and transmitter advertisement schedule determine received data speed.
- **Esc not working:** Ensure the terminal window has keyboard focus. `Ctrl+C` also stops the scan. If an older release left the terminal broken, exit it and run `stty sane`.
- **Wi-Fi disconnects:** Frequent active scans can affect a connected adapter. Consider a dedicated adapter for advanced capture.

**Privacy Is an Illusion. Knowledge Is a Tool.**
