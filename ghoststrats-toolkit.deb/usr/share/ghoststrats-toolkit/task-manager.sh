#!/usr/bin/env bash
# Compatibility launcher for the Ghost Strategist Tool's integrated task manager.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
exec python3 ./task_manager.py "$@"
