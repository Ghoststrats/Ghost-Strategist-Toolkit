#!/usr/bin/env bash
# Activate GS BlackOut using a session-only snapshot, never the startup baseline.
set -u
umask 077
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/ghost-strategist-tool"
export GS_BLACKOUT_DEVICE_STATE="$STATE_DIR/blackout-session-v66.tsv"
case "${1:-}" in
  apply)
    if [[ -e "$GS_BLACKOUT_DEVICE_STATE" || -L "$GS_BLACKOUT_DEVICE_STATE" ]]; then
      printf '%s\n' 'An existing GS BlackOut session is awaiting Turn It All On. Refusing to overwrite it.'
      exit 1
    fi
    # Other standalone lockdown backups have separate owners. Refuse rather
    # than applying BlackOut over them and risking an incomplete undo.
    for other in remote-lockdown-state.tsv port-lockdown-v22.state blackout-extra-v47.tsv; do
      if [[ -e "$STATE_DIR/$other" || -L "$STATE_DIR/$other" ]]; then
        printf 'Existing standalone lockdown backup: %s
' "$other"
        printf '%s
' 'Restore that earlier action first; GS BlackOut has not been activated.'
        exit 1
      fi
    done
    exec bash "$BASE/device-controls.sh" ghost;;
  *) printf '%s\n' 'Usage: blackout-control.sh apply'; exit 2;;
esac
