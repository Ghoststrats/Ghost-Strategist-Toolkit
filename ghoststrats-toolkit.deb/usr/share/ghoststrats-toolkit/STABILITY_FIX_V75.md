# Ghost Strategist Toolkit V75 — Terminal Stability Fix

## Fixed
- The live Task Manager and Easter egg terminal animations no longer use buffered `sys.stdin.read(1)`; they read one character from the TTY directly so the main menu can receive later key presses.
- The toolkit captures the initial terminal input/echo configuration and restores it after completed, failed, or interrupted menu actions and external commands.
- Navigation remains **[1] through [19]** with **GS Drone Detector at [6]**.

## Troubleshooting
If V74 appears unresponsive, press Ctrl+C (or close that terminal), open a new terminal, and run `stty sane` if typing is invisible. Install V75 using `./Install-and-Run.sh` or the V75 `.deb` release, then launch `ghoststrats-toolkit`.

Don't run the app as root. Some external programs hold the terminal until they finish; use their normal exit command or Ctrl+C rather than typing toolkit menu numbers inside those programs.

## Testing
180 automated tests passed, including 5 V75 terminal-input tests. A non-root pseudo-terminal navigation test opened the live Task Manager, returned to home, opened a second tool, and exited. Hardware and distribution-specific behavior require testing on real Linux Mint, Kali, Parrot, and Tails installations.
