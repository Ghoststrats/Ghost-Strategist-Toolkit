#!/usr/bin/env python3
"""Read-only / opt-in local network discovery for Ghost Strategist Tool.

No new packages are installed; no scans occur automatically.
"""
from gs_brand import print_gs as print
import gs_keys
import concurrent.futures
import ipaddress
import re
import shutil
import socket
import subprocess
import time
from pathlib import Path

COMMON_PORTS = {
  20:'FTP data',21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',80:'HTTP',
  110:'POP3',111:'RPC',135:'RPC',139:'NetBIOS',143:'IMAP',443:'HTTPS',445:'SMB',
  587:'SMTP submission',631:'IPP printing',993:'IMAPS',995:'POP3S',1433:'SQL Server',
  2049:'NFS',3306:'MySQL',3389:'RDP',5432:'PostgreSQL',5900:'VNC',6379:'Redis',
  8080:'HTTP alternate',8443:'HTTPS alternate',9000:'App server'
}

def run_tool(command, limit=15):
    name=command[0]
    if not shutil.which(name):
        print(f'Unavailable: {name} is not installed. Nothing was changed.')
        return None
    try:
        completed=subprocess.run(command, text=True, stdout=subprocess.PIPE,
                  stderr=subprocess.STDOUT, timeout=limit, check=False)
        output=completed.stdout.strip()
        if output:
            lines=output.splitlines()
            if len(lines)>160:
                print('\n'.join(lines[:160]))
                print(f'... {len(lines)-160} additional rows omitted. Narrow the query for more.')
            else:
                print(output)
        if completed.returncode:
            print(f'{name} returned code {completed.returncode}.')
        return completed
    except subprocess.TimeoutExpired:
        print(f'{name} timed out; no background scan was intentionally started.')
    except OSError as e:
        print('Could not start',name,':',e)
    return None

def _query(command, timeout=6):
    """Get command output without treating a failed device query as a safe state."""
    if not shutil.which(command[0]):
        return None, f'{command[0]} is not installed'
    try:
        proc = subprocess.run(command, capture_output=True, text=True,
                              timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, str(exc)
    if proc.returncode:
        return None, (proc.stderr or proc.stdout or 'command failed').strip()
    return proc.stdout.strip(), None


def _radio_choice(label):
    """No radio is switched on unless the user explicitly selects 1."""
    try:
        response = gs_keys.read_line(f'{label} is disabled. [1] Enable {label} and scan  '
                         '[0] Cancel: ').strip()
    except (EOFError, KeyboardInterrupt):
        print('\nCancelled. Radio settings unchanged.')
        return False
    if response != '1':
        print('Cancelled. Radio settings unchanged.')
        return False
    print(f'Enabling {label} can make this computer discoverable or transmit radio signals.')
    print(f'{label} will remain enabled when this scan finishes. Use Device Controls to turn it off.')
    return True


def _wifi_state():
    state, err = _query(['nmcli', 'radio', 'wifi'])
    if err or state not in ('enabled', 'disabled'):
        return None, f'Cannot determine Wi-Fi status: {err or state or "no response"}'
    # NetworkManager can report a software-enabled radio that is hardware-blocked.
    radios, _ = _query(['nmcli', '-t', '-f', 'WIFI-HW,WIFI', 'radio', 'all'])
    if radios:
        hw = radios.splitlines()[0].split(':', 1)[0].strip().lower()
        if hw == 'disabled':
            return 'hardware-blocked', 'The Wi-Fi adapter is hardware-blocked or unavailable.'
    return state, None


def wifi_scan():
    print('\nWI-FI SCAN — Nearby access points (SSID, BSSID, signal and security).')
    print('Scanning may transmit Wi-Fi probe requests; it is not anonymous.')
    if not shutil.which('nmcli'):
        print('NetworkManager (nmcli) is not available. Nothing changed.')
        return
    state, error = _wifi_state()
    if state == 'hardware-blocked':
        print(error)
        print('Check the laptop wireless switch, airplane mode, or adapter before scanning.')
        return
    if state is None:
        print(error)
        print('Status could not be verified. Check [6] Wi-Fi Controls before scanning.')
        return
    if state == 'disabled':
        if not _radio_choice('Wi-Fi'):
            return
        out, error = _query(['nmcli', 'radio', 'wifi', 'on'])
        if error:
            print(f'Could not enable Wi-Fi: {error}')
            return
        state, error = _wifi_state()
        if state != 'enabled':
            print('Wi-Fi ON was requested, but an enabled radio could not be verified.')
            if error: print(error)
            print('Scan not started. Check Wi-Fi Controls and hardware restrictions.')
            return
        print('Wi-Fi enabled successfully. Starting nearby-network scan...')
    else:
        print('Wi-Fi already enabled. Starting nearby-network scan...')
    run_tool(['nmcli', '-f', 'IN-USE,SSID,BSSID,CHAN,SIGNAL,SECURITY',
              'device', 'wifi', 'list', '--rescan', 'yes'], limit=22)
    print('Wi-Fi remains enabled after scanning. Signal strength is not an exact distance.')


def _bluetooth_state():
    """Returns (enabled|disabled|hardware-blocked|missing|unknown, explanation)."""
    result, error = _query(['bluetoothctl', 'show'])
    if result is None:
        if error and 'No default controller' in error:
            return 'missing', 'No default Bluetooth controller is available.'
        return 'unknown', f'Cannot check the Bluetooth controller: {error}'
    powered = re.search(r'^\s*Powered:\s*(yes|no)\s*$', result, re.M | re.I)
    if not powered:
        if 'No default controller' in result:
            return 'missing', 'No default Bluetooth controller is available.'
        return 'unknown', 'Bluetooth controller did not report its powered state.'
    blocked, _ = _query(['rfkill', 'list', 'bluetooth'])
    if blocked:
        hard = re.search(r'Hard blocked:\s*(yes|no)', blocked, re.I)
        soft = re.search(r'Soft blocked:\s*(yes|no)', blocked, re.I)
        if hard and hard.group(1).lower() == 'yes':
            return 'hardware-blocked', 'Bluetooth is hard-blocked by hardware or firmware.'
        if soft and soft.group(1).lower() == 'yes':
            return 'disabled', 'Bluetooth is soft-blocked (rfkill).'
    return ('enabled' if powered.group(1).lower() == 'yes' else 'disabled'), None


def _enable_bluetooth():
    blocked, _ = _query(['rfkill', 'list', 'bluetooth'])
    if blocked and re.search(r'Soft blocked:\s*yes', blocked, re.I):
        _out, err = _query(['rfkill', 'unblock', 'bluetooth'], timeout=8)
        if err:
            print('Unblocking Bluetooth requires additional permission:', err)
            if shutil.which('sudo'):
                print('Requesting administrator permission to unblock Bluetooth...')
                try:
                    result = subprocess.run(['sudo', 'rfkill', 'unblock', 'bluetooth'],
                                            timeout=45, check=False)
                    if result.returncode:
                        print('Bluetooth unblock was denied or failed.')
                        return False
                except (OSError, subprocess.TimeoutExpired) as exc:
                    print('Bluetooth unblock failed:', exc)
                    return False
            else:
                print('sudo is unavailable; use Bluetooth Controls to unblock it.')
                return False
    # Powering on via BlueZ is separate from clearing the rfkill software block.
    output, err = _query(['bluetoothctl', 'power', 'on'], timeout=12)
    if err:
        print('Could not power on Bluetooth:', err)
        return False
    state, explanation = _bluetooth_state()
    if state != 'enabled':
        print('Bluetooth power-on could not be verified; scan cancelled.')
        if explanation: print(explanation)
        return False
    print('Bluetooth enabled successfully. Starting discovery...')
    return True


def bluetooth_scan():
    print('\nBLUETOOTH SCAN — Discover nearby broadcasting Bluetooth devices.')
    print('RSSI suggests signal strength, NOT a reliable physical distance.')
    if not shutil.which('bluetoothctl'):
        print('bluetoothctl is not available; BlueZ may be missing.')
        return
    state, explanation = _bluetooth_state()
    if state == 'hardware-blocked':
        print(explanation)
        print('Use the device hardware switch or firmware controls to unblock it.')
        return
    if state == 'missing':
        print(explanation)
        print('Connect a supported Bluetooth adapter before scanning.')
        return
    if state == 'unknown':
        print(explanation)
        print('Discovery cancelled because the radio state cannot be verified.')
        return
    if state == 'disabled':
        if explanation: print(explanation)
        if not _radio_choice('Bluetooth'):
            return
        if not _enable_bluetooth():
            return
    else:
        print('Bluetooth already enabled. Starting discovery...')
    print('Searching for approximately 10 seconds; discovery will then stop.')
    try:
        proc = subprocess.run(['bluetoothctl', '--timeout', '10', 'scan', 'on'],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=15, check=False)
        raw = proc.stdout or ''
        if proc.returncode and not raw.strip():
            print('Bluetooth scan command reported an error.')
    except subprocess.TimeoutExpired as err:
        raw = err.stdout or b''
        if isinstance(raw, bytes): raw = raw.decode('utf-8', 'replace')
        print('Bluetooth discovery reached its timeout.')
    except OSError as err:
        print('Bluetooth scan failed:', err)
        return
    finally:
        try:
            subprocess.run(['bluetoothctl', 'scan', 'off'], capture_output=True,
                           timeout=4, check=False)
        except (OSError, subprocess.TimeoutExpired):
            pass
    raw = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw)
    addresses = {}
    pat = re.compile(r'Device\s+((?:[\dA-Fa-f]{2}:){5}[\dA-Fa-f]{2})\s+(.*)')
    for ln in raw.splitlines():
        m = pat.search(ln)
        if not m: continue
        addr = m.group(1).upper()
        detail = m.group(2).strip()
        item = addresses.setdefault(addr, {'name': '(unknown)', 'rssi': None})
        rssi = re.search(r'RSSI:\s*(-?\d+)', detail)
        if rssi: item['rssi'] = int(rssi.group(1))
        elif detail and not any(x in detail for x in ('ManufacturerData','TxPower','ServicesResolved','Connected','UUID','Alias','Name:')):
            if detail not in ('(unknown)','RSSI') and not detail.startswith(('Class:','Icon:','LegacyPairing:')):
                item['name'] = detail[:50]
    if addresses:
        print(f'\nFound {len(addresses)} devices or broadcasts:')
        print(f'{"MAC address":<19} {"RSSI":<9} {"Signal":<11} Name')
        for address,item in sorted(addresses.items(),
                                   key=lambda kv: (kv[1]['rssi'] is None,-(kv[1]['rssi'] or -999))):
            rssi = item['rssi']
            signal = ('stronger' if rssi >= -60 else 'moderate' if rssi >= -75 else 'weaker') if rssi is not None else 'unknown'
            val = f'{rssi} dBm' if rssi is not None else 'unknown'
            print(f'{address:<19} {val:<9} {signal:<11} {item["name"]}')
    else:
        print('No nearby devices were reported during this scan.')
        if raw.strip(): print(raw.strip()[-1100:])
    print('RSSI varies with walls, antennas, movement and transmission power.')
    print('Bluetooth remains enabled after scanning; switch it off in Device Controls if needed.')

def neighbors():
    print('\nLOCAL NETWORK NEIGHBORS (read-only ARP/NDP cache).')
    print('Shows previously discovered neighbors; this does not actively scan every host.')
    run_tool(['ip','neigh','show'])

def listening():
    print('\nLOCAL LISTENING PORTS — sockets open on this computer, not an external scan.')
    print('Some process details require additional permissions.')
    run_tool(['ss','-lntu'])

def connections():
    print('\nACTIVE NETWORK CONNECTIONS — established TCP connections.')
    run_tool(['ss','-tn','state','established'])

def tcp_scan(host='127.0.0.1'):
    """Small bounded concurrent TCP connection check; never a vulnerability scan."""
    print(f'\nCOMMON TCP PORTS ON {host} — connect scan without Nmap.')
    print('This is a small TCP connection check, not a vulnerability assessment.')
    print(f'Testing {len(COMMON_PORTS)} common ports (TCP only; max 8 concurrent attempts).')

    def check_port(port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.35)
                return port if sock.connect_ex((host, port)) == 0 else None
        except OSError:
            return None

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            hits=sorted(port for port in pool.map(check_port, COMMON_PORTS) if port is not None)
    except KeyboardInterrupt:
        print('\nScan interrupted.'); return
    if hits:
        for port in hits:
            print(f'  {port:>5}/tcp  OPEN     {COMMON_PORTS[port]}')
    else:
        print('No successful TCP connections to the selected common ports.')
    print('Connections can be blocked by firewalls. An OPEN port is not proof of a threat.')
    print('Results cover ONLY this curated port list, not every possible port.')

def lan_scan():
    raw=gs_keys.read_line('Authorized private IPv4 address (e.g. 192.168.1.10), or 0 to cancel: ').strip()
    if raw=='0':print('Cancelled.');return
    try:
        ip=ipaddress.ip_address(raw)
        if not isinstance(ip,ipaddress.IPv4Address): raise ValueError('IPv4 only')
        allowed=(ip in ipaddress.ip_network('10.0.0.0/8') or
                 ip in ipaddress.ip_network('172.16.0.0/12') or
                 ip in ipaddress.ip_network('192.168.0.0/16') or
                 ip in ipaddress.ip_network('127.0.0.0/8') or
                 ip in ipaddress.ip_network('169.254.0.0/16'))
        if not allowed: raise ValueError('Only localhost or private/local network IPs are supported')
    except ValueError as e:
        print('Invalid target:',e);return
    print('Only scan a device you own or are authorized to audit.')
    if gs_keys.read_line(f'Scan common TCP ports on {ip}? [y/N]: ').strip().lower()!='y':
        print('Cancelled.');return
    tcp_scan(str(ip))

def network_bytes():
    result={}
    try:
        for line in Path('/proc/net/dev').read_text().splitlines()[2:]:
            interface,fields=line.split(':',1)
            nums=fields.split()
            if len(nums)>=9:
                result[interface.strip()]=(int(nums[0]),int(nums[8]))
    except (OSError,ValueError): pass
    return result

def monitor():
    print('\nLIVE NETWORK TRAFFIC MONITOR — five samples, 2s apart (read-only).')
    print('Byte counts are per interface; not packet content or remote identity.')
    prev=network_bytes()
    if not prev: print('/proc/net/dev unavailable.');return
    try:
        for i in range(1,6):
            time.sleep(2)
            now=network_bytes()
            print(f'\nSample {i}/5 — received / transmitted bytes in last 2 seconds:')
            for interface,(rx,tx) in sorted(now.items()):
                if interface=='lo':continue
                old_rx,old_tx=prev.get(interface,(rx,tx))
                print(f'  {interface:<15} RX {max(0,rx-old_rx):>10,} B   TX {max(0,tx-old_tx):>10,} B')
            prev=now
    except KeyboardInterrupt:
        print('\nMonitoring stopped.')
