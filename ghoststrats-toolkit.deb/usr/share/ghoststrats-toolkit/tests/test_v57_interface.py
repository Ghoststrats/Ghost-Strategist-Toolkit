"""V57 current-feature UI and safety checks. No real system changes."""
import contextlib
import io
import os
import re
import shutil
import subprocess
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import gs
import gs_bugout
import gs_file_explorer as explorer
import startup_settings

SUBMENUS = [
    'sub_blackout','sub_bugout','sub_nullout','sub_restore','sub_radios',
    'sub_peripherals','sub_overview','sub_network','sub_network_intelligence',
    'sub_mac','sub_task','sub_remote','sub_network_shortcuts',
    'sub_scanning','sub_threat','sub_firewall','sub_persistence','sub_help',
]

class InterfaceV57(unittest.TestCase):
    def test_all_nineteen_main_choices_contiguous(self):
        menu=[(int(k),v) for _,lst in gs.MAIN_SECTIONS for k,v in lst]
        self.assertEqual(sorted(k for k,_ in menu),list(range(1,20)))
        self.assertEqual([k for k,_ in menu],list(range(1,20)))  # Grouped under GhostStrats Tools
        self.assertEqual(len(set(name for _,name in menu)),19)
        self.assertEqual(dict(menu)[4],'GS BugOut')
        self.assertEqual(dict(menu)[9],'File Explorer')
        self.assertNotIn('Theme',str(menu))
        self.assertNotIn('Nmap',str(menu))

    def test_submenus_have_unique_contiguous_numbers_and_handlers(self):
        for method in SUBMENUS:
            with self.subTest(method=method), mock.patch.object(gs,'persistent_menu') as menu:
                getattr(gs,method)()
                title, entries, handlers=menu.call_args.args[:3]
                choices=re.findall(r'(?m)^\s*\[(\d+)\]\s+(.+)$','\n'.join(entries))
                ids=[int(i) for i,_ in choices if i!='0']
                self.assertEqual(ids,list(range(1,len(ids)+1)),f'{method}: {ids}')
                self.assertEqual(set(map(str,ids)),set(handlers),method)
                self.assertEqual([k for k,_ in choices if k=='0'],['0'],method)
                self.assertTrue(title)
                if menu.call_args.args[3:] and menu.call_args.args[3] is not None:
                    briefs=menu.call_args.args[3]
                    self.assertEqual(set(briefs),set(map(str,ids)),method)
                    for key,val in briefs.items():
                        self.assertTrue(len(val[1])>20,(method,key))

    def test_gray_descriptions_for_every_option(self):
        for method in SUBMENUS:
            with self.subTest(method=method):
                options_record=[]
                def get_menu(title,options,**kw):
                    options_record.extend(options)
                    return '0'
                with mock.patch.object(gs,'menu_sub',side_effect=get_menu):
                    # no commands run: menu ends at 0
                    getattr(gs,method)()
                rows=options_record
                for i,txt in enumerate(rows):
                    m=re.match(r'^\s*\[(\d+)\]',str(txt))
                    if not m:continue
                    self.assertGreater(len(rows[i+1].strip()),12,(method,txt))
                    self.assertFalse(rows[i+1].lstrip().startswith('['),(method,txt))

    def test_blackout_one_screen_and_full_guide(self):
        with mock.patch.object(gs,'persistent_menu') as m:gs.sub_blackout()
        title,options,actions,briefs=m.call_args.args
        body='\n'.join(options)
        self.assertLessEqual(len(options),30)
        self.assertIn('WHAT CHANGES',body)
        self.assertIn('HOW UNDO WORKS',body)
        self.assertEqual(set(actions),{'1','2','3','4'})
        info=gs.submenu_guide(title,options,briefs)
        for term in ('webcam','firewall','services','logs','[1]','[4]'):
            self.assertIn(term.lower(),info.lower())

    def test_restore_removed_mac_spoof_and_theme(self):
        with mock.patch.object(gs,'persistent_menu') as m:gs.sub_restore()
        content='\n'.join(m.call_args.args[1]).lower()
        self.assertNotIn('mac profile',content)
        self.assertNotIn('theme',content)
        self.assertEqual(set(m.call_args.args[2]),{'1','2'})
        self.assertTrue(all('theme' not in f for _,f in startup_settings.OTHER_BACKUPS))

    def test_main_layout_fits_width_without_dropped_options(self):
        for width in (54,70,80,100,120):
            with self.subTest(columns=width):
                out=io.StringIO()
                with mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((width,35))),\
                     contextlib.redirect_stdout(out):
                    gs.ui('MAIN MENU',gs.main_menu_options(),None)
                shown=out.getvalue()
                for n in range(1,20):
                    self.assertEqual(len(re.findall(r'\['+str(n)+r'\]\s+',shown)),1,(n,width))
                for line in shown.splitlines():
                    self.assertLessEqual(len(re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', line)),width,(width,line))

    def test_purple_gs_styling_inside_white_labels(self):
        with mock.patch.object(gs,'COLOR_ON',True):
            rendered=gs.paint('GS BlackOut',gs.WHITE)
            self.assertIn(gs.PURPLE+'GS',rendered)
            self.assertIn(gs.RESET+gs.WHITE,rendered)

    def test_bugout_menu_and_no_quick_mode(self):
        with mock.patch.object(gs,'persistent_menu') as m:gs.sub_bugout()
        title,options,actions,briefs=m.call_args.args
        self.assertEqual(set(actions),{'1','2'})
        self.assertIn('3-second countdown','\n'.join(options))
        self.assertNotIn('Quick BugOut','\n'.join(options))
        self.assertIn('preview',briefs['2'][1].lower())

    def test_all_shell_scripts_parse(self):
        for script in ROOT.glob('*.sh'):
            with self.subTest(file=script.name):
                p=subprocess.run(['bash','-n',str(script)],capture_output=True,text=True)
                self.assertEqual(p.returncode,0,p.stderr)

    def test_restore_cancel_not_reported_as_success(self):
        with mock.patch.object(gs,'cmd_run',return_value=10),\
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot') as snapshot:
            self.assertIn('cancelled',gs.restore_all().lower())
            snapshot.assert_not_called()

    def test_restore_steps_use_distinct_sequence_numbers(self):
        source=(ROOT/'restore-all.sh').read_text()
        for number in range(1,5):
            self.assertIn(f'[{number}]',source)
        self.assertIn("exit 10; fi",source)

    def test_explorer_numbers_do_not_conflict_with_file_rows(self):
        with mock.patch.object(explorer,'BROWSER_PAGE_SIZE',10):
            self.assertEqual(explorer.BROWSER_PAGE_SIZE,10)
        # Browser menu action keys start at 11, file keys end at 10.
        content=Path(explorer.__file__).read_text()
        self.assertIn('[11] Next page',content)
        self.assertIn('[19]',content)
        self.assertIn('page * BROWSER_PAGE_SIZE',content)

if __name__=='__main__':unittest.main()
