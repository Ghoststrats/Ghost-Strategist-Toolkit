"""V66: BlackOut-only recovery boundaries and exact creator message playback."""
import contextlib
import io
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import gs
import easter_eggs

class V66BlackoutAndEasterTests(unittest.TestCase):
    def test_new_name_and_route(self):
        self.assertEqual(gs.MAIN_SECTIONS[-1][1][-1], ('19', 'Turn It All On'))
        with mock.patch.object(gs,'explained_menu') as menu:
            gs.sub_restore()
        self.assertEqual(set(menu.call_args.args[4]), {'1','2'})
        self.assertIs(menu.call_args.args[4]['2'],gs.restore_all)
        self.assertNotIn('DHCP identity',str(menu.call_args.args[4]))

    def test_undo_requires_blackout_session_not_initial_baseline(self):
        with tempfile.TemporaryDirectory() as tmp:
            env={**os.environ, 'XDG_STATE_HOME':tmp, 'NO_COLOR':'1'}
            # Legacy initial snapshot must not count as a GS BlackOut session.
            state=Path(tmp)/'ghost-strategist-tool'
            state.mkdir()
            (state/'blackout-devices-v23.tsv').write_text('WIFI|enabled\n')
            result=subprocess.run(['bash',str(ROOT/'restore-all.sh')],
                                  env=env,input='y\n',text=True,capture_output=True,timeout=8)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('Nothing will be changed',result.stdout)
            self.assertTrue((state/'blackout-devices-v23.tsv').exists())

    def test_blackout_restore_does_not_undo_independent_backups(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);state=(base/'state'/'ghost-strategist-tool');state.mkdir(parents=True)
            # Copy entry script; simulate child tools using harmless mock sh files.
            shutil.copy2(ROOT/'restore-all.sh',base/'restore-all.sh')
            log=base/'actions.txt'
            for name in ('device-controls.sh','gs-port-lockdown.sh',
                         'remote-lockdown.sh','blackout-extra.sh'):
                script=base/name
                script.write_text('#!/bin/bash\necho "'+name+' $*" >> "$GS_FAKE_LOG"\n')
            (state/'blackout-session-v66.tsv').write_text(
                'WIFI|enabled\nMIC_MUTE|no\n'
                'REMOTE_PREEXIST|yes\nPORT_PREEXIST|yes\nEXTRA_PREEXIST|yes\n')
            # Even if standalone backups exist, we must not touch them.
            for name in ('remote-lockdown-state.tsv','port-lockdown-v22.state','blackout-extra-v47.tsv'):
                (state/name).write_text('original')
            env={**os.environ,'XDG_STATE_HOME':str(base/'state'),'GS_FAKE_LOG':str(log)}
            p=subprocess.run(['bash',str(base/'restore-all.sh')],input='y\n',env=env,
                             text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,0,p.stdout+p.stderr)
            self.assertEqual(log.read_text().strip(), 'device-controls.sh restore')
            self.assertFalse((state/'blackout-session-v66.tsv').exists())
            for name in ('remote-lockdown-state.tsv','port-lockdown-v22.state','blackout-extra-v47.tsv'):
                self.assertEqual((state/name).read_text(),'original')

    def test_restore_cancel_does_not_run_commands(self):
        with tempfile.TemporaryDirectory() as tmp:
            state=Path(tmp)/'ghost-strategist-tool';state.mkdir()
            path=state/'blackout-session-v66.tsv'
            path.write_text('WIFI|enabled\nMIC_MUTE|no\nREMOTE_PREEXIST|no\n'
                            'PORT_PREEXIST|no\nEXTRA_PREEXIST|no\n')
            env={**os.environ,'XDG_STATE_HOME':tmp}
            p=subprocess.run(['bash',str(ROOT/'restore-all.sh')],input='n\n',env=env,
                             text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,10,p.stdout+p.stderr)
            self.assertTrue(path.exists())

    def test_secret_trigger_and_manifesto_exact_passages(self):
        self.assertTrue(easter_eggs.is_manifesto_command(' SAFETY IS AN ILLUSION '))
        self.assertFalse(easter_eggs.is_manifesto_command('safety is an illusion; shutdown'))
        self.assertTrue(easter_eggs.MANIFESTO.startswith('SAFETY IS AN ILLUSION.'))
        self.assertIn('Compliance is not reliance.',easter_eggs.MANIFESTO)
        self.assertIn('BECAUSE THE MOST DANGEROUS MOMENT',easter_eggs.MANIFESTO)
        self.assertTrue(easter_eggs.MANIFESTO.endswith('— **GhostStrats**'))
        self.assertEqual(easter_eggs.MANIFESTO.count('IT\'S WHEN THE SYSTEM STOPS WATCHING'),1)

    def test_noninteractive_letter_by_letter_screen_clears_without_side_effects(self):
        output=io.StringIO()
        with mock.patch.dict(os.environ, {'GHOSTSTRAT_TEST_MODE':'1'}), \
             mock.patch('subprocess.run',side_effect=AssertionError('no OS command')):
            easter_eggs.play_manifesto(stream=output,input_stream=io.StringIO(),
                                       delay=0,sleeper=lambda t:None)
        self.assertTrue(output.getvalue().startswith('\033[2J\033[H'))
        self.assertIn('A Message from GhostStrats',output.getvalue())
        self.assertIn('IT\'S WHEN THE SYSTEM STOPS WATCHING',output.getvalue())

    def test_more_verses_and_channel_link(self):
        for phrase in ('psalm461','isaiah4110','john832','2timothy17',
                       '1thessalonians521','romans1218','joshua19'):
            result=[]
            self.assertTrue(easter_eggs.run(phrase,out=result.append,color=False))
            self.assertIn('KJV',' '.join(result))
        lines=[]
        self.assertTrue(easter_eggs.run('youtube',out=lines.append,color=False))
        self.assertIn('https://www.youtube.com/@GhostStrats',' '.join(lines))

    def test_main_picks_manifesto_before_normal_eggs(self):
        with mock.patch.object(gs.os,'geteuid',return_value=1000),\
             mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True),\
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'),\
             mock.patch.object(gs,'menu_sub',side_effect=['safety is an illusion',None]),\
             mock.patch.object(easter_eggs,'play_manifesto') as animate,\
             mock.patch.object(gs,'wait_for_continue'),\
             contextlib.redirect_stdout(io.StringIO()):
            gs.main()
        animate.assert_called_once()

class V66ActivationSafetyTests(unittest.TestCase):
    def test_wrapper_uses_separate_activation_snapshot_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            shutil.copy2(ROOT/'blackout-control.sh',base/'blackout-control.sh')
            (base/'device-controls.sh').write_text(
                '#!/bin/bash\n'
                'echo "${GS_BLACKOUT_DEVICE_STATE}|$*" >> "$GS_FAKE_LOG"\n')
            state=base/'state'/'ghost-strategist-tool'
            state.mkdir(parents=True)
            log=base/'log'
            env={**os.environ, 'XDG_STATE_HOME':str(base/'state'),'GS_FAKE_LOG':str(log)}
            p=subprocess.run(['bash',str(base/'blackout-control.sh'),'apply'],
                             env=env,text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,0,p.stdout+p.stderr)
            self.assertIn('blackout-session-v66.tsv|ghost',log.read_text())
            (state/'blackout-session-v66.tsv').write_text('PREVIOUS SESSION')
            p=subprocess.run(['bash',str(base/'blackout-control.sh'),'apply'],
                             env=env,text=True,capture_output=True,timeout=8)
            self.assertNotEqual(p.returncode,0)
            self.assertEqual(len(log.read_text().splitlines()),1)
            self.assertEqual((state/'blackout-session-v66.tsv').read_text(),'PREVIOUS SESSION')

    def test_remains_safe_for_unrecognized_easter_egg_input(self):
        commands=('safety is an illusion ; rm -rf /','youtube; sudo shutdown',
                  'psalm461 rm -rf','turn everything back on')
        for command in commands:
            self.assertFalse(easter_eggs.is_manifesto_command(command))
            self.assertFalse(easter_eggs.run(command,out=lambda x:None,color=False))
