"""V65 two-column dashboard: labels only, no inline summaries."""
import contextlib
import io
import os
import re
import unittest
from unittest import mock
import gs

ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')


class CompactMenuTests(unittest.TestCase):
    def capture(self, columns, *, color=False):
        output = io.StringIO()
        with mock.patch.object(gs.shutil, 'get_terminal_size', return_value=os.terminal_size((columns,24))), \
             mock.patch.object(gs, 'COLOR_ON', color), contextlib.redirect_stdout(output):
            gs.ui('MAIN MENU', gs.main_menu_options(), None, show_nullout=True)
            row = gs.COUNT_ROW
        return ANSI.sub('',output.getvalue()), row

    def test_compact_two_columns_fit_24_lines(self):
        for columns in (40,48,54,60,70,80,100,120):
            with self.subTest(columns=columns):
                text, status_row = self.capture(columns)
                rows = text.splitlines()
                self.assertLessEqual(len(rows),24)
                self.assertLessEqual(max(map(len,rows)),columns)
                self.assertGreaterEqual(status_row,1)
                self.assertLess(status_row,len(rows))
                self.assertIn('GS NullOut: INACTIVE',rows[status_row-1])

    def test_two_columns_have_all_options_once(self):
        for columns in (40,80,100):
            with self.subTest(columns=columns):
                output,_=self.capture(columns)
                menu='\n'.join(row for row in output.splitlines() if '│' in row)
                numbers=list(map(int,re.findall(r'\[(\d+)\]\s',menu)))
                self.assertEqual(sorted(x for x in numbers if x != 0),list(range(1,20)))
                self.assertIn('[4]',menu)
                self.assertIn('[18]',menu)
                self.assertTrue(any('[1]' in r and '[7]' in r for r in menu.splitlines()))
                self.assertTrue(any('[11]' in r and '[16]' in r for r in menu.splitlines()))

    def test_gs_category_and_custom_header(self):
        result,_=self.capture(80)
        self.assertEqual(result.count('GHOSTSTRATS TOOLS'),1)
        self.assertIn('PRIVACY / SAFETY IS AN ILLUSION',result)
        self.assertIn('STRICTLY FOR EDUCATIONAL PURPOSES ONLY',result)
        self.assertIn('[H] HELP & WALKTHROUGHS',result)
        self.assertIn('Ghost Strategist Toolkit',result)

    def test_no_inline_notes_and_purple_gs_is_retained(self):
        raw=io.StringIO()
        with mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((100,24))), \
             mock.patch.object(gs,'COLOR_ON',True),contextlib.redirect_stdout(raw):
            gs.ui('MAIN MENU',gs.main_menu_options(),None,show_nullout=False)
        self.assertIn(gs.PURPLE+'GS'+gs.RESET+gs.WHITE,raw.getvalue())
        self.assertNotIn('Cleanup + exit',raw.getvalue())
        self.assertNotIn('Privacy controls',raw.getvalue())
        self.assertNotIn('Network status',raw.getvalue())

    def test_all_routes_stay_numbered(self):
        self.assertEqual([int(k) for _,entries in gs.MAIN_SECTIONS for k,_ in entries],list(range(1,20)))
        self.assertEqual(gs.MAIN_SECTIONS[0][0],'GHOSTSTRATS TOOLS')
        self.assertEqual(dict(gs.MAIN_SECTIONS[0][1])['4'],'GS BugOut')


if __name__=='__main__':
    unittest.main()
