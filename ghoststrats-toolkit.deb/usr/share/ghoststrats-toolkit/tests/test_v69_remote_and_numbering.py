"""V69 UI updates and remote-access recovery: no real system changes."""
import contextlib
import io
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import gs

ROOT = Path(__file__).resolve().parents[1]

class MainMenuV69(unittest.TestCase):
    def test_all_19_routes_and_help_fallback(self):
        mapping = {
            1:'sub_blackout',2:'sub_nullout',3:'sub_threat',4:'sub_bugout',
            5:'sub_network_intelligence',6:'launch_drone_detector',
            7:'sub_scanning',8:'sub_network_shortcuts',9:'run_python',
            10:'sub_network',11:'sub_radios',12:'sub_peripherals',
            13:'sub_mac',14:'sub_firewall',15:'sub_remote',
            16:'sub_persistence',17:'sub_task',18:'sub_overview',19:'sub_restore'
        }
        rows=[(int(n),label) for _,section in gs.MAIN_SECTIONS for n,label in section]
        self.assertEqual([n for n,_ in rows],list(range(1,20)))
        self.assertNotIn('Toolkit Diagnostics',str(gs.MAIN_SECTIONS))
        for number,function in mapping.items():
            with self.subTest(number=number),contextlib.ExitStack() as stack:
                calls={key:stack.enter_context(mock.patch.object(gs,key)) for key in set(mapping.values())}
                stack.enter_context(mock.patch.object(gs.os,'geteuid',return_value=1000))
                stack.enter_context(mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True))
                stack.enter_context(mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'))
                stack.enter_context(mock.patch.object(gs,'menu_sub',side_effect=[str(number),None]))
                with contextlib.redirect_stdout(io.StringIO()):gs.main()
                calls[function].assert_called_once()
                if number==9:self.assertEqual(calls[function].call_args.args[0],'gs_file_explorer.py')
        with mock.patch.object(gs,'persistent_menu') as menu:
            gs.sub_help()
        self.assertIn('7',menu.call_args.args[2])

    def test_remote_menu_is_action_first_and_recovery_notice_is_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            state=Path(tmp)/'ghost-strategist-tool'
            state.mkdir()
            with mock.patch.dict(os.environ, {'XDG_STATE_HOME': tmp}),\
                 mock.patch.object(gs,'persistent_menu') as renderer:
                gs.sub_remote()
                title, body, actions, briefs=renderer.call_args.args
                self.assertIn('NO PENDING BACKUP','\n'.join(body))
                self.assertIn('WHAT WOULD YOU LIKE TO DO?',body)
                self.assertNotIn('PURPOSE',body)
                self.assertEqual(set(actions),{'1','2','3','4'})
                self.assertEqual(set(briefs),set(actions))
                self.assertTrue(all(len(description)>45 for _,description in briefs.values()))
                (state/'remote-lockdown-state.tsv').write_text('saved')
                gs.sub_remote()
                self.assertIn('BACKUP PENDING','\n'.join(renderer.call_args.args[1]))
                (state/'blackout-session-v66.tsv').write_text('saved')
                gs.sub_remote()
                self.assertIn('Turn It All On','\n'.join(renderer.call_args.args[1]))

    def test_remote_action_messages_distinguish_readonly_previous_state_and_failure(self):
        for action,code,expected in (
            ('status',0,'read only'),('apply',3,'NOT APPLIED'),
            ('restore',2,'NOTHING TO RESTORE'),('apply',10,'Cancelled'),
            ('apply',1,'INCOMPLETE'),('restore',0,'Restore finished')):
            with self.subTest(action=action,code=code),mock.patch.object(gs,'cmd_run',return_value=code):
                self.assertIn(expected,gs.remote_do(action))

class RemoteScriptV69(unittest.TestCase):
    def test_saved_state_refuses_apply_before_confirmation_or_system_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            home=Path(tmp)
            state=home/'ghost-strategist-tool';state.mkdir()
            backup=state/'remote-lockdown-state.tsv'
            backup.write_text('FIREWALL|inactive|ACCEPT\n')
            p=subprocess.run(['bash',str(ROOT/'remote-lockdown.sh'),'apply'],
                             env={**os.environ,'XDG_STATE_HOME':tmp,'NO_COLOR':'1'},
                             input='',text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,3,p.stdout+p.stderr)
            self.assertIn('NOT APPLIED',p.stdout)
            self.assertIn('Choose [3]',p.stdout)
            self.assertNotIn('Apply remote lockdown?',p.stdout)
            self.assertEqual(backup.read_text(),'FIREWALL|inactive|ACCEPT\n')

    def test_blackout_backup_points_to_correct_undo(self):
        with tempfile.TemporaryDirectory() as tmp:
            state=Path(tmp)/'ghost-strategist-tool';state.mkdir()
            (state/'remote-lockdown-state.tsv').write_text('present')
            (state/'blackout-session-v66.tsv').write_text('present')
            p=subprocess.run(['bash',str(ROOT/'remote-lockdown.sh'),'apply'],
                             env={**os.environ,'XDG_STATE_HOME':tmp,'NO_COLOR':'1'},
                             input='',text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,3)
            self.assertIn('[19] Turn It All On',p.stdout)

    def test_no_snapshot_restoration_is_clear_and_does_not_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=subprocess.run(['bash',str(ROOT/'remote-lockdown.sh'),'restore'],
                             env={**os.environ,'XDG_STATE_HOME':tmp,'NO_COLOR':'1'},
                             input='',text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,2,p.stdout+p.stderr)
            self.assertIn('Nothing was changed',p.stdout)

if __name__ == '__main__':unittest.main()

class RestoreOwnershipV69(unittest.TestCase):
    def test_direct_restore_does_not_bypass_blackout_owner(self):
        with tempfile.TemporaryDirectory() as tmp:
            state=Path(tmp)/'ghost-strategist-tool';state.mkdir()
            (state/'remote-lockdown-state.tsv').write_text('FIREWALL|inactive|ACCEPT\n')
            (state/'blackout-session-v66.tsv').write_text('RECORD')
            p=subprocess.run(['bash',str(ROOT/'remote-lockdown.sh'),'restore'],
                             env={**os.environ,'XDG_STATE_HOME':tmp,'NO_COLOR':'1'},
                             input='',text=True,capture_output=True,timeout=8)
            self.assertEqual(p.returncode,3)
            self.assertIn('[19] Turn It All On',p.stdout)
            self.assertTrue((state/'remote-lockdown-state.tsv').exists())
