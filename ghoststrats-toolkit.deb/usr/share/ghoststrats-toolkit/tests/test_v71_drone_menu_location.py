"""V71: GS Drone Detector belongs to GhostStrats Tools; older routes stay unchanged."""
import contextlib
import io
from unittest import TestCase, mock
import gs

class DroneMenuLocationTests(TestCase):
    def test_single_ghoststrats_entry_and_no_discovery_duplicate(self):
        title, entries = gs.MAIN_SECTIONS[0]
        self.assertEqual(title, 'GHOSTSTRATS TOOLS')
        self.assertEqual(dict(entries)['6'], 'GS Drone Detector')
        all_entries = [(k, label) for _, rows in gs.MAIN_SECTIONS for k, label in rows]
        self.assertEqual(sum(label=='GS Drone Detector' for _, label in all_entries), 1)
        self.assertEqual(sorted(int(k) for k, _ in all_entries), list(range(1,20)))
        with mock.patch.object(gs, 'persistent_menu') as capture:
            gs.sub_scanning()
        self.assertEqual(set(capture.call_args.args[2]), set('123456'))
        self.assertNotIn('GS Drone Detector', '\n'.join(capture.call_args.args[1]))

    def test_new_main_selection_calls_existing_launcher(self):
        with mock.patch.object(gs.os, 'geteuid', return_value=1000), \
             mock.patch.object(gs.sys.stdin, 'isatty', return_value=True, create=True), \
             mock.patch.object(gs.startup_settings, 'ensure_initial_snapshot', return_value='SAVED'), \
             mock.patch.object(gs, 'menu_sub', side_effect=['6', None]), \
             mock.patch.object(gs, 'launch_drone_detector', return_value='OK') as launcher, \
             contextlib.redirect_stdout(io.StringIO()):
            gs.main()
        launcher.assert_called_once_with()

    def test_new_selection_seven_opens_original_discovery_menu(self):
        with mock.patch.object(gs.os, 'geteuid', return_value=1000), \
             mock.patch.object(gs.sys.stdin, 'isatty', return_value=True, create=True), \
             mock.patch.object(gs.startup_settings, 'ensure_initial_snapshot', return_value='SAVED'), \
             mock.patch.object(gs, 'menu_sub', side_effect=['7', None]), \
             mock.patch.object(gs, 'sub_scanning') as discovery, \
             mock.patch.object(gs, 'launch_drone_detector') as drone, \
             contextlib.redirect_stdout(io.StringIO()):
            gs.main()
        discovery.assert_called_once_with()
        drone.assert_not_called()
