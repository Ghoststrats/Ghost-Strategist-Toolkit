"""V39: reproduce regressions and test new reliability behavior without hardware changes."""
from __future__ import annotations
import contextlib
import io
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import diagnostics
import persistence_privacy
import gs
import scanning
import importlib.util
spec=importlib.util.spec_from_file_location('threat_analysis',ROOT/'threat-analysis.py')
threat=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=threat
spec.loader.exec_module(threat)

class V39Tests(unittest.TestCase):
    def test_command_wait_calls_nullout_even_while_child_is_running(self):
        with mock.patch.object(gs,'armed',True), mock.patch.object(gs,'remaining',return_value=12) as timer:
            with contextlib.redirect_stdout(io.StringIO()):
                code=gs.cmd_run([sys.executable,'-c','import time;time.sleep(1.15)'])
        self.assertEqual(code,0)
        self.assertGreaterEqual(timer.call_count,1)

    def test_command_error_is_reported(self):
        self.assertNotEqual(gs.cmd_run([sys.executable,'-c','import sys;sys.exit(7)']),0)

    def test_network_status_errors_not_reported_as_success(self):
        with mock.patch.object(gs,'explained_menu') as menu:
            gs.sub_network()
        handlers=menu.call_args.args[4]
        with mock.patch.object(gs,'cmd_run',return_value=1):
            self.assertIn('unavailable',handlers['2']())
        with mock.patch.object(gs,'cmd_run',return_value=0):
            self.assertIn('displayed',handlers['2']())

    def test_system_overview_mixed_failure(self):
        with mock.patch.object(gs,'cmd_run',side_effect=[0,0,127,0]):
            self.assertIn('unavailable',gs.print_sys())

    def test_readonly_diagnostics_can_check_sources_and_report_limits(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder)
            (base/'good.py').write_text('x=1\n')
            (base/'broken.py').write_text('def broken(:\n')
            (base/'good.sh').write_text('echo ok\n')
            good, warning, errors=diagnostics.inspection(base,lambda c:'/usr/bin/'+c)
            self.assertTrue(any('good.py: OK' in g for g in good))
            self.assertTrue(any('broken.py: ERROR' in e for e in errors))
            self.assertIsInstance(warning,list)

    def test_diagnostics_help_is_integrated_without_new_main_number(self):
        with mock.patch.object(gs,'persistent_menu') as run:
            gs.sub_help()
        menu='\n'.join(run.call_args.args[1])
        self.assertIn('[7] Toolkit Diagnostics',menu)
        self.assertIs(run.call_args.args[2]['7'],diagnostics.run)
        self.assertEqual(sum('[3]' in k for k in gs.main_menu_options()),1)

    def test_scan_port_results_on_real_localhost_and_order(self):
        with socket.socket() as srv:
            srv.bind(('127.0.0.1',0)); srv.listen(1)
            port=srv.getsockname()[1]
            with mock.patch.object(scanning,'COMMON_PORTS',{port:'Temporary local listener'}):
                output=io.StringIO()
                with contextlib.redirect_stdout(output):
                    scanning.tcp_scan()
            self.assertIn(str(port)+'/tcp',output.getvalue())
            self.assertIn('OPEN',output.getvalue())

    def test_long_output_is_bounded_with_caveat(self):
        fake=mock.Mock(returncode=0,stdout='\n'.join('Entry '+str(i) for i in range(170)))
        with mock.patch.object(scanning.shutil,'which',return_value='/bin/yes'),\
             mock.patch.object(scanning.subprocess,'run',return_value=fake),\
             contextlib.redirect_stdout(io.StringIO()) as out:
            scanning.run_tool(['nmcli','device','status'])
        self.assertIn('10 additional rows omitted',out.getvalue())
        self.assertNotIn('Entry 169\n',out.getvalue())

    def test_tcp_udp_same_port_are_separate_findings(self):
        ports=[('tcp','0.0.0.0',22,'ALL INTERFACES'),('udp','0.0.0.0',22,'ALL INTERFACES')]
        findings=threat.risk_for_ports(ports,'INACTIVE')
        self.assertEqual(len(findings),2)
        self.assertIn('TCP',findings[0].title)
        self.assertIn('UDP',findings[1].title)

    def test_threat_wifi_query_runs_only_once(self):
        calls=[]
        def runner(cmd):
            calls.append(tuple(cmd))
            return (None,'not installed')
        threat.run_audit(run=runner)
        self.assertEqual(calls.count(('nmcli','radio','wifi')),1)

    def test_backup_snapshot_exclusive_creation_is_used(self):
        for filename in ('device-controls.sh','remote-lockdown.sh','gs-port-lockdown.sh'):
            source=(ROOT/filename).read_text()
            self.assertIn('ln -- "$tmp" "$STATE"',source,filename)
            self.assertNotIn('mv -n',source,filename)
            result=subprocess.run(['bash','-n',str(ROOT/filename)],capture_output=True)
            self.assertEqual(result.returncode,0)

    def test_bluetooth_enable_checks_unblock_and_controller_power(self):
        # Replace *all* hardware utilities with harmless local mocks.
        with tempfile.TemporaryDirectory() as temp:
            binpath=Path(temp)
            rfkill=binpath/'rfkill'
            bluetooth=binpath/'bluetoothctl'
            logfile=binpath/'commands.log'
            rfkill.write_text('#!/bin/sh\necho "rfkill:$*" >> "$FAKE_LOG"\n'
                              'if [ "$1" = list ]; then echo "Soft blocked: no"; fi\n')
            bluetooth.write_text('#!/bin/sh\necho "bluetoothctl:$*" >> "$FAKE_LOG"\n'
                                 'if [ "$1" = show ]; then echo " Powered: yes"; fi\n')
            rfkill.chmod(0o755);bluetooth.chmod(0o755)
            env=os.environ.copy()
            env.update(PATH=str(binpath)+':'+env.get('PATH',''),FAKE_LOG=str(logfile))
            command=['bash',str(ROOT/'device-controls.sh'),'bluetooth','on']
            proc=subprocess.run(command,env=env,capture_output=True,text=True,timeout=4)
            self.assertEqual(proc.returncode,0,proc.stderr+proc.stdout)
            calls=logfile.read_text()
            self.assertIn('rfkill:unblock bluetooth',calls)
            self.assertIn('bluetoothctl:power on',calls)
            self.assertIn('bluetoothctl:show',calls)

