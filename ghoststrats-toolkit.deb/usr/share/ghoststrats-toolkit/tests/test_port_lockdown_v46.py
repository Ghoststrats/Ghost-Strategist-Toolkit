"""UFW command regression tests with a fake sudo/ufw; NEVER edit the host firewall."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'gs-port-lockdown.sh'
PORTS = ('21/tcp', '22/tcp', '23/tcp', '111/tcp', '135/tcp',
         '139/tcp', '445/tcp', '2049/tcp', '3389/tcp', '5900:5910/tcp')
FAKE_SUDO = r'''#!/usr/bin/python3
import json, os, pathlib, sys
p=pathlib.Path(os.environ['MOCK_UFW_STATE'])
s=json.loads(p.read_text())
a=sys.argv[1:]
if a and a[0]=='-n':a=a[1:]
if a == ['-v']:sys.exit(0)
if not a or a[0]!='ufw':sys.exit(12)
a=a[1:]
s.setdefault('calls',[]).append(a)
def save():p.write_text(json.dumps(s))
if a[:1]==['status']:
    if len(a)>1 and a[1]=='numbered':
        print('Status: active' if s['active'] else 'Status: inactive')
        for i,(port,tag) in enumerate(s['rules'],1):
            print(f'[ {i}] {port} DENY IN Anywhere # {tag}')
    else:print('Status: active' if s['active'] else 'Status: inactive')
    save();sys.exit(0)
if a[:2]==['--force','enable']:s['active']=True;save();sys.exit(0)
if a[:2]==['--force','disable']:s['active']=False;save();sys.exit(0)
if a[:2]==['--force','delete']:
    n=int(a[2])-1
    if n<0 or n>=len(s['rules']):sys.exit(4)
    s['rules'].pop(n);save();sys.exit(0)
if a[:2]==['insert','1']:
    if not s['rules']:
        print("ERROR: Invalid position '1'")
        save();sys.exit(1)
    # Insert-all rule. Ordinary deny in cases tested separately.
    s['rules'].insert(0,('Anywhere','GST_PORT_ALL_V22'))
    save();sys.exit(0)
if a and a[0]=='deny':
    if 'comment' not in a:save();sys.exit(8)
    tag=a[a.index('comment')+1]
    if 'from' in a:port='Anywhere'
    else:port=a[2] # deny in 21/tcp comment TAG
    if port==os.environ.get('MOCK_UFW_FAIL_PORT'):
        save();sys.exit(5)
    s['rules'].append((port,tag));save();sys.exit(0)
save();print('UNEXPECTED:',a,file=sys.stderr);sys.exit(7)
'''

class PortLockdownTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        d=Path(self.tmp.name)
        (d/'bin').mkdir()
        (d/'bin'/'sudo').write_text(FAKE_SUDO)
        (d/'bin'/'sudo').chmod(0o755)
        (d/'bin'/'ufw').write_text('#!/bin/sh\nexit 0\n')
        (d/'bin'/'ufw').chmod(0o755)
        self.db=d/'mock.json'
        self.db.write_text(json.dumps({'active':False,'rules':[],'calls':[]}))
        self.env={**os.environ, 'XDG_STATE_HOME':str(d/'state'),
                  'MOCK_UFW_STATE':str(self.db),
                  'PATH':str(d/'bin')+os.pathsep+os.environ['PATH'],
                  'NO_COLOR':'1'}

    def command(self,arg,answer='y\n',env=None):
        return subprocess.run(['bash',str(SCRIPT),arg],input=answer,text=True,
                              env=env or self.env,capture_output=True,timeout=10)

    def state(self):return json.loads(self.db.read_text())

    def test_empty_ruleset_common_ports_do_not_use_insert_and_verify(self):
        result=self.command('apply-common')
        self.assertEqual(result.returncode,0,result.stdout+'\n'+result.stderr)
        self.assertIn('Tagged deny rules verified: 10/10',result.stdout)
        s=self.state()
        self.assertTrue(s['active'])
        self.assertEqual([item[0] for item in s['rules']],list(PORTS))
        self.assertFalse(any(a[:1]==['insert'] for a in s['calls']))

    def test_partial_failure_returns_nonzero_with_explicit_warning(self):
        env={**self.env,'MOCK_UFW_FAIL_PORT':'22/tcp'}
        result=self.command('apply-common',env=env)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('FAILED to add 22/tcp',result.stdout)
        self.assertIn('INCOMPLETE port lockdown',result.stdout)
        self.assertIn('Tagged deny rules verified: 9/10',result.stdout)

    def test_block_all_with_empty_ruleset_uses_nonpositional_deny(self):
        # Override only the IPv6 environment probe, leaving the actual UFW
        # command branch under test. The mocked sudo never touches the host.
        source = str(SCRIPT)
        cmd = ('source <(sed \'/^case "${1:-menu}" in/,$d\' ' +
               source + '); check_ipv6_for_all(){ return 0; }; apply_all --confirmed')
        result = subprocess.run(['bash','-c',cmd],capture_output=True,text=True,
                                env=self.env,timeout=10)
        self.assertEqual(result.returncode,0,result.stdout+'\n'+result.stderr)
        self.assertFalse(any(a[:1]==['insert'] for a in self.state()['calls']))
        self.assertEqual(self.state()['rules'],[['Anywhere','GST_PORT_ALL_V22']])

    def test_common_rule_restore_removes_only_our_tags(self):
        first=self.command('apply-common')
        self.assertEqual(first.returncode,0,first.stdout)
        second=self.command('restore',answer='y\n')
        self.assertEqual(second.returncode,0,second.stdout)
        self.assertEqual(self.state()['rules'],[])
        self.assertFalse(self.state()['active'])

if __name__=='__main__':unittest.main()
