"""GS Drone Detector is bundled as a direct-start Turbo scanning tool."""
import hashlib
from pathlib import Path
import subprocess
import unittest
from unittest import mock

import gs

ROOT = Path(__file__).resolve().parents[1]


class DroneIntegration(unittest.TestCase):
    def test_menu_is_connected_without_changing_existing_routes(self):
        with mock.patch.object(gs, 'persistent_menu') as ui:
            gs.sub_scanning()
        actions=ui.call_args.args[2]
        self.assertEqual(set(actions),set('123456'))
        self.assertEqual(dict(gs.MAIN_SECTIONS[0][1])['6'], 'GS Drone Detector')
        self.assertEqual(sorted(int(k) for _,items in gs.MAIN_SECTIONS for k,_ in items),list(range(1,20)))

    def test_bundled_detector_matches_standalone_and_docs(self):
        self.assertTrue((ROOT/'gs-drone-detector.sh').is_file())
        self.assertTrue((ROOT/'GS_Drone_Detector_README.md').is_file())
        self.assertIn('GS Drone Detector', (ROOT/'README.md').read_text()[:300])

    def test_launch_returns_to_parent_menu(self):
        with mock.patch.object(gs.subprocess,'run',return_value=mock.Mock(returncode=0)) as invoke:
            msg=gs.launch_drone_detector()
        argv=invoke.call_args.args[0]
        self.assertEqual(argv,['bash',str(ROOT/'gs-drone-detector.sh'),'scan'])
        self.assertEqual(invoke.call_args.kwargs['cwd'],str(ROOT))
        self.assertIn('Returned to Ghost Strategist main menu',msg)

    def test_missing_detector_is_explained(self):
        with mock.patch.object(gs.Path,'is_file',return_value=False):
            self.assertIn('missing',gs.launch_drone_detector().lower())

    def test_independent_offline_decoder_test(self):
        cp=subprocess.run(['bash',str(ROOT/'gs-drone-detector.sh'),'test'],
                          capture_output=True,text=True,timeout=12)
        self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
        self.assertIn('SIMULATED SIGNALS ONLY',cp.stdout)
        self.assertIn('NO radio devices or drones were detected',cp.stdout)

    def test_default_launch_is_turbo_with_no_detector_menu(self):
        script=(ROOT/'gs-drone-detector.sh').read_text()
        self.assertNotIn('def menu():',script)
        self.assertNotIn('def ble_pair_helper():',script)
        cp=subprocess.run(['bash',str(ROOT/'gs-drone-detector.sh'),'scan',
                           '--no-wifi','--duration','1'],
                          capture_output=True,text=True,timeout=8)
        self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
        self.assertIn('TURBO LIVE',cp.stdout)


if __name__=='__main__':
    unittest.main()
