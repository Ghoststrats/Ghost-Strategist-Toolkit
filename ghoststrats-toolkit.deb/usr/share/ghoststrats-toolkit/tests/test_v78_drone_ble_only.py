"""GS v78: drone-only candidate filtering, BLE Remote ID, and consented pairing."""
import asyncio
import contextlib
import io
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT/'gs-drone-detector.sh').read_text()
BODY = SCRIPT.split('# GS_PYTHON_START\n',1)[1].split('\nGS_PYTHON_EOF',1)[0]
D=types.ModuleType('gs_drone_v78_test')
exec(compile(BODY,str(ROOT/'gs-drone-detector.sh'),'exec'),D.__dict__)


class DroneOnlyBLETests(unittest.TestCase):
    def args(self, *extra):
        return D.make_args(['scan','--plain',*extra])[1]

    def test_rc_car_and_unknown_do_not_match(self):
        for s in ('TRAXXAS-CAR-01','ARRMA X','RC-CAR','HomeWifi','Phone-99'):
            self.assertEqual(D.classify(s)[3],0)
        self.assertEqual(D.classify('DJI-NEO-TEST')[1],'drone')

    def test_non_drones_never_stored_even_at_max_signal(self):
        mon=D.Monitor(self.args('--no-wifi'))
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                for name in ('TRAXXAS CAR','OfficeWifi','Mobile Phone'):
                    mon.put('BLE',name,name,-35,'dBm')
                    mon.apply(mon.q.get_nowait())
            self.assertEqual(mon.devices,{})
            self.assertEqual(len(mon.events),0)
        finally:mon.close()

    def test_wifi_disable_does_not_disable_ble(self):
        args=self.args('--no-wifi')
        self.assertTrue(args.no_wifi)
        self.assertFalse(hasattr(args,'no_ble'))
        self.assertEqual(args.monitor,'')

    def test_ble_callback_filters_ordinary_and_decodes_remote_id(self):
        mon=D.Monitor(self.args('--no-wifi'))
        mon.end=0  # enter the scanner context, dispatch samples, no real waiting
        basic=bytes([0x02,0x12])+b'GS-BLE-TEST'.ljust(20,b'\0')+bytes(3)
        advs=[
            (types.SimpleNamespace(name='Smart Watch',address='AA:00:00:00:00:01'),
             types.SimpleNamespace(local_name='Smart Watch',rssi=-40, service_uuids=[],service_data={},manufacturer_data={},tx_power=None)),
            (types.SimpleNamespace(name='DJI-NEO-TEST',address='AA:00:00:00:00:02'),
             types.SimpleNamespace(local_name='DJI-NEO-TEST',rssi=-60, service_uuids=[],service_data={},manufacturer_data={23:b'foo'},tx_power=-12)),
            (types.SimpleNamespace(name=None,address='AA:00:00:00:00:03'),
             types.SimpleNamespace(local_name=None,rssi=-77,service_uuids=[D.ODID_UUID],service_data={D.ODID_UUID:b'\x0d\x01'+basic},manufacturer_data={},tx_power=None)),
        ]
        class FakeBleakScanner:
            def __init__(self,callback):self.cb=callback
            async def __aenter__(self):
                for dev,adv in advs:self.cb(dev,adv)
                return self
            async def __aexit__(self,*args):return False
        mock_bleak=types.ModuleType('bleak')
        mock_bleak.BleakScanner=FakeBleakScanner
        try:
            with mock.patch.dict(sys.modules,{'bleak':mock_bleak}):
                asyncio.run(mon.ble_loop())
            with contextlib.redirect_stdout(io.StringIO()):
                while not mon.q.empty():mon.apply(mon.q.get_nowait())
            self.assertEqual(len(mon.devices),2)
            self.assertNotIn('BLE:AA:00:00:00:00:01',mon.devices)
            ble=mon.devices['BLE:AA:00:00:00:00:02']
            self.assertEqual(ble['details']['ble_company_ids'],'0x0017')
            self.assertEqual(ble['details']['ble_tx_power_dbm'],-12)
            rid=mon.devices['BLE:AA:00:00:00:00:03']
            self.assertEqual(rid['confidence'],3)
            self.assertEqual(rid['details']['id'],'GS-BLE-TEST')
            self.assertEqual(rid['details']['rid_service_advertised'],True)
        finally:mon.close()

    def test_pairing_menu_is_removed_in_turbo_only_release(self):
        script=(ROOT/'gs-drone-detector.sh').read_text()
        self.assertNotIn('def ble_pair_helper():', script)
        self.assertNotIn('Pair/connect my OWN BLE drone', script)
        self.assertNotIn("args.command=='pair'", script)

    def test_rc_rules_from_old_custom_file_ignored(self):
        with mock.patch.object(D,'HOME',Path('/nonexistent/path-for-gs-drone-test')):
            self.assertEqual(D.custom_rules(),[])
        self.assertEqual(D.signal_advisory(-40,'dBm')['level'],'red')

if __name__=='__main__': unittest.main()
