"""V45 first-launch backups: mock hardware, verify no silent changes."""
from __future__ import annotations
import contextlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import gs
import startup_settings as initial


class StartupSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home=Path(self.temp.name)
        self.bin=self.home/'bin'
        self.bin.mkdir()
        self.statehome=self.home/'state'
        self.env={**os.environ, 'XDG_STATE_HOME':str(self.statehome),
                  'PATH':str(self.bin)+':'+os.environ.get('PATH',''),
                  'NO_COLOR':'1', 'FAKE_WIFI':'enabled', 'FAKE_WIFI_STATE_FILE':str(self.home/'wifi_state')}
        scripts={
            'nmcli':'case "$*" in "radio wifi") if [ -f "$FAKE_WIFI_STATE_FILE" ]; then cat "$FAKE_WIFI_STATE_FILE"; else echo "${FAKE_WIFI:-enabled}"; fi;; "radio wifi on") echo enabled > "$FAKE_WIFI_STATE_FILE";; "radio wifi off") echo disabled > "$FAKE_WIFI_STATE_FILE";; esac',
            'rfkill':'if [ "$1" = list ]; then echo "Soft blocked: no"; fi',
            'bluetoothctl':'if [ "$1" = show ]; then echo " Powered: yes"; fi',
            'pactl':'if [ "$1" = get-source-mute ]; then echo "Mute: no"; else echo "Mute: yes"; fi',
            'sudo': 'echo "FORBIDDEN" >> "$XDG_STATE_HOME/sudo_called"; exit 77',
        }
        for name,body in scripts.items():
            f=self.bin/name
            f.write_text('#!/bin/sh\n'+body+'\n')
            f.chmod(0o755)

    def snapshot(self, **extra):
        return subprocess.run(['bash',str(ROOT/'device-controls.sh'),'snapshot'],
                              env={**self.env,**extra},text=True,capture_output=True,timeout=8)

    def test_restoring_unchanged_devices_does_not_run_privileged_controls(self):
        with mock.patch.dict(os.environ,self.env):
            self.assertIn('SAVED',initial.ensure_initial_snapshot())
        result=subprocess.run(['bash',str(ROOT/'device-controls.sh'),'restore'],
                              env=self.env,text=True,capture_output=True,timeout=8)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertFalse((self.statehome/'sudo_called').exists())
        self.assertIn('already matches saved state',result.stdout)

    def test_changed_wifi_restores_first_saved_state_not_latest(self):
        with mock.patch.dict(os.environ,self.env):
            initial.ensure_initial_snapshot()
        changed={**self.env,'FAKE_WIFI':'disabled'}
        result=subprocess.run(['bash',str(ROOT/'device-controls.sh'),'restore'],
                              env=changed,text=True,capture_output=True,timeout=8)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertIn('Wi-Fi VERIFIED: enabled',result.stdout)
        with mock.patch.dict(os.environ,changed):
            self.assertEqual(initial.read_snapshot()['WIFI'],'enabled')

    def test_launch_style_snapshot_is_read_only_and_private(self):
        with mock.patch.dict(os.environ,self.env):
            result=initial.ensure_initial_snapshot()
            self.assertTrue(result.startswith('SAVED'),result)
            data=initial.read_snapshot()
            self.assertEqual(data['WIFI'],'enabled')
            self.assertEqual(data['MIC_MUTE'],'no')
            self.assertTrue(data['CAPTURED_AT'].endswith('Z'))
            self.assertFalse((self.statehome/'sudo_called').exists())
            f=initial.snapshot_path()
            self.assertEqual(f.stat().st_mode & 0o777,0o600)
            self.assertEqual(f.parent.stat().st_mode & 0o777,0o700)

    def test_second_launch_never_overwrites_original_even_if_settings_changed(self):
        with mock.patch.dict(os.environ,self.env):
            self.assertIn('SAVED',initial.ensure_initial_snapshot())
            old=initial.snapshot_path().read_bytes()
        with mock.patch.dict(os.environ,{**self.env,'FAKE_WIFI':'disabled'}):
            self.assertIn('preserved',initial.ensure_initial_snapshot())
            self.assertEqual(initial.snapshot_path().read_bytes(),old)
            self.assertEqual(initial.read_snapshot()['WIFI'],'enabled')

    def test_existing_bad_backup_not_overwritten(self):
        location=self.statehome/'ghost-strategist-tool'/'blackout-devices-v23.tsv'
        location.parent.mkdir(parents=True)
        location.write_text('broken\n')
        with mock.patch.dict(os.environ,self.env):
            result=initial.ensure_initial_snapshot()
        self.assertIn('WARNING',result)
        self.assertEqual(location.read_text(),'broken\n')

    def test_symlinked_backup_is_rejected(self):
        location=self.statehome/'ghost-strategist-tool'/'blackout-devices-v23.tsv'
        location.parent.mkdir(parents=True)
        target=self.home/'external.txt'
        target.write_text('keep original')
        location.symlink_to(target)
        with mock.patch.dict(os.environ,self.env):
            self.assertIn('WARNING',initial.ensure_initial_snapshot())
        self.assertEqual(target.read_text(),'keep original')

    def test_symlinked_state_directory_is_rejected(self):
        self.statehome.mkdir()
        target=self.home/'somewhere'
        target.mkdir()
        (self.statehome/'ghost-strategist-tool').symlink_to(target)
        with mock.patch.dict(os.environ,self.env):
            self.assertIn('WARNING',initial.ensure_initial_snapshot())
        self.assertFalse(any(target.iterdir()))

    def test_after_restore_clears_backup_next_capture_is_fresh(self):
        with mock.patch.dict(os.environ,self.env):
            initial.ensure_initial_snapshot()
            self.assertEqual(initial.read_snapshot()['WIFI'],'enabled')
            initial.snapshot_path().unlink()
        with mock.patch.dict(os.environ,{**self.env,'FAKE_WIFI':'disabled'}):
            self.assertIn('SAVED',initial.ensure_initial_snapshot())
            self.assertEqual(initial.read_snapshot()['WIFI'],'disabled')

    def test_preview_separates_existing_other_tool_backups(self):
        with mock.patch.dict(os.environ,self.env):
            initial.ensure_initial_snapshot()
            (initial.directory()/'remote-lockdown-state.tsv').write_text('private|not printed')
            message=initial.preview()
        self.assertIn('Wi-Fi radio',message)
        self.assertNotIn('Wi-Fi MAC profile',message)
        self.assertIn('Available',message)
        self.assertNotIn('not printed',message)

    def test_missing_dependencies_record_unknown_not_fake_results(self):
        env={**self.env,'PATH':'/usr/bin:/bin'}
        with mock.patch.dict(os.environ,env):
            result=initial.ensure_initial_snapshot()
            self.assertIn('SAVED',result)
            data=initial.read_snapshot()
        self.assertIn(data['WIFI'],('enabled','disabled','unknown'))

    def test_main_snapshots_before_rendering_home(self):
        events=[]
        with mock.patch.object(gs.os,'geteuid',return_value=1000),\
             mock.patch.object(gs.sys.stdin,'isatty',return_value=True),\
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',side_effect=lambda:events.append('capture') or 'SAVED'),\
             mock.patch.object(gs,'menu_sub',side_effect=lambda *a,**k:events.append('menu') or None):
            gs.main()
        self.assertEqual(events,['capture','menu'])

    def test_blackout_only_restore_never_recaptures_startup_baseline(self):
        with mock.patch.object(gs,'cmd_run',return_value=0),\
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED') as capture:
            self.assertIn('GS BlackOut recovery completed',gs.restore_all())
            capture.assert_not_called()
        with mock.patch.object(gs,'cmd_run',return_value=1),\
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot') as capture:
            self.assertIn('incomplete',gs.restore_all())
            capture.assert_not_called()

    def test_restore_submenu_has_preview_plus_independent_recovery(self):
        with mock.patch.object(gs,'explained_menu') as menu:
            gs.sub_restore()
        actions=menu.call_args.args[4]
        self.assertEqual(set(actions),set('12'))
        self.assertIs(actions['1'],gs.show_blackout_record)
        self.assertIs(actions['2'],gs.restore_all)
        self.assertNotIn(gs.ip_changer.restore_identity, actions.values())


if __name__=='__main__':unittest.main()
