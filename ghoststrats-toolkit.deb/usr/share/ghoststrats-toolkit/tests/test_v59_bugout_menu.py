"""V61: BugOut moved to number 4, preserving numerical main menu order."""
import contextlib
import io
import os
import re
import unittest
from unittest import mock
import gs

ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')


class BugOutVisibility(unittest.TestCase):
    def test_group_and_handler_do_not_move(self):
        title, choices = gs.MAIN_SECTIONS[0]
        self.assertEqual([k for k, _ in choices], ['1', '2', '3', '4', '5', '6'])
        self.assertIn(('4', 'GS BugOut'), choices)
        self.assertEqual(sorted(int(k) for _, items in gs.MAIN_SECTIONS for k, _ in items), list(range(1, 20)))

    def test_every_tool_visible_on_24_line_terminal(self):
        for columns in (40, 48, 54, 60, 70, 80, 100, 120):
            with self.subTest(columns=columns):
                output = io.StringIO()
                with mock.patch.object(gs.shutil, 'get_terminal_size', return_value=os.terminal_size((columns, 24))), contextlib.redirect_stdout(output):
                    gs.ui('MAIN MENU', gs.main_menu_options(), None, show_nullout=True)
                lines = ANSI.sub('', output.getvalue()).splitlines()
                self.assertLessEqual(len(lines), 24)  # No scrolling on a 24-line terminal
                self.assertTrue(any('[4]' in line and 'BugOut' in line for line in lines))
                # Options are read vertically in numeric order.
                menu_text = '\n'.join(line for line in lines if line.startswith('  │'))
                seen = [int(x) for x in re.findall(r'\[(\d+)\]\s+', menu_text) if x != '0']
                self.assertEqual(sorted(seen), list(range(1, 20)), (columns, seen))
                self.assertTrue(all(len(line) <= columns for line in lines))
                menu_lines = [line for line in lines if line.startswith('  │')]
                for number in range(1, 20):
                    self.assertEqual(sum(len(re.findall(r'\[' + str(number) + r'\]\s+', line)) for line in menu_lines), 1, number)

    def test_bugout_choice_opens_existing_submenu(self):
        with mock.patch.object(gs, 'persistent_menu') as menu:
            gs.sub_bugout()
        self.assertEqual(menu.call_args.args[0], 'GS BUGOUT')
        self.assertIn('1', menu.call_args.args[2])
        self.assertIn('2', menu.call_args.args[2])

    def test_hidden_eggs_do_not_activate_bugout(self):
        import easter_eggs
        messages = []
        self.assertTrue(easter_eggs.run('gsbugout', out=messages.append))
        self.assertTrue(any('No cleanup or shutdown was started' in message for message in messages))

if __name__ == '__main__':
    unittest.main()
