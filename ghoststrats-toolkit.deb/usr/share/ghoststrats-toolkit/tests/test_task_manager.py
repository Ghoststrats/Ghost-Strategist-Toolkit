"""Regression tests for V35's read-only Task Manager."""
import contextlib
import io
import subprocess
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gs
import task_manager


class TaskManagerTests(unittest.TestCase):
    def test_calls_read_only_ps_and_not_top(self):
        fake = subprocess.CompletedProcess(args=['ps'], returncode=0,
                stdout='PID USER STAT %CPU %MEM COMMAND\n21 mint S 2 1 demo\n', stderr='')
        with mock.patch.object(task_manager.subprocess,'run',return_value=fake) as run:
            lines, error = task_manager.fetch_processes()
        self.assertIsNone(error)
        self.assertIn('demo', '\n'.join(lines))
        self.assertEqual(run.call_args.args[0],
                         ['ps','-eo','pid,user,stat,pcpu,pmem,comm','--sort=-pcpu'])

    def test_readable_view_and_quit_keys(self):
        text = task_manager.display_snapshot(['PID USER STAT %CPU %MEM COMMAND',
                                               '21 mint S 2 1 demo'], live=True)
        self.assertIn('Press 0 or Q',text)
        self.assertIn('no',text.lower())
        self.assertIn('demo',text)

    def test_graceful_missing_ps(self):
        with mock.patch.object(task_manager.subprocess,'run',side_effect=FileNotFoundError('ps')):
            lines,error=task_manager.fetch_processes()
        self.assertEqual(lines,[])
        self.assertIn('Could not read', error)

    def test_snapshot_keeps_submenu_action(self):
        with mock.patch.object(task_manager,'fetch_processes',return_value=(['PID USER', '10 mint test'],None)):
            with contextlib.redirect_stdout(io.StringIO()) as out:
                result=task_manager.snapshot()
        self.assertIn('test',out.getvalue())
        self.assertEqual(result,'Process snapshot complete.')

    def test_menu_routes_to_integrated_live(self):
        with mock.patch.object(gs.task_manager, 'live',return_value='Viewer exited') as live:
            self.assertEqual(gs.task_view(),'Viewer exited')
        self.assertEqual(live.call_args.args[0], gs.remaining)


if __name__ == '__main__':
    unittest.main()
