"""Safety regression checks for GS BugOut. All production effects mocked."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bugout', ROOT / 'gs_bugout.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


class BugoutSafety(unittest.TestCase):
    def test_v56_route_and_stage_help(self):
        s=(ROOT/'gs.py').read_text()
        for snippet in ("('4', 'GS BugOut')", "'4':sub_bugout", '3-second countdown',
                        'WHAT HAPPENS', 'systemd', 'Type BUGOUT'):
            self.assertIn(snippet, s)

    def test_preview_only_calls_stages_with_true(self):
        names=('close_applications','temp_cleanup','cache_cleanup','clipboard_clear',
               'network_off','unmount_usb','poweroff')
        with mock.patch.multiple(b, **{n:mock.DEFAULT for n in names}) as mocks:
            b.preview()
            for m in mocks.values(): m.assert_called_once_with(True)

    def test_test_mode_never_runs_actions(self):
        with mock.patch.dict(os.environ,{'GHOSTSTRAT_TEST_MODE':'1'}), \
             mock.patch.object(b,'preview') as check, mock.patch.object(b,'poweroff') as off:
            self.assertEqual(b.execute(),0)
            check.assert_called_once()
            off.assert_not_called()

    def test_wrong_confirmation_no_changes(self):
        with mock.patch.dict(os.environ,{'GHOSTSTRAT_TEST_MODE':'','SSH_TTY':'','SSH_CONNECTION':''}), \
             mock.patch.object(b.os,'geteuid',return_value=1000), \
             mock.patch.object(b.sys.stdin,'isatty',return_value=True), \
             mock.patch.object(b.sys.stdout,'isatty',return_value=True), \
             mock.patch.object(b.shutil,'which',return_value='/usr/bin/systemctl'), \
             mock.patch('builtins.input',return_value='NO'), \
             mock.patch.object(b,'close_applications') as app:
            self.assertEqual(b.execute(),10)
            app.assert_not_called()

    def test_cancel_countdown_no_changes(self):
        with mock.patch.dict(os.environ,{'GHOSTSTRAT_TEST_MODE':'','SSH_TTY':'','SSH_CONNECTION':''}), \
             mock.patch.object(b.os,'geteuid',return_value=1000), \
             mock.patch.object(b.sys.stdin,'isatty',return_value=True), \
             mock.patch.object(b.sys.stdout,'isatty',return_value=True), \
             mock.patch.object(b.shutil,'which',return_value='/usr/bin/systemctl'), \
             mock.patch('builtins.input',return_value='BUGOUT'), \
             mock.patch.object(b.time,'sleep',side_effect=KeyboardInterrupt), \
             mock.patch.object(b,'close_applications') as app:
            self.assertEqual(b.execute(),130)
            app.assert_not_called()

    def test_three_second_countdown_and_poweroff_order(self):
        events=[]
        def record(name): return lambda p: events.append((name,p))
        stages=('close_applications','temp_cleanup','cache_cleanup','clipboard_clear',
                'network_off','unmount_usb','poweroff')
        patches=[mock.patch.object(b,n,side_effect=record(n)) for n in stages]
        with mock.patch.dict(os.environ,{'GHOSTSTRAT_TEST_MODE':'','SSH_TTY':'','SSH_CONNECTION':''}), \
             mock.patch.object(b.os,'geteuid',return_value=1000), \
             mock.patch.object(b.sys.stdin,'isatty',return_value=True), \
             mock.patch.object(b.sys.stdout,'isatty',return_value=True), \
             mock.patch.object(b.shutil,'which',return_value='/usr/bin/systemctl'), \
             mock.patch('builtins.input',return_value='BUGOUT'), \
             mock.patch.object(b.time,'sleep',side_effect=lambda n:events.append(('sleep',n))):
            for p in patches: p.start()
            try: b.execute()
            finally:
                for p in reversed(patches):p.stop()
        self.assertEqual(events[:3],[('sleep',1)]*3)
        self.assertEqual(events[3:],[ (n,False) for n in stages])

    def test_cache_cleanup_stays_inside_allowlist(self):
        with tempfile.TemporaryDirectory() as temp:
            home=Path(temp); root=home/'.cache'/'thumbnails'; root.mkdir(parents=True)
            (root/'delete.png').write_bytes(b'cache')
            (home/'keep.txt').write_text('important')
            (home/'.cache'/'keep.dat').write_text('save')
            b.cache_cleanup(False,home,home/'.cache')
            self.assertFalse((root/'delete.png').exists())
            self.assertTrue((home/'keep.txt').exists())
            self.assertTrue((home/'.cache'/'keep.dat').exists())

    def test_symlink_cache_not_followed(self):
        with tempfile.TemporaryDirectory() as temp:
            home=Path(temp)/'home'; home.mkdir()
            target=Path(temp)/'outside'; target.mkdir()
            (target/'keep.txt').write_text('safe')
            (home/'.cache').symlink_to(target,target_is_directory=True)
            b.cache_cleanup(False,home,home/'.cache')
            self.assertTrue((target/'keep.txt').exists())

    def test_ssh_refusal(self):
        with mock.patch.dict(os.environ,{'GHOSTSTRAT_TEST_MODE':'','SSH_CONNECTION':'remote:1234'}), \
             mock.patch.object(b.os,'geteuid',return_value=1000), \
             mock.patch.object(b,'close_applications') as app:
            self.assertEqual(b.execute(),2)
            app.assert_not_called()


if __name__=='__main__': unittest.main()
