"""V65: no duplicate or inline taglines in the main menu."""
import contextlib
import io
import os
import unittest
from unittest import mock
import gs

class CleanMainMenuTests(unittest.TestCase):
    def render(self, width):
        output=io.StringIO()
        with mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((width,24))), \
             mock.patch.object(gs,'COLOR_ON',False), contextlib.redirect_stdout(output):
            gs.ui('MAIN MENU',gs.main_menu_options(),None,show_nullout=True)
        return output.getvalue()

    def test_no_microdescriptions_at_any_width(self):
        for width in (40,60,80,100,120):
            output=self.render(width)
            self.assertNotIn('Privacy controls',output)
            self.assertNotIn('Cleanup + exit',output)
            self.assertNotIn('Exposure review',output)
            self.assertNotIn('Idle shutdown',output)
            self.assertNotIn('Browse and tree',output)
            self.assertIn('[4] GS BugOut' if width >= 80 else '[4]',output)
            self.assertLessEqual(len(output.splitlines()),24)

    def test_submenu_explanations_remain_defined(self):
        self.assertIn('disable supported radios',gs.MAIN_DESCRIPTIONS['1'])
        self.assertEqual(len(gs.MAIN_DESCRIPTIONS),19)

if __name__=='__main__':
    unittest.main()
