"""V64: two-column dashboard, menu routing and branding checks."""
import io
import os
import re
import contextlib
import unittest
from unittest import mock
import gs

ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')

class StackedMainMenu(unittest.TestCase):
    def capture(self, width):
        output=io.StringIO()
        with mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((width,24))), contextlib.redirect_stdout(output):
            gs.ui('MAIN MENU',gs.main_menu_options(),None,show_nullout=True)
        return ANSI.sub('',output.getvalue())

    def test_all_gs_tools_have_one_category(self):
        title,options=gs.MAIN_SECTIONS[0]
        self.assertEqual(title,'GHOSTSTRATS TOOLS')
        self.assertEqual([key for key,_ in options],list(map(str,range(1,7))))
        self.assertTrue(all(label.startswith('GS ') for _,label in options))
        self.assertFalse(any(label.startswith('GS ') for _,rows in gs.MAIN_SECTIONS[1:] for _,label in rows))

    def test_all_descriptions_and_order(self):
        self.assertEqual(set(gs.MAIN_DESCRIPTIONS),set(map(str,range(1,20))))
        for width in (40,48,54,60,70,80,100,120):
            with self.subTest(width=width):
                data=self.capture(width)
                lines=data.splitlines()
                self.assertTrue(all(len(line)<=width for line in lines))
                found=[int(n) for n in re.findall(r'\[(\d+)\]\s+', '\n'.join(l for l in lines if l.startswith('  │'))) if n!='0']
                self.assertEqual(sorted(found),list(range(1,20)))
                for number in range(1,20):
                    label=dict(item for _,group in gs.MAIN_SECTIONS for item in group)[str(number)]
                    self.assertIn(f'[{number}] ',data)
                    if width>=80:
                        self.assertIn(f'[{number}] {label}',data)
                self.assertIn('PRIVACY / SAFETY IS AN ILLUSION',data)
                self.assertIn('STRICTLY FOR EDUCATIONAL',data)
                self.assertLessEqual(len(lines),24)
                self.assertIn('[H] HELP',data)

    def test_clean_home_and_purple_gs(self):
        output=io.StringIO()
        with mock.patch.object(gs,'COLOR_ON',True),mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((100,24))), contextlib.redirect_stdout(output):
            gs.ui('MAIN MENU',gs.main_menu_options(),None,show_nullout=False)
        raw=output.getvalue()
        self.assertIn(gs.PURPLE+'GS'+gs.RESET+gs.WHITE,raw)
        self.assertNotIn('Cleanup + exit',raw)
        self.assertNotIn('Privacy controls',raw)

    def test_status_row_bounds_on_scrolling_menus(self):
        with mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((70,24))),contextlib.redirect_stdout(io.StringIO()):
            gs.ui('MAIN MENU',gs.main_menu_options(),None,show_nullout=True)
        self.assertGreaterEqual(gs.COUNT_ROW,1)
        self.assertLessEqual(gs.COUNT_ROW,23)

    def test_number_four_still_opens_bugout(self):
        with mock.patch.object(gs.os,'geteuid',return_value=1000),mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True),mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'),mock.patch.object(gs,'menu_sub',side_effect=['4',None]),mock.patch.object(gs,'sub_bugout') as bugout,contextlib.redirect_stdout(io.StringIO()):
            gs.main()
        bugout.assert_called_once()

if __name__ == '__main__': unittest.main()
