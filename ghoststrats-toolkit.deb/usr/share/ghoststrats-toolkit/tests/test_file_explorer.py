import importlib.util
import tempfile
from pathlib import Path
import unittest

module_path = Path(__file__).resolve().parents[1] / 'gs_file_explorer.py'
spec = importlib.util.spec_from_file_location('gs_file_explorer', module_path)
gs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gs)

class FileExplorerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / '.hidden').mkdir()
        (self.root / '.hidden' / 'secret.txt').write_text('Sample', encoding='utf-8')
        (self.root / 'normal.txt').write_text('Visible', encoding='utf-8')
        (self.root / 'folder').mkdir()
        (self.root / 'folder' / 'nested.txt').write_text('Data', encoding='utf-8')
        (self.root / 'folder' / 'loop').symlink_to(self.root, target_is_directory=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_tree_has_hidden(self):
        lines = '\n'.join(gs.tree_lines(self.root, depth_limit=3))
        self.assertIn('.hidden/', lines)
        self.assertIn('secret.txt', lines)
        self.assertIn('normal.txt', lines)
        self.assertIn('loop ->', lines)
        self.assertLess(len(lines.splitlines()), 15)

    def test_hidden_search(self):
        results = [str(p.relative_to(self.root)) for p in gs.hidden_matches(self.root)]
        self.assertIn('.hidden', results)
        self.assertNotIn('normal.txt', results)

    def test_name_search(self):
        results = [p.name for p in gs.name_matches(self.root, 'NESTED')]
        self.assertEqual(results, ['nested.txt'])

    def test_metadata(self):
        report = gs.metadata(self.root / 'normal.txt')
        self.assertEqual(report['Kind'], 'Regular file')
        self.assertIn('Permissions', report)
        self.assertIn('Owner / Group', report)
        self.assertIn('Last modified', report)

    def test_symlink_not_followed(self):
        report = gs.metadata(self.root / 'folder' / 'loop')
        self.assertIn('Symbolic link', report['Kind'])
        listed = [p for p in gs.iter_files(self.root)]
        self.assertLess(len(listed), 10)

    def test_max_entries(self):
        lines = '\n'.join(gs.tree_lines(self.root, depth_limit=None, max_entries=2))
        self.assertIn('limit reached', lines)

if __name__ == '__main__':
    unittest.main()
