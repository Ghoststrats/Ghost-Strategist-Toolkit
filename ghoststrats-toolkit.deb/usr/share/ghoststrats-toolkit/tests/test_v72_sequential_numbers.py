"""V72: main selection numbers match the order seen by the user."""
import contextlib
import io
import os
import re
from pathlib import Path
from unittest import TestCase, mock
import gs

ROOT = Path(__file__).resolve().parents[1]

class ConsecutiveMenuNumberTests(TestCase):
    def test_each_section_continues_from_previous_section(self):
        expected = [
            list(range(1,7)), list(range(7,11)),
            list(range(11,16)), list(range(16,20)),
        ]
        for (_,options),numbers in zip(gs.MAIN_SECTIONS,expected):
            self.assertEqual([int(k) for k,_ in options],numbers)
        self.assertEqual(dict(gs.MAIN_SECTIONS[0][1])['6'],'GS Drone Detector')
        self.assertEqual(dict(gs.MAIN_SECTIONS[3][1])['19'],'Turn It All On')
        for dictionary in (gs.MAIN_DESCRIPTIONS,gs.MAIN_SHORT_LABELS,gs.MAIN_TINY_LABELS):
            self.assertEqual(set(dictionary),set(map(str,range(1,20))))

    def test_real_home_handlers_match_all_labels(self):
        handler_names = [
            'sub_blackout','sub_nullout','sub_threat','sub_bugout',
            'sub_network_intelligence','launch_drone_detector','sub_scanning',
            'sub_network_shortcuts','run_python','sub_network','sub_radios',
            'sub_peripherals','sub_mac','sub_firewall','sub_remote',
            'sub_persistence','sub_task','sub_overview','sub_restore',
        ]
        for selection,handler in enumerate(handler_names,start=1):
            with self.subTest(selection=selection),contextlib.ExitStack() as stack:
                patched = {name:stack.enter_context(mock.patch.object(gs,name)) for name in set(handler_names)}
                stack.enter_context(mock.patch.object(gs.os,'geteuid',return_value=1000))
                stack.enter_context(mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True))
                stack.enter_context(mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'))
                stack.enter_context(mock.patch.object(gs,'menu_sub',side_effect=[str(selection),None]))
                with contextlib.redirect_stdout(io.StringIO()):
                    gs.main()
                patched[handler].assert_called_once()
                self.assertEqual(sum(fn.call_count for fn in patched.values()),1)
                if selection==9:
                    self.assertEqual(patched[handler].call_args.args,('gs_file_explorer.py',))

    def test_help_and_restore_safety_reference_new_shortcuts(self):
        with mock.patch.object(gs,'persistent_menu') as menu:
            gs.sub_help()
        help_text = re.sub(r'\s+', ' ', re.sub(r'\x1b\[[0-9;]*m', '', menu.call_args.args[2]['8']()))
        for fragment in ('Built-in Network Tools [8]','File Explorer [9]',
                         'System & Device Overview [18]','Turn It All On [19]'):
            self.assertIn(fragment,help_text)
        shell=(ROOT/'remote-lockdown.sh').read_text()
        self.assertIn('[19] Turn It All On',shell)
        self.assertNotIn('[18] Turn It All On',shell)
