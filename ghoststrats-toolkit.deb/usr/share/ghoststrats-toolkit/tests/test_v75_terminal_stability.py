"""V75 regression tests for keyboard buffering and terminal recovery."""
import io
import os
import pty
import sys
import termios
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gs
import task_manager


class _Input:
    def __init__(self, fd):
        self.fd = fd
    def fileno(self):
        return self.fd
    def isatty(self):
        return True
    def read(self, _size):
        raise AssertionError('Buffered read stole input from the main menu')


class _Output(io.StringIO):
    def isatty(self):
        return True


class TerminalStabilityTests(unittest.TestCase):
    def test_terminal_guard_restores_exact_original_flags(self):
        master, slave = pty.openpty()
        try:
            original = termios.tcgetattr(slave)
            bad = termios.tcgetattr(slave)
            bad[3] &= ~(termios.ECHO | termios.ICANON)
            termios.tcsetattr(slave, termios.TCSANOW, bad)
            self.assertNotEqual(original, termios.tcgetattr(slave))
            with mock.patch.object(gs, '_TERMINAL_FD', slave), \
                 mock.patch.object(gs, '_TERMINAL_BASELINE', original):
                self.assertTrue(gs.restore_terminal())
                self.assertEqual(original, termios.tcgetattr(slave))
                self.assertFalse(gs.restore_terminal())
        finally:
            os.close(master)
            os.close(slave)

    def test_terminal_guard_does_nothing_without_a_tty(self):
        with mock.patch.object(gs, '_TERMINAL_FD', None), \
             mock.patch.object(gs, '_TERMINAL_BASELINE', None):
            self.assertFalse(gs.restore_terminal())

    def test_child_command_always_restores_terminal_after_exit(self):
        with mock.patch.object(gs, 'restore_terminal') as restore, \
             mock.patch.object(gs.subprocess, 'Popen') as launcher:
            launcher.return_value.wait.return_value = 0
            self.assertEqual(gs.cmd_run(['true']), 0)
            restore.assert_called_once()

    def test_live_process_viewer_uses_unbuffered_tty_bytes(self):
        master, slave = pty.openpty()
        sender = threading.Thread(target=lambda: (time.sleep(0.15), os.write(master, b'0')))
        try:
            sender.start()
            fake_output = _Output()
            with mock.patch.object(task_manager.sys, 'stdin', _Input(slave)), \
                 mock.patch.object(task_manager.sys, 'stdout', fake_output), \
                 mock.patch.object(task_manager, 'fetch_processes', return_value=(['PID USER', '1 demo'], None)), \
                 mock.patch.dict(os.environ, {'TERM': 'dumb'}):
                result = task_manager.live(refresh_seconds=0.5)
            self.assertIn('closed', result.lower())
            self.assertIn('TASK MANAGER', fake_output.getvalue())
        finally:
            sender.join(timeout=2)
            os.close(master)
            os.close(slave)

    def test_submenu_recovers_after_failed_action(self):
        call_order = []
        def damaged_action():
            call_order.append('action')
            raise RuntimeError('intentional')
        selections = iter(['1'])
        with mock.patch.object(gs, 'menu_sub', side_effect=lambda *_a, **_kw: next(selections)), \
             mock.patch.object(gs.gs_keys, 'read_line', return_value='0'), \
             mock.patch.object(gs, 'restore_terminal', side_effect=lambda: call_order.append('restore')), \
             mock.patch.object(gs, 'paint', side_effect=lambda content, *_a: str(content)), \
             mock.patch.object(gs, 'print', side_effect=lambda *_a, **_kw: None):
            gs.persistent_menu('TEST MENU', ['[1] Check', '[0] Back'], {'1': damaged_action})
        self.assertEqual(call_order, ['action', 'restore'])


if __name__ == '__main__':
    unittest.main()
