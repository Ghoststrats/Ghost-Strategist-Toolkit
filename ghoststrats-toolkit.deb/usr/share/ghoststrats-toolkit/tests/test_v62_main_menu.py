"""V62 responsive home/header design regression checks."""
import contextlib
import io
import os
import re
import unittest
from unittest import mock
import gs

ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')

class V62MainMenuTests(unittest.TestCase):
    def render(self, cols):
        out = io.StringIO()
        with mock.patch.object(gs.shutil, 'get_terminal_size', return_value=os.terminal_size((cols, 24))), contextlib.redirect_stdout(out):
            gs.ui('MAIN MENU', gs.main_menu_options(), None, show_nullout=True)
        return ANSI.sub('', out.getvalue()).splitlines()

    def test_header_exact_slogan_and_immediately_following_warning(self):
        for cols in (40, 48, 70, 80, 120):
            with self.subTest(cols=cols):
                lines=self.render(cols)
                slogan=next(i for i, row in enumerate(lines) if 'PRIVACY / SAFETY IS AN ILLUSION' in row)
                warning=next(i for i, row in enumerate(lines) if 'STRICTLY FOR EDUCATIONAL' in row)
                self.assertEqual(warning,slogan+1)
                if cols == 40:
                    self.assertIn('PURPOSES ONLY', lines[warning+1])
                else:
                    self.assertIn('STRICTLY FOR EDUCATIONAL PURPOSES ONLY', lines[warning])
                self.assertLess(warning,next(i for i, row in enumerate(lines) if ('GHOSTSTRATS TOOLS' in row or 'GS TOOLS' in row)))
                self.assertEqual(sum('STRICTLY FOR EDUCATIONAL' in row for row in lines),1)

    def test_sequential_routing_no_duplicate_and_24_line_terminal(self):
        for cols in (40, 48, 54, 60, 70, 80, 100, 120):
            with self.subTest(cols=cols):
                lines=self.render(cols)
                self.assertLessEqual(len(lines),24)  # V64 compact main menu
                self.assertTrue(all(len(row)<=cols for row in lines))
                body='\n'.join(row for row in lines if row.startswith('  │'))
                found=[int(n) for n in re.findall(r'\[(\d+)\]\s+',body) if n!='0']
                self.assertEqual(sorted(found),list(range(1,20)))
                self.assertTrue(any('[4]' in row and 'BugOut' in row for row in lines))
                self.assertTrue(any('[H]' in row and '[0]' in row for row in lines))

    def test_educational_disclaimer_at_top_not_footer(self):
        lines=self.render(80)
        footer=next(i for i, row in enumerate(lines) if '[H] HELP & WALKTHROUGHS' in row)
        disclaimer=next(i for i, row in enumerate(lines) if 'STRICTLY FOR EDUCATIONAL PURPOSES ONLY' in row)
        self.assertLess(disclaimer,footer-10)

if __name__=='__main__': unittest.main()
