"""V61: move BugOut to 4, shift former 4..17, preserve undo at 19."""
import contextlib
import io
import unittest
from unittest import mock
import gs

EXPECTED = [
    'GS BlackOut', 'GS NullOut', 'GS Threat Analysis', 'GS BugOut',
    'GS Network Intelligence', 'GS Drone Detector', 'Wireless & LAN Discovery',
    'Built-in Network Tools', 'File Explorer',
    'Network & IP Settings', 'Wi-Fi & Bluetooth', 'Camera, Mic & Audio',
    'MAC Address Inspector', 'Firewall & Port Security',
    'Remote Access Lockdown', 'Startup & Privacy Audit', 'Task Manager',
    'System & Device Overview', 'Turn It All On',
]

class BugOutShortcutAtFour(unittest.TestCase):
    def test_all_options_shifted_once(self):
        options = [label for _, rows in gs.MAIN_SECTIONS for _, label in rows]
        self.assertEqual(options, EXPECTED)
        numbers = [int(k) for _, rows in gs.MAIN_SECTIONS for k, _ in rows]
        self.assertEqual(numbers, list(range(1,20)))

    def test_four_calls_real_bugout_submenu_not_activation(self):
        with mock.patch.object(gs.os, 'geteuid', return_value=1000), \
             mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True), \
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'), \
             mock.patch.object(gs,'menu_sub',side_effect=['4',None]), \
             mock.patch.object(gs,'sub_bugout') as bugout, \
             mock.patch.object(gs,'sub_network_intelligence') as network, \
             contextlib.redirect_stdout(io.StringIO()):
            gs.main()
        bugout.assert_called_once()
        network.assert_not_called()

    def test_help_references_updated_shortcuts(self):
        with mock.patch.object(gs, 'persistent_menu') as menu:
            gs.sub_help()
        handlers = menu.call_args.args[2]
        text = '\n'.join(handlers[key]() for key in ('2', '5', '6', '8'))
        self.assertIn('GS BugOut [4]', text)
        self.assertIn('Built-in Network Tools [8]', text)
        self.assertIn('System & Device Overview [18]', text)
        self.assertNotIn('GS BugOut [18]', text)

if __name__ == '__main__':
    unittest.main()
