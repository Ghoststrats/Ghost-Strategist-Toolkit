"""V76 synthetic radio strength and warning behavior (no adapters needed)."""
import contextlib
import io
from pathlib import Path
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / 'gs-drone-detector.sh').read_text()
BODY = SCRIPT.split('# GS_PYTHON_START\n', 1)[1].split('\nGS_PYTHON_EOF', 1)[0]
D = types.ModuleType('gs_drone_v76_test')
exec(compile(BODY, str(ROOT / 'gs-drone-detector.sh'), 'exec'), D.__dict__)


class DroneSignalTests(unittest.TestCase):
    def test_color_boundaries(self):
        boundaries = [(0, 'green'), (49, 'green'), (50, 'yellow'),
                      (89, 'yellow'), (90, 'red'), (99, 'red'), (100, 'red')]
        for value, level in boundaries:
            with self.subTest(signal=value):
                self.assertEqual(D.signal_advisory(value, '%')['level'], level)

    def test_peak_warning_is_tentative(self):
        state = D.signal_advisory(100, '%')
        self.assertIn('DANGER', state['message'])
        self.assertIn('POSSIBLY CLOSE', state['message'])
        self.assertNotIn('IS CLOSE', state['message'])

    def test_dbm_scale_and_missing_values(self):
        self.assertEqual(D.signal_index(-100, 'dBm'), 0)
        self.assertEqual(D.signal_index(-70, 'dBm'), 50)
        self.assertEqual(D.signal_index(-40, 'dBm'), 100)
        for n in [None, float('nan'), float('inf'), 'invalid']:
            with self.subTest(signal=n):
                self.assertEqual(D.signal_advisory(n, 'dBm')['level'], 'unknown')
        self.assertEqual(D.signal_advisory(65, 'watts')['level'], 'unknown')

    def test_yellow_to_red_only_alerts_once(self):
        args = D.make_args(['scan', '--plain', '--no-wifi'])[1]
        monitor = D.Monitor(args)
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                for value in (49, 50, 89, 90, 91, 100):
                    monitor.put('Wi-Fi survey', 'demo', 'DJI-NEO-TEST', value, '%')
                    monitor.apply(monitor.q.get_nowait())
            self.assertEqual(len(monitor.events), 2)
            self.assertIn('VERY STRONG SIGNAL', monitor.events[0][1])
            self.assertEqual(monitor.devices['Wi-Fi survey:demo']['last_signal_level'], 'red')
            self.assertIn('DANGER: MAX SIGNAL', '\n'.join(monitor.format_item(monitor.devices['Wi-Fi survey:demo'])))
        finally:
            monitor.close()

    def test_no_false_candidate_from_generic_wifi(self):
        args = D.make_args(['scan', '--plain', '--no-wifi'])[1]
        monitor = D.Monitor(args)
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                monitor.put('Wi-Fi survey', 'ordinary', 'HomeWifi', 100, '%')
                monitor.apply(monitor.q.get_nowait())
            self.assertEqual(len(monitor.events), 0)
            self.assertNotIn('Wi-Fi survey:ordinary',monitor.devices)
        finally:
            monitor.close()

    def test_demo_three_level_examples(self):
        args = D.make_args(['demo', '--plain'])[1]
        monitor = D.Monitor(args)
        try:
            monitor.demo_events()
            with contextlib.redirect_stdout(io.StringIO()):
                while not monitor.q.empty():
                    monitor.apply(monitor.q.get_nowait())
            matched = [D.signal_advisory(x['signal'],x['unit'])['level']
                       for x in monitor.devices.values() if x['confidence']]
            self.assertEqual(set(matched), {'green', 'yellow', 'red'})
        finally:
            monitor.close()


if __name__ == '__main__':
    unittest.main()
