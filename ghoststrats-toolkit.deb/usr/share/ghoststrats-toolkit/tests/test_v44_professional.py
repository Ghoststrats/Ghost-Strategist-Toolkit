"""V44 professional edition: safe routing/layout checks; no privileged effects."""
import contextlib
import io
import os
import re
import sys
import unittest
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import gs
import gs_file_explorer


class ProfessionalMenuTests(unittest.TestCase):
    def test_exactly_19_unique_main_choices(self):
        all_entries=[(key,label) for _,options in gs.MAIN_SECTIONS for key,label in options]
        self.assertEqual(len(all_entries),19)
        self.assertEqual({int(k) for k,_ in all_entries},set(range(1,20)))
        self.assertEqual(len({label for _,label in all_entries}),19)
        self.assertIn('[H]', '\n'.join(gs.main_menu_options()))
        self.assertIn('[0]', '\n'.join(gs.main_menu_options()))

    def test_four_distinct_complementary_sections(self):
        self.assertEqual(len(gs.MAIN_SECTIONS),4)
        self.assertEqual([len(options) for _,options in gs.MAIN_SECTIONS],[6,4,5,4])
        text='\n'.join(gs.main_menu_options())
        for section,_ in gs.MAIN_SECTIONS:
            self.assertEqual(text.count(section),1)
        self.assertIn('Wireless & LAN Discovery',text)
        self.assertNotIn('Toolkit Diagnostics',text)
        self.assertIn('File Explorer',text)

    def render(self, columns, body=None, *, active=False, countdown=60):
        with mock.patch.object(gs.shutil,'get_terminal_size',return_value=os.terminal_size((columns,24))),\
             contextlib.redirect_stdout(io.StringIO()) as log,\
             mock.patch.object(gs,'armed',active):
            gs.ui('MAIN MENU',gs.main_menu_options() if body is None else body,countdown if active else None,show_nullout=True)
        return log.getvalue().replace('\033[2J\033[H','')

    def test_default_80_column_menu_has_two_columns(self):
        output=self.render(80)
        self.assertIn('GS NullOut: INACTIVE',output)
        self.assertIn('gs  ›',output)
        self.assertEqual(output.count('GHOSTSTRATS TOOLS'),1)
        self.assertEqual(output.count('DEVICE & ACCESS CONTROL'),1)
        self.assertIn('[4] GS BugOut',output)
        self.assertIn('DISCOVERY & SCANNING',output)
        self.assertNotIn('Privacy controls',output)
        self.assertLessEqual(len(output.splitlines()),24)

    def test_sections_read_down_columns(self):
        text=self.render(120)
        self.assertIn('GHOSTSTRATS TOOLS',text)
        self.assertIn('DISCOVERY & SCANNING',text)
        self.assertIn('DEVICE & ACCESS CONTROL',text)
        self.assertIn('SYSTEM & UTILITIES',text)
        self.assertEqual(text.count('[4] GS BugOut'),1)
        for n in range(1,20):
            self.assertEqual(len(re.findall(r'\['+str(n)+r'\]\s+', '\n'.join(line for line in text.splitlines() if line.startswith('  │')))),1)

    def test_narrow_terminal_stays_complete(self):
        text=self.render(70)
        for n in range(1,20):
            self.assertEqual(len(re.findall(r'\['+str(n)+r'\]\s+', '\n'.join(line for line in text.splitlines() if line.startswith('  │')))),1,n)
        self.assertIn('DEVICE & ACCESS CONTROL',text)
        self.assertLessEqual(len(text.splitlines()),24)

    def test_no_line_longer_than_terminal_width(self):
        for cols in (70,80,100,120):
            text=self.render(cols)
            for line in text.splitlines():
                self.assertLessEqual(len(re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',line)),cols)

    def test_nullout_red_warning_still_visible(self):
        text=self.render(80, active=True, countdown=15)
        self.assertIn('SHUTDOWN WARNING: 15s',text)
        self.assertIn('gs  ›',text)
        text=self.render(80, active=True, countdown=16)
        self.assertNotIn('SHUTDOWN WARNING',text)

    def test_no_installers_or_duplicate_scanners_on_home(self):
        text='\n'.join(gs.main_menu_options())
        self.assertNotIn('Install Tor',text)
        self.assertNotIn('OnionShare Installer',text)
        self.assertNotIn('Device Status Info',text)
        self.assertNotIn('Port Lockdown',text)  # consolidated under firewall
        self.assertNotIn('Nmap Scanner',text)

    def test_all_nineteen_tools_are_routed(self):
        mapping={
            1:'sub_blackout',2:'sub_nullout',3:'sub_threat',4:'sub_bugout',
            5:'sub_network_intelligence',6:'launch_drone_detector',
            7:'sub_scanning',8:'sub_network_shortcuts',9:'run_python',
            10:'sub_network',11:'sub_radios',12:'sub_peripherals',
            13:'sub_mac',14:'sub_firewall',15:'sub_remote',
            16:'sub_persistence',17:'sub_task',18:'sub_overview',19:'sub_restore',
        }
        from unittest import mock
        for n,expected in mapping.items():
            with self.subTest(tool=n), contextlib.ExitStack() as stack:
                names=sorted(set(mapping.values()))
                patched={key:stack.enter_context(mock.patch.object(gs,key)) for key in names}
                
                stack.enter_context(mock.patch.object(gs.os,'geteuid',return_value=1000))
                stack.enter_context(mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True))
                stack.enter_context(mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'))
                stack.enter_context(mock.patch.object(gs,'menu_sub',side_effect=[str(n),None]))
                with contextlib.redirect_stdout(io.StringIO()): gs.main()
                patched[expected].assert_called_once()
                if n==9:self.assertEqual(patched[expected].call_args.args[0],'gs_file_explorer.py')

    def test_help_uses_h_and_not_number(self):
        with mock.patch.object(gs.os,'geteuid',return_value=1000),\
             mock.patch.object(gs.sys.stdin,'isatty',return_value=True,create=True),\
             mock.patch.object(gs,'menu_sub',side_effect=['H',None]),\
             mock.patch.object(gs,'sub_help') as help_handler:
            gs.main()
        help_handler.assert_called_once()

    def test_combined_radio_actions(self):
        with mock.patch.object(gs,'persistent_menu') as capture:gs.sub_radios()
        handlers=capture.call_args.args[2]
        self.assertEqual(set(handlers),{'1','2','3','4','5'})
        with mock.patch.object(gs,'dev_do',return_value='ok') as device:
            handlers['2']();handlers['3']();handlers['4']();handlers['5']()
        self.assertEqual([call.args for call in device.call_args_list],
             [('wifi','off'),('wifi','on'),('bluetooth','off'),('bluetooth','on')])

    def test_peripheral_actions(self):
        with mock.patch.object(gs,'persistent_menu') as capture:gs.sub_peripherals()
        handlers=capture.call_args.args[2]
        self.assertEqual(len(handlers),7)
        with mock.patch.object(gs,'dev_do',return_value='ok') as device:
            for i in '234567':handlers[i]()
        self.assertEqual([call.args for call in device.call_args_list],
             [('microphone','off'),('microphone','on'),('camera','off'),
              ('camera','on'),('speakers','off'),('speakers','on')])

    def test_unified_firewall_and_port_menu(self):
        with mock.patch.object(gs,'persistent_menu') as capture:gs.sub_firewall()
        handlers=capture.call_args.args[2]
        self.assertEqual(len(handlers),8)
        with mock.patch.object(gs,'port_do',return_value='ok') as port:
            for i in ('5','6','7'):handlers[i]()
        self.assertEqual([x.args for x in port.call_args_list],
                         [('apply-common',),('apply-all',),('restore',)])

    def test_scanning_hub_has_no_duplicate_nested_shortcuts(self):
        with mock.patch.object(gs,'persistent_menu') as capture:gs.sub_scanning()
        opts='\n'.join(capture.call_args.args[1])
        handlers=capture.call_args.args[2]
        # All six original discovery actions remain; detector moved to GhostStrats Tools.
        self.assertEqual(set(handlers),set('123456'))
        self.assertNotIn('GS Drone Detector',opts)
        self.assertNotIn('Nmap',opts)
        self.assertNotIn('TShark',opts)
        self.assertNotIn('File Explorer',opts)

    def test_system_overview_consolidated(self):
        with mock.patch.object(gs,'print_sys') as syst, mock.patch.object(gs,'info_status') as dev, \
             mock.patch.object(gs,'persistent_menu') as capture:
            gs.sub_overview()
            handlers=capture.call_args.args[2]
            self.assertEqual(len(handlers),4)
            handlers['1']();handlers['2']()
            syst.assert_called_once();dev.assert_called_once()

    def test_browse_header_is_framed(self):
        with mock.patch.object(gs_file_explorer.shutil,'get_terminal_size',return_value=os.terminal_size((80,24))),\
             contextlib.redirect_stdout(io.StringIO()) as log:
            gs_file_explorer.header('Folder', 'Read only')
        lines=log.getvalue().splitlines()[1:]
        self.assertEqual(len(lines),6)
        self.assertTrue(all(row.startswith('  ') for row in lines))
        self.assertTrue(all(row.endswith(('┐','┤','│','┘')) for row in lines))
        self.assertEqual(len({len(row) for row in lines}),1)


if __name__=='__main__':unittest.main()
