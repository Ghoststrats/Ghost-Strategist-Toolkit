"""V77 fast scan scheduling and UI responsiveness; does not touch radio hardware."""
import contextlib
import io
from pathlib import Path
import threading
import time
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT/'gs-drone-detector.sh').read_text()
BODY = SCRIPT.split('# GS_PYTHON_START\n', 1)[1].split('\nGS_PYTHON_EOF', 1)[0]
D=types.ModuleType('gs_drone_v77_test')
exec(compile(BODY, str(ROOT/'gs-drone-detector.sh'),'exec'),D.__dict__)

class FastScanTests(unittest.TestCase):
    def test_defaults_faster_than_previous_release(self):
        args=D.make_args(['scan'])[1]
        self.assertEqual(args.interval,3)
        self.assertEqual(args.dwell,.5)
        self.assertEqual(args.refresh,.15)
        self.assertEqual(args.duration,0)

    def test_turbo_options_available(self):
        args=D.make_args(['scan','--interval','3','--refresh','.15','--dwell','.5'])[1]
        self.assertEqual((args.interval,args.refresh,args.dwell),(3,.15,.5))

    def test_balanced_arguments_still_available(self):
        args=D.make_args(['scan','--interval','12','--dwell','3','--refresh','.6'])[1]
        self.assertEqual((args.interval,args.dwell,args.refresh),(12,3,.6))

    def test_fractional_channel_dwell_and_validation(self):
        self.assertEqual(D.make_args(['scan','--dwell','.25'])[1].dwell,.25)
        for opts in (['--interval','2'],['--dwell','.15'],['--refresh','0'],['--interval','nan']):
            with self.subTest(opts=opts), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    D.make_args(['scan']+opts)

    def test_fast_survey_command_requests_a_fresh_scan(self):
        m=D.Monitor(D.make_args(['scan'])[1])
        output='DJI-NEO:AA\\:BB\\:CC\\:DD\\:EE\\:FF:6:2437:95\n'
        try:
            with mock.patch.object(D,'cmd_exists',return_value=True),mock.patch.object(m,'run_wifi_command',return_value=(0,output,'')) as call:
                m.wifi_survey()
            args=call.call_args.args[0]
            self.assertEqual(args[-2:],['--rescan','yes'])
            self.assertIn('DJI-NEO', m.q.get_nowait()['name'])
            self.assertEqual(m.survey_attempts,1)
        finally:m.close()

    def test_wifi_scan_guard_prevents_parallel_survey(self):
        m=D.Monitor(D.make_args(['scan'])[1])
        started=threading.Event()
        release=threading.Event()
        def delayed():
            started.set()
            release.wait(timeout=3)
        try:
            with mock.patch.object(m,'wifi_survey',side_effect=delayed) as survey:
                t=threading.Thread(target=m.wifi_survey_once)
                t.start()
                self.assertTrue(started.wait(1))
                self.assertTrue(m.survey_in_progress)
                m.wifi_survey_once()
                release.set()
                t.join(2)
                self.assertFalse(t.is_alive())
                self.assertEqual(survey.call_count,1)
                self.assertFalse(m.survey_in_progress)
        finally:
            release.set()
            m.close()

    def test_queue_backpressure_does_not_hang_callback(self):
        m=D.Monitor(D.make_args(['scan','--no-wifi'])[1])
        try:
            for i in range(4150):
                m.put('Wi-Fi beacon',str(i),'DJI-NEO',-65,'dBm')
            self.assertEqual(m.q.qsize(),4096)
            self.assertEqual(m.dropped_packets,54)
        finally:m.close()

    def test_fast_ui_prints_scan_progress_without_radio(self):
        m=D.Monitor(D.make_args(['demo'])[1])
        out=io.StringIO()
        try:
            with mock.patch.object(D.sys.stdout,'isatty',return_value=True),\
                 mock.patch.object(D,'COLOR',False),\
                 contextlib.redirect_stdout(out):
                # Redirected buffer usually has no isatty; force display via mocking on it.
                pass
            with mock.patch.object(D.sys,'stdout',out),mock.patch.object(out,'isatty',return_value=True):
                m.display(None)
            self.assertIn('UPDATE 0.15s',out.getvalue())
            self.assertIn('Wi-Fi scan request 3s',out.getvalue())
        finally:m.close()

if __name__=='__main__':unittest.main()
