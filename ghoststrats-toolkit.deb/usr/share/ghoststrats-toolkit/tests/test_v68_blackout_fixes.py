"""V68: BlackOut socket shutdown and reversible state under isolated fake system tools."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock
import gs

ROOT = Path(__file__).resolve().parents[1]


class BlackoutControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.bin = self.dir / 'bin'
        self.bin.mkdir()
        self.data = self.dir / 'data'
        self.data.mkdir()
        self.state = self.dir / 'state'
        self.env = {**os.environ, 'PATH': str(self.bin)+':'+os.environ.get('PATH',''),
                    'XDG_STATE_HOME': str(self.state), 'GS_FAKE_DATA': str(self.data),
                    'NO_COLOR': '1'}
        self.install('systemctl', '''#!/usr/bin/env bash
case "$1" in
 show) echo loaded;;
 is-active) [[ "$2" == --quiet ]] && shift; test "$(cat "$GS_FAKE_DATA/$2" 2>/dev/null)" = active;;
 start|stop)
   if [[ "$1" == stop && "${GS_KEEP_ACTIVE:-}" == "$2" ]]; then exit 0; fi
   [[ "$1" == start ]] && echo active > "$GS_FAKE_DATA/$2" || echo inactive > "$GS_FAKE_DATA/$2";;
esac
''')
        self.install('sudo', '#!/usr/bin/env bash\nexec "$@"\n')
        self.install('nmcli', '''#!/usr/bin/env bash
case "$*" in
 networking) cat "$GS_FAKE_DATA/network";;
 'networking off') echo disabled > "$GS_FAKE_DATA/network";;
 'networking on') echo enabled > "$GS_FAKE_DATA/network";;
 'radio wwan') cat "$GS_FAKE_DATA/wwan";;
 'radio wwan off') echo disabled > "$GS_FAKE_DATA/wwan";;
 'radio wwan on') echo enabled > "$GS_FAKE_DATA/wwan";;
esac
''')
        (self.data / 'network').write_text('enabled\n')
        (self.data / 'wwan').write_text('enabled\n')
        self.units = ('avahi-daemon.socket', 'avahi-daemon.service', 'cups.socket', 'cups.path',
                      'cups.service', 'bluetooth.service', 'smbd.service', 'nmbd.service')
        for unit in self.units:
            (self.data / unit).write_text('active\n' if unit in (
                'avahi-daemon.socket', 'avahi-daemon.service', 'cups.socket',
                'cups.service') else 'inactive\n')

    def install(self, name, content):
        path = self.bin / name
        path.write_text(content)
        path.chmod(0o755)

    def run_extra(self, action, more=None):
        return subprocess.run(['bash', str(ROOT/'blackout-extra.sh'), action],
                              env={**self.env, **(more or {})}, text=True,
                              capture_output=True, timeout=12)

    def test_socket_and_service_stop_and_restore(self):
        a = self.run_extra('apply')
        self.assertEqual(a.returncode, 0, a.stdout + a.stderr)
        self.assertIn('VERIFIED off: avahi-daemon.socket', a.stdout)
        for unit in ('avahi-daemon.socket','avahi-daemon.service','cups.socket','cups.service'):
            self.assertEqual((self.data/unit).read_text().strip(), 'inactive')
        self.assertEqual((self.data/'network').read_text().strip(), 'disabled')
        state = self.state/'ghost-strategist-tool'/'blackout-extra-v47.tsv'
        self.assertIn('SERVICE|avahi-daemon.socket|active', state.read_text())
        self.assertIn('SERVICE|cups.path|inactive', state.read_text())
        b = self.run_extra('restore')
        self.assertEqual(b.returncode, 0, b.stdout + b.stderr)
        for unit in ('avahi-daemon.socket','avahi-daemon.service','cups.socket','cups.service'):
            self.assertEqual((self.data/unit).read_text().strip(), 'active')
        self.assertEqual((self.data/'cups.path').read_text().strip(), 'inactive')
        self.assertEqual((self.data/'network').read_text().strip(), 'enabled')
        self.assertFalse(state.exists())

    def test_keeps_snapshot_and_fails_if_socket_cannot_stop(self):
        a = self.run_extra('apply', {'GS_KEEP_ACTIVE':'avahi-daemon.socket'})
        self.assertNotEqual(a.returncode, 0)
        self.assertIn('FAILED to stop or verify: avahi-daemon.socket', a.stdout)
        self.assertTrue((self.state/'ghost-strategist-tool'/'blackout-extra-v47.tsv').exists())

    def test_no_snapshot_override(self):
        a = self.run_extra('apply')
        snapshot = self.state/'ghost-strategist-tool'/'blackout-extra-v47.tsv'
        prior = snapshot.read_bytes()
        again = self.run_extra('apply')
        self.assertNotEqual(again.returncode, 0)
        self.assertEqual(prior, snapshot.read_bytes())

    def test_blackout_activation_refuses_independent_restore_state(self):
        local = self.dir/'tool'
        local.mkdir()
        shutil.copy2(ROOT/'blackout-control.sh', local/'blackout-control.sh')
        self.install('touchflag', '#!/bin/sh\necho CALLED > "$GS_FAKE_DATA/called"\n')
        (local/'device-controls.sh').write_text('#!/bin/bash\ntouchflag\n')
        state = self.state/'ghost-strategist-tool'
        state.mkdir(parents=True)
        (state/'remote-lockdown-state.tsv').write_text('unrelated session')
        result = subprocess.run(['bash', str(local/'blackout-control.sh'), 'apply'],
                                env=self.env, text=True, capture_output=True, timeout=8)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Restore that earlier action first', result.stdout)
        self.assertFalse((self.data/'called').exists())

    def test_refused_sudo_does_not_create_blackout_backup(self):
        self.install('sudo', '#!/bin/sh\nexit 77\n')
        result = subprocess.run(['bash', str(ROOT/'device-controls.sh'), 'ghost'],
                                env=self.env, text=True, capture_output=True, timeout=8)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('authorization was not granted', result.stdout)
        self.assertFalse((self.state/'ghost-strategist-tool'/'blackout-devices-v23.tsv').exists())

    def test_status_option_routes_to_full_verification(self):
        with mock.patch.object(gs, 'persistent_menu') as m:
            gs.sub_blackout()
        _, _, actions, descriptions = m.call_args.args
        self.assertIs(actions['3'], gs.blackout_status)
        self.assertIn('socket', descriptions['3'][1])

    def test_ui_and_report_are_read_only(self):
        self.assertIs(gs.sub_blackout.__globals__['blackout_status'], gs.blackout_status)
        result = subprocess.run(['bash', str(ROOT/'blackout-verify.sh')],
                                env=self.env, text=True, capture_output=True, timeout=8)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('READ-ONLY VERIFICATION', result.stdout)
        self.assertEqual((self.data/'network').read_text().strip(), 'enabled')

if __name__ == '__main__':
    unittest.main()
