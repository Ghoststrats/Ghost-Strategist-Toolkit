"""Snake Easter egg: deterministic collision, navigation, and safety tests."""
import contextlib
from collections import deque
import io
import os
from pathlib import Path
import sys
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import gs
import gs_snake


class SnakeTests(unittest.TestCase):
    def test_spawns_inside_bounds_and_avoids_body(self):
        game = gs_snake.SnakeGame(24, 10)
        self.assertEqual(len(game.snake), 3)
        self.assertNotIn(game.food, game.snake)
        self.assertTrue(all(0 <= x < 24 and 0 <= y < 10 for x,y in game.snake))

    def test_wall_collision_returns_crash_without_prompt(self):
        game = gs_snake.SnakeGame(12, 8)
        statuses = []
        for _ in range(20):
            result = game.step()
            statuses.append(result)
            if result == 'crash':
                break
        self.assertEqual(statuses[-1], 'crash')
        self.assertTrue(game.finished)

    def test_self_collision(self):
        game = gs_snake.SnakeGame(14, 10)
        game.snake = deque([(5,5),(5,6),(4,6),(4,5),(3,5)])
        game.direction = 'LEFT'
        game.food = (8,8)
        self.assertEqual(game.step(), 'crash')

    def test_moving_into_tail_is_safe(self):
        game = gs_snake.SnakeGame(14, 10)
        game.snake = deque([(5,5),(4,5),(4,4),(5,4)])
        game.direction = 'UP'
        game.food = (8,8)
        self.assertEqual(game.step(), 'alive')
        self.assertEqual(game.snake[0], (5,4))

    def test_food_increases_score_and_length(self):
        game = gs_snake.SnakeGame(14, 10)
        length = len(game.snake)
        x,y = game.snake[0]
        game.food = (x+1,y)
        self.assertEqual(game.step(), 'alive')
        self.assertEqual(game.score, 1)
        self.assertEqual(len(game.snake), length+1)
        self.assertNotIn(game.food, game.snake)

    def test_reverse_and_multi_turn_are_blocked(self):
        game = gs_snake.SnakeGame(14, 10)
        self.assertFalse(game.turn('LEFT'))
        self.assertTrue(game.turn('UP'))
        self.assertFalse(game.turn('LEFT'))
        self.assertEqual(game.direction, 'UP')
        game.step()
        self.assertTrue(game.turn('LEFT'))

    def test_nontty_returns_without_curses(self):
        with mock.patch.object(gs_snake.sys.stdin,'isatty',return_value=False), \
             mock.patch('subprocess.run', side_effect=AssertionError('should not spawn')):
            self.assertEqual(gs_snake.play(), 'not-a-terminal')

    def test_hidden_main_menu_game_returns_without_wait(self):
        with mock.patch.object(gs.os, 'geteuid', return_value=1000), \
             mock.patch.object(gs.sys.stdin, 'isatty', return_value=True), \
             mock.patch.object(gs.startup_settings,'ensure_initial_snapshot',return_value='SAVED'), \
             mock.patch.object(gs,'menu_sub',side_effect=[' GaMe ',None]) as menu, \
             mock.patch.object(gs.gs_snake,'play',return_value='crash') as run, \
             mock.patch.object(gs,'wait_for_continue',side_effect=AssertionError('crash must return immediately')), \
             contextlib.redirect_stdout(io.StringIO()):
            gs.main()
        run.assert_called_once_with()
        self.assertEqual(menu.call_count, 2)  # Returned directly home after collision.

    def test_not_a_main_menu_number(self):
        self.assertEqual(len(gs.MAIN_SECTIONS),4)
        self.assertEqual(gs.MAIN_SECTIONS[0][1][3],('4','GS BugOut'))
        self.assertNotIn('[game]', '\n'.join(gs.main_menu_options()))


if __name__ == '__main__':
    unittest.main()
