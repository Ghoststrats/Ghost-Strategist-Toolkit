"""V74 multi-distro detection, Tails-safe dispatch and Wayland warning tests."""
import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gs_platform
import gs


class PlatformTests(unittest.TestCase):
    def test_identifies_supported_families(self):
        cases = [
            ('ID=linuxmint\nID_LIKE="ubuntu debian"', 'mint'),
            ('ID=kali\nID_LIKE=debian', 'kali'),
            ('NAME="Parrot OS"\nID=parrot', 'parrot'),
            ('NAME=Tails\nID=tails', 'tails'),
            ('ID=debian', 'debian-family'),
            ('ID=ubuntu', 'debian-family'),
            ('ID=arch', 'other-linux'),
        ]
        for contents, expected in cases:
            with self.subTest(expected=expected):
                self.assertEqual(gs_platform.identify(gs_platform.parse_os_release(contents)), expected)

    def test_tails_marker_is_detected_even_if_debian_id(self):
        with tempfile.TemporaryDirectory() as root:
            release = Path(root) / 'os-release'
            marker = Path(root) / 'tails-version'
            release.write_text('ID=debian\n', encoding='utf8')
            self.assertEqual(gs_platform.detect(release, marker), 'debian-family')
            marker.write_text('7.x\n', encoding='utf8')
            self.assertEqual(gs_platform.detect(release, marker), 'tails')

    def test_tails_safe_list_has_no_radio_or_firewall_workflows(self):
        self.assertEqual(gs_platform.TAILS_ALLOWED, frozenset({'3','5','9','13','16','18','h'}))
        self.assertTrue(set('124678') - gs_platform.TAILS_ALLOWED)

    def test_tails_blocks_unsafe_main_choice_before_launch(self):
        selections = iter(['1', '6', '14', '19', '0'])
        with mock.patch.object(gs, 'TAILS_SAFE', True), \
             mock.patch.object(gs, 'PLATFORM', 'tails'), \
             mock.patch.object(gs.sys.stdin, 'isatty', return_value=True), \
             mock.patch.object(gs.os, 'geteuid', return_value=1000), \
             mock.patch.object(gs, 'menu_sub', side_effect=lambda *a, **kw: (lambda v: None if v == '0' else v)(next(selections))), \
             mock.patch.object(gs.startup_settings, 'ensure_initial_snapshot', side_effect=AssertionError('no startup snapshot')), \
             mock.patch.object(gs, 'sub_blackout', side_effect=AssertionError('blackout')), \
             mock.patch.object(gs, 'launch_drone_detector', side_effect=AssertionError('drone')), \
             mock.patch.object(gs, 'sub_firewall', side_effect=AssertionError('firewall')), \
             mock.patch.object(gs, 'sub_restore', side_effect=AssertionError('restore')):
            gs.main()
        self.assertIn('Unavailable on Tails', gs.msg)

    def test_tails_status_distinguishable(self):
        with mock.patch.object(gs, 'TAILS_SAFE', True):
            self.assertIn('UNAVAILABLE ON TAILS', gs.countdown_text(None))

    def test_wayland_nullout_does_not_arm(self):
        output = []
        with mock.patch.object(gs.gs_platform, 'session', return_value='wayland'), \
             mock.patch.object(gs, 'explained_menu', side_effect=lambda *args: output.append(args[4]['1']())), \
             mock.patch.object(gs, 'toggle_nullout', side_effect=AssertionError('must not arm')):
            gs.sub_nullout()
        self.assertIn('unavailable on Wayland', output[0])

if __name__ == '__main__':
    unittest.main()
