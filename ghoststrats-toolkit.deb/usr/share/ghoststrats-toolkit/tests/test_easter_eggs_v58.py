"""Test read-only creator/branding easter eggs without touching host devices."""
import contextlib
import io
import os
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import easter_eggs
import gs


class CreatorEasterEggTests(unittest.TestCase):
    def get(self, trigger, *, color=False):
        lines = []
        result = easter_eggs.run(trigger, out=lines.append, color=color)
        return result, '\n'.join(lines)

    def test_every_new_egg_is_reachable(self):
        for trigger, target in easter_eggs.ALIASES.items():
            with self.subTest(trigger=trigger):
                matched, content = self.get(trigger)
                self.assertTrue(matched)
                self.assertIn(easter_eggs.SCENES[target][0], content)

    def test_existing_eggs_kept(self):
        for trigger in ('ghostrats', 'ghoststrats', 'ghoststrategist',
                        'ghost rats', 'anomaly', 'we are the anomaly',
                        '316', '3:16', '828', '413', '356',
                        'john316', 'romans828', 'proverbs356'):
            with self.subTest(trigger=trigger):
                self.assertTrue(self.get(trigger)[0])

    def test_kjv_exodus_added(self):
        self.assertIn('The LORD shall fight for you', self.get('Exodus 14:14')[1])

    def test_typing_egg_does_not_change_settings_or_files(self):
        with mock.patch('subprocess.run', side_effect=AssertionError('unexpected subprocess')), \
             mock.patch('subprocess.Popen', side_effect=AssertionError('unexpected process')):
            for item in easter_eggs.ALIASES:
                self.assertTrue(self.get(item)[0])

    def test_no_accidental_matching(self):
        for trigger in ('', '1', '18', '19', 'help', 'exit', 'blahcyberdeck',
                        'blackout now', 'gs bugout activate', 'ghostsignal; rm -rf /'):
            with self.subTest(trigger=trigger):
                match, content = self.get(trigger)
                self.assertFalse(match)
                self.assertEqual(content, '')

    def test_case_spacing_aliases(self):
        self.assertTrue(self.get('  Digital Ghost Collective  ')[0])
        self.assertTrue(self.get('STUDY-SEPTEMBER')[0])
        self.assertTrue(self.get('gs nullout')[0])
        self.assertTrue(self.get('The Cyber Hangout')[0])

    def test_preview_eggs_do_not_claim_action_started(self):
        for trigger in ('GS BugOut', 'GS BlackOut', 'GS NullOut'):
            result, content = self.get(trigger)
            self.assertTrue(result)
            self.assertIn('GS ', content)
        self.assertIn('No cleanup or shutdown was started.', self.get('GS BugOut')[1])

    def test_color_obeys_explicit_setting(self):
        self.assertNotIn('\033[', self.get('ghostmode', color=False)[1])
        out = self.get('ghostmode', color=True)[1]
        self.assertIn(easter_eggs.PURPLE, out)
        self.assertIn(easter_eggs.GRAY, out)

    def test_hint_command_and_no_packages(self):
        output = self.get('ghostsignal')[1]
        self.assertIn('HIDDEN SIGNALS', output)
        self.assertIn('harmless messages', output)

    def test_integration_with_main_prompt(self):
        seen = []
        with mock.patch.object(gs.os, 'geteuid', return_value=1000), \
             mock.patch.object(gs.sys.stdin, 'isatty', return_value=True, create=True), \
             mock.patch.object(gs.startup_settings, 'ensure_initial_snapshot', return_value='SAVED'), \
             mock.patch.object(gs, 'menu_sub', side_effect=['ghostsignal','dgc',None]), \
             mock.patch.object(gs, 'wait_for_continue', side_effect=lambda:seen.append('wait')), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            gs.main()
        text=output.getvalue()
        self.assertIn('HIDDEN SIGNALS', text)
        self.assertIn('DIGITAL GHOST COLLECTIVE', text)
        self.assertEqual(seen, ['wait','wait'])


if __name__ == '__main__':
    unittest.main()
