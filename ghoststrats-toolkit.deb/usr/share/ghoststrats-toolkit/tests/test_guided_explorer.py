"""V43 guided explorer: read-only number menus and stable main-menu shortcuts."""
import contextlib
import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import gs
import gs_file_explorer as explorer


class GuidedExplorerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'project').mkdir()
        (self.root / 'project' / 'notes.txt').write_text('nonsecret testing text')
        (self.root / 'visible.txt').write_text('hello')
        (self.root / '.hidden').write_text('hidden')
        (self.root / 'shortcut').symlink_to(self.root / 'project')

    def tearDown(self):
        self.tmp.cleanup()

    def scripted(self, sequence):
        output = io.StringIO()
        with mock.patch('builtins.input', side_effect=sequence), contextlib.redirect_stdout(output):
            explorer.browse(self.root)
        return output.getvalue()

    def test_browser_opens_without_initial_path_prompt(self):
        text = self.scripted(['0'])
        self.assertIn('GS FILE EXPLORER', text)
        self.assertIn('visible.txt', text)
        self.assertIn('[13] Up folder', text)
        self.assertIn('[17] Search by name', text)
        self.assertNotIn('Path (you can use', text)

    def test_directory_selection_and_parent(self):
        text = self.scripted(['1', '13', '0'])
        self.assertIn('notes.txt', text)
        self.assertGreaterEqual(text.count('GS FILE EXPLORER'), 3)

    def test_file_action_details_back(self):
        # Directly invoke read-only per-file actions to avoid depending on sorting.
        with mock.patch('builtins.input', side_effect=['1', '', '0']), contextlib.redirect_stdout(io.StringIO()) as out:
            explorer.file_actions(self.root / 'visible.txt')
        self.assertIn('Owner / Group', out.getvalue())
        self.assertIn('FILE DETAILS', out.getvalue())
        self.assertIn('Back to folder', out.getvalue())

    def test_file_preview_requires_explicit_yes(self):
        with mock.patch('builtins.input', side_effect=['3', 'no', '', '0']), contextlib.redirect_stdout(io.StringIO()) as out:
            explorer.file_actions(self.root / 'visible.txt')
        self.assertIn('may display private information', out.getvalue())
        self.assertNotIn('First 4 KiB', out.getvalue())

    def test_hidden_filter_keeps_original_files(self):
        self.assertIn('.hidden', [i.name for i in explorer.browser_entries(self.root)])
        self.assertNotIn('.hidden', [i.name for i in explorer.browser_entries(self.root, False)])
        text = self.scripted(['19', '0'])
        self.assertIn('Hide hidden files', text)

    def test_page_clamped_and_numbers_are_for_current_page(self):
        for i in range(20):
            (self.root / f'new-{i:02d}.txt').touch()
        items = explorer.browser_entries(self.root)
        page, last, lines = explorer.numbered_rows(items, 999)
        self.assertEqual(page, last)
        self.assertLessEqual(len(lines), explorer.BROWSER_PAGE_SIZE)
        # Every on-screen file row has a unique one-based selection number.
        self.assertEqual([int(x.strip().split(']')[0][1:]) for x in lines], list(range(1, len(lines) + 1)))
        inspected = []
        with mock.patch.object(explorer,'file_actions',side_effect=lambda path:inspected.append(path)), \
            mock.patch('builtins.input',side_effect=['11', '1', '0']), \
            contextlib.redirect_stdout(io.StringIO()):
            explorer.browse(self.root)
        self.assertEqual(len(inspected), 1)
        self.assertEqual(inspected[0], Path(explorer.browser_entries(self.root, False)[10].path))

    def test_search_result_selection(self):
        output = io.StringIO()
        with mock.patch('builtins.input',side_effect=['notes', '1']),contextlib.redirect_stdout(output):
            selected = explorer.search_browser(self.root)
        self.assertEqual(selected, self.root / 'project' / 'notes.txt')
        self.assertIn('SEARCH RESULTS', output.getvalue())

    def test_search_cancellation_and_hidden_filter(self):
        with mock.patch('builtins.input',side_effect=['no-match','']), contextlib.redirect_stdout(io.StringIO()):
            self.assertIsNone(explorer.search_browser(self.root))
        with mock.patch('builtins.input',side_effect=['hidden','']), contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertIsNone(explorer.search_browser(self.root, show_hidden=False))
        self.assertIn('No matching entries', out.getvalue())

    def test_symlink_is_inspect_only(self):
        with mock.patch('builtins.input',side_effect=['0']),contextlib.redirect_stdout(io.StringIO()) as out:
            explorer.file_actions(self.root / 'shortcut')
        self.assertNotIn('Calculate SHA-256',out.getvalue())
        self.assertEqual(explorer.metadata(self.root / 'shortcut')['Kind'], 'Symbolic link (not followed)')

    def test_folder_tools_help_menu_returns_cleanly(self):
        with mock.patch('builtins.input',side_effect=['5','', '0']),contextlib.redirect_stdout(io.StringIO()) as out:
            explorer.folder_tools(self.root)
        self.assertIn('File Explorer help',out.getvalue())
        self.assertIn('HELP & LEARNING',out.getvalue())

    def test_original_cli_still_available(self):
        with contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(explorer.main(['--tree',str(self.root),'--limit','30']),0)
        self.assertIn('visible.txt',out.getvalue())
        with contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(explorer.main(['--inspect',str(self.root/'visible.txt')]),0)
        self.assertIn('Regular file',out.getvalue())

    def test_no_unexpected_mutations_when_browsing(self):
        before = {str(f.relative_to(self.root)):f.stat().st_mtime_ns
                  for f in self.root.rglob('*') if not f.is_symlink()}
        self.scripted(['17','17','1','13','0'])
        after = {str(f.relative_to(self.root)):f.stat().st_mtime_ns
                 for f in self.root.rglob('*') if not f.is_symlink()}
        self.assertEqual(before,after)

