"""V79 regression tests: no cursor-hopping, blank redraws, or stranded keys."""
from __future__ import annotations
import io
import unittest
from unittest import mock
import gs
import gs_keys


class MenuLoopStabilityTests(unittest.TestCase):
    def test_main_menu_uses_same_reader_as_other_menus(self):
        with mock.patch.object(gs, 'ui') as draw, \
             mock.patch.object(gs, '_refresh_status', side_effect=AssertionError('flicker')) as forbidden, \
             mock.patch.object(gs, 'remaining', return_value=None), \
             mock.patch.object(gs.gs_keys, 'read_line', return_value='6') as reader:
            self.assertEqual(gs._read_main_choice(gs.main_menu_options()), '6')
            draw.assert_called_once()
            forbidden.assert_not_called()
            self.assertEqual(reader.call_args.kwargs['interval'], 0.2)
            self.assertIs(reader.call_args.kwargs['watchdog'], gs.remaining)

    def test_empty_enter_does_not_repaint_or_start_over(self):
        with mock.patch.object(gs, 'ui') as draw, \
             mock.patch.object(gs, 'remaining', return_value=None), \
             mock.patch.object(gs.gs_keys, 'read_line', side_effect=['', '  ', '19']), \
             mock.patch.object(gs.sys, 'stdout', new_callable=io.StringIO):
            self.assertEqual(gs._read_main_choice([]), '19')
            draw.assert_called_once()

    def test_esc_on_home_is_non_destructive(self):
        with mock.patch.object(gs, 'ui') as draw, \
             mock.patch.object(gs, 'remaining', return_value=None), \
             mock.patch.object(gs.gs_keys, 'read_line', side_effect=[gs_keys.HomeRequested(), '9']):
            self.assertEqual(gs._read_main_choice([]), '9')
            draw.assert_called_once()

    def test_main_menu_zero_still_exits(self):
        with mock.patch.object(gs, 'ui'), \
             mock.patch.object(gs, 'remaining', return_value=None), \
             mock.patch.object(gs.gs_keys, 'read_line', return_value='0'):
            self.assertEqual(gs._read_main_choice([]), '0')
            self.assertIsNone(gs.menu_sub('MAIN MENU', [], show_nullout=True))


if __name__ == '__main__':
    unittest.main()
