"""V81: BLE-disable CLI removed, missing dependency diagnosed accurately, Turbo still starts BLE."""
import contextlib
import io
from pathlib import Path
import types
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'gs-drone-detector.sh').read_text()
BODY=SRC.split('# GS_PYTHON_START\n',1)[1].split('\nGS_PYTHON_EOF',1)[0]
D=types.ModuleType('v81_drone')
exec(compile(BODY,str(ROOT/'gs-drone-detector.sh'),'exec'),D.__dict__)

class BLEAlwaysOn(unittest.TestCase):
    def test_disabled_switch_is_gone(self):
        parser,args=D.make_args([])
        self.assertNotIn('--no-ble',parser.format_help())
        self.assertNotIn('--ble-only',parser.format_help())
        self.assertFalse(hasattr(args,'no_ble'))
        for flag in ('--no-ble','--ble-only'):
            with self.subTest(flag=flag),contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):D.make_args(['scan',flag])

    def test_live_scan_starts_ble_without_disabling_radio(self):
        m=D.Monitor(D.make_args(['scan','--no-wifi','--duration','1','--plain'])[1])
        try:
            with mock.patch.object(m,'ble_thread') as ble, mock.patch.object(m,'_scan_loop'), \
                 mock.patch.object(m,'scan_keyboard',return_value=contextlib.nullcontext(None)), \
                 contextlib.redirect_stdout(io.StringIO()):
                m.run()
            ble.assert_called_once()
            self.assertIsNotNone(m.ble_worker)
        finally:m.close()

    def test_status_reports_unavailable_not_disabled(self):
        m=D.Monitor(D.make_args(['scan','--no-wifi'])[1])
        try:
            real_import=__import__
            def no_bleak(name,*args,**kwargs):
                if name=='bleak':raise ImportError('not installed')
                return real_import(name,*args,**kwargs)
            with mock.patch('builtins.__import__',side_effect=no_bleak):
                import asyncio
                asyncio.run(m.ble_loop())
            self.assertTrue(m.ble_status.startswith('unavailable'))
            self.assertIn('BLE unavailable',m.error)
            self.assertNotIn('disabled',m.error.lower())
        finally:m.close()

    def test_demo_still_skips_real_ble_receiver(self):
        m=D.Monitor(D.make_args(['demo','--duration','1','--plain'])[1])
        try:
            with mock.patch.object(m,'ble_thread') as ble, mock.patch.object(m,'_scan_loop'), \
                 mock.patch.object(m,'scan_keyboard',return_value=contextlib.nullcontext(None)), \
                 contextlib.redirect_stdout(io.StringIO()):m.run()
            ble.assert_not_called()
        finally:m.close()

if __name__=='__main__':unittest.main()
