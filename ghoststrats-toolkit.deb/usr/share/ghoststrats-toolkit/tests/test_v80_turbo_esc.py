"""V80: one Turbo entrypoint, Esc cleanup, no detector submenus."""
import contextlib
from pathlib import Path
import types
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'gs-drone-detector.sh').read_text()
BODY=SOURCE.split('# GS_PYTHON_START\n',1)[1].split('\nGS_PYTHON_EOF',1)[0]
D=types.ModuleType('gs_drone_v80')
exec(compile(BODY,str(ROOT/'gs-drone-detector.sh'),'exec'), D.__dict__)

class TurboEscTests(unittest.TestCase):
    def test_default_command_is_turbo_immediate(self):
        args=D.make_args([])[1]
        self.assertEqual(args.command,'scan')
        self.assertEqual((args.interval,args.refresh,args.dwell),(3,0.15,0.5))
        self.assertFalse(hasattr(args,'no_ble'))
        self.assertFalse(args.no_wifi)

    def test_old_menu_pairing_and_balanced_modes_removed(self):
        self.assertNotIn('def menu():',SOURCE)
        self.assertNotIn('def ble_pair_helper():',SOURCE)
        self.assertNotIn('FAST (5s Wi-Fi',SOURCE)
        self.assertNotIn('Pair/connect my OWN BLE drone',SOURCE)

    def test_esc_stops_loop_before_triggering_new_scans(self):
        m=D.Monitor(D.make_args(['scan','--no-wifi'])[1])
        try:
            with mock.patch.object(m,'escape_requested',return_value=True),\
                 mock.patch.object(m,'wifi_survey_once',side_effect=AssertionError('scan continued')):
                m._scan_loop(20)
            self.assertTrue(m.stop.is_set())
        finally:m.close()

    def test_bare_esc_ends_scan_but_arrow_does_not(self):
        with mock.patch.object(D.select,'select',side_effect=[([1],[],[]),([],[],[])]),\
             mock.patch.object(D.os,'read',return_value=b'\x1b'):
            self.assertTrue(D.Monitor.escape_requested(1))
        with mock.patch.object(D.select,'select',side_effect=[([1],[],[]),([1],[],[]),([],[],[])]),\
             mock.patch.object(D.os,'read',side_effect=[b'\x1b',b'[']):
            self.assertFalse(D.Monitor.escape_requested(1))

    def test_close_terminates_active_wifi_process(self):
        m=D.Monitor(D.make_args(['scan','--no-wifi'])[1])
        proc=mock.Mock()
        proc.poll.return_value=None
        with m.wifi_process_lock:m.wifi_process=proc
        m.close()
        proc.terminate.assert_called_once()
        proc.wait.assert_called_once()

    def test_parent_launches_scan_not_submenu(self):
        import gs
        with mock.patch.object(gs.subprocess,'run',return_value=types.SimpleNamespace(returncode=0)) as command:
            result=gs.launch_drone_detector()
        self.assertEqual(command.call_args.args[0][-1], 'scan')
        self.assertIn('main menu',result)

if __name__=='__main__':unittest.main()
