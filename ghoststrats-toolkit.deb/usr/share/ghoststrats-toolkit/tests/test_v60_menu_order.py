"""Regression tests: V61 main-menu shortcuts must display 1..19 in reading order."""
import contextlib
import io
import os
import re
import unittest
from unittest import mock
import gs

ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')

class NumericMainMenuTests(unittest.TestCase):
    def test_source_sections_in_order(self):
        ids = [int(key) for _, entries in gs.MAIN_SECTIONS for key, _ in entries]
        self.assertEqual(ids, list(range(1,20)))
        self.assertEqual(dict((int(k), v) for _, e in gs.MAIN_SECTIONS for k, v in e)[4], 'GS BugOut')

    def test_visible_order_and_fit_at_supported_widths(self):
        for width in (40, 48, 54, 60, 70, 80, 100, 120):
            with self.subTest(columns=width):
                output = io.StringIO()
                with mock.patch.object(gs.shutil, 'get_terminal_size', return_value=os.terminal_size((width,24))), contextlib.redirect_stdout(output):
                    gs.ui('MAIN MENU', gs.main_menu_options(), None, show_nullout=True)
                plain = ANSI.sub('',output.getvalue())
                rows = plain.splitlines()
                self.assertLessEqual(len(rows), 24)  # Compact menu fits without scrolling
                self.assertTrue(all(len(row) <= width for row in rows))
                # Read one stacked option per line from top to bottom.
                body = '\n'.join(row for row in rows if row.startswith('  │'))
                found = [int(n) for n in re.findall(r'\[(\d+)\]\s+',body) if n!='0']
                self.assertEqual(sorted(found), list(range(1,20)), f'{width}: {found}')
                self.assertIn('[4]',body)
                self.assertIn('[0] EXIT', plain)

    def test_bugout_keeps_handler_and_preview(self):
        with mock.patch.object(gs, 'persistent_menu') as capture:
            gs.sub_bugout()
        self.assertEqual(capture.call_args.args[0],'GS BUGOUT')
        self.assertEqual(set(capture.call_args.args[2]), {'1','2'})

if __name__ == '__main__':
    unittest.main()
