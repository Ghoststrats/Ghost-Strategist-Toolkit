#!/usr/bin/env python3
"""Read-only educational persistence and privacy residue checks.

Uses Python 3 standard library and bounded system commands. Does NOT classify
malware, erase traces, tamper with autostarts, disable services, or inspect
file contents. It does not create reports or baseline files.
"""
from gs_brand import print_gs as print
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile

HOME = Path.home()
STATE = Path(os.getenv('XDG_STATE_HOME', str(HOME / '.local' / 'state'))) / 'ghost-strategist-tool'
BASELINE = STATE / 'persistence_baseline.json'
VERSION = 1
SKIP = {'__pycache__'}
MAX_ITEMS = 80


def run_cmd(args, timeout=7):
    """Run fixed argument arrays only (never shell input)."""
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                                errors='replace', check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, str(exc)
    if result.returncode != 0:
        return None, (result.stderr.strip() or result.stdout.strip() or
                      f'Command returned {result.returncode}')[:240]
    return result.stdout, None


def show_path(path):
    try:
        s = path.lstat()  # Never follow symlinks when reporting files.
        kind = 'link' if stat.S_ISLNK(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'file'
        stamp = dt.datetime.fromtimestamp(s.st_mtime).strftime('%Y-%m-%d %H:%M')
        return f'{kind:9} {s.st_size:>9} bytes  {stamp}  {path}'
    except (OSError, ValueError) as exc:
        return f'UNAVAILABLE {path} ({exc})'


def folder_listing(dirs, limit=MAX_ITEMS):
    seen = 0
    for folder in dirs:
        print(f'\n  {folder}:')
        try:
            entries = sorted(folder.iterdir(), key=lambda p: p.name.casefold())
        except (OSError, PermissionError) as exc:
            print('    Not accessible:', str(exc)[:120]); continue
        if not entries:
            print('    No entries'); continue
        available = max(0, limit-seen)
        for path in entries[:available]:
            print('   ', show_path(path))
            seen += 1
        if len(entries) > available:
            print('    (Output limited; not a complete inventory.)')
        if seen >= limit:
            print('  Stopped at', limit, 'entries to avoid overwhelming the terminal.')
            break


def startup_apps():
    print('\nSTARTUP APPLICATIONS — read-only')
    print(' .desktop files can automatically launch apps when a desktop session begins.')
    folder_listing([HOME/'.config'/'autostart', Path('/etc/xdg/autostart')])
    print('\nNote: an entry is not inherently malicious; inspect unexpected names carefully.')


def enabled_services():
    print('\nBACKGROUND SERVICES — read-only')
    print('Systemd services can start automatically even when no app window is open.')
    for label, args in [('SYSTEM SERVICES', ['systemctl', 'list-unit-files', '--type=service', '--state=enabled', '--no-pager', '--no-legend']),
                        ('USER SERVICES', ['systemctl', '--user', 'list-unit-files', '--type=service', '--state=enabled', '--no-pager', '--no-legend'])]:
        print('\n'+label)
        output, error = run_cmd(args)
        if error: print('  Unavailable:', error); continue
        lines = [s for s in output.splitlines() if s.strip()]
        for line in lines[:40]: print('  '+line[:180])
        if len(lines)>40: print(f'  ... {len(lines)-40} more (limited output)')
    print('\nEnabled is not always running. Read service names as context, not a malware verdict.')


def schedules():
    print('\nSCHEDULED TASKS — read-only')
    print('Cron jobs and systemd timers can execute even when you are not using the computer.')
    for label, args in [('USER CRONTAB', ['crontab','-l']),
                        ('ACTIVE SYSTEM TIMERS', ['systemctl','list-timers','--all','--no-pager','--no-legend']),
                        ('USER TIMERS', ['systemctl','--user','list-timers','--all','--no-pager','--no-legend'])]:
        print('\n'+label)
        output,error=run_cmd(args)
        if error:
            if 'no crontab for' in error.lower(): print('  No user crontab.'); continue
            print('  Unavailable:', error); continue
        lines=output.splitlines()
        if label=='USER CRONTAB':
            # Avoid displaying arguments, tokens, or secrets inside cron commands.
            active=[s for s in lines if s.strip() and not s.strip().startswith('#')]
            print(f'  {len(active)} active non-comment cron entries (commands hidden for privacy)')
        else:
            for line in lines[:20]: print('  '+line[:160])
            if len(lines)>20: print('  ... more rows not shown')
    print('\nSystem cron locations (file metadata only):')
    folder_listing([Path('/etc/cron.d'), Path('/etc/cron.daily')],limit=35)


def login_hooks():
    print('\nLOGIN / PERSISTENCE HOOKS — read-only')
    print('Shell profiles and user service files can run code at login or terminal startup.')
    paths = [HOME/'.profile', HOME/'.bash_profile',HOME/'.bashrc',
             HOME/'.zshrc', HOME/'.config'/'systemd'/'user',
             HOME/'.config'/'autostart', Path('/etc/rc.local')]
    for path in paths:
        if path.is_symlink() or path.exists(): print(' ',show_path(path))
    print('\nRecent changes need context. A changed shell profile is not proof of compromise.')


def recent_changes():
    print('\nRECENT SYSTEM CHANGES — read-only')
    print('Shows last modification times for common package and startup configuration files.')
    paths = [Path('/var/log/apt/history.log'), Path('/var/log/dpkg.log'),
             Path('/etc/crontab'), Path('/etc/ssh/sshd_config'),
             HOME/'.bashrc', HOME/'.profile', HOME/'.config'/'autostart',
             HOME/'.config'/'systemd'/'user']
    present=[]
    for p in paths:
        try:
            if p.is_symlink() or p.exists(): present.append((p.lstat().st_mtime,p))
        except OSError: pass
    for _,p in sorted(present,reverse=True)[:20]: print(' ',show_path(p))
    if not present: print('  No accessible tracked paths found.')
    print('\nOnly metadata is displayed. This is NOT a complete change-history log.')


def _directory_summary(path, max_entries=2000):
    try:
        if not path.is_dir(): return 'not present'
        count=0
        for _,names,files in os.walk(path,followlinks=False):
            count += len(names)+len(files)
            if count>=max_entries: return f'>={max_entries} entries (capped)'
        return f'{count} entries'
    except (OSError,PermissionError) as exc:
        return f'unavailable ({exc})'


def privacy_traces():
    print('\nPRIVACY RESIDUE — file metadata only')
    print('Local app history, recent-file lists, thumbnails, and trash may persist on disk.')
    tracked = [HOME/'.bash_history', HOME/'.zsh_history',
               HOME/'.local/share/recently-used.xbel',
               HOME/'.cache/thumbnails', HOME/'.local/share/Trash',
               HOME/'.mozilla/firefox', HOME/'.config/chromium']
    for p in tracked:
        if not (p.is_symlink() or p.exists()): continue
        detail=show_path(p)
        if p.is_dir(): detail += f'  [{_directory_summary(p)}]'
        print(' ',detail)
    print('\nNo history contents, browser data, files, passwords, or cookies are read or erased.')
    print('These are possible traces, not proof of tracking. Running this tool can itself leave normal OS traces.')


ACTIONS = {
    '1': startup_apps, '2': enabled_services, '3': schedules,
    '4': login_hooks, '5': recent_changes, '6': privacy_traces,
}
