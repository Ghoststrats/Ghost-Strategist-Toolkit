# V80 — GS Drone Detector Turbo-only + Esc to Home

- Main menu [6] now immediately launches a single continuous Turbo drone scan (no detector submenu).
- Removed visible Fast, Balanced, BLE-only, demo, pairing, vendor update and other menu entries. Wi-Fi + BLE are combined automatically where supported.
- Default Wi-Fi scan-request period 3s; screen refresh 0.15s; optional monitor-channel dwell 0.5s.
- Single Esc key stops the active scan, terminates an in-flight Wi-Fi subprocess, stops BLE discovery and restores TTY input before returning to the main Ghost Strategist Toolkit menu.
- Ctrl+C remains a secondary exit method. Earlier detector signal-color warnings and drone-only matching remain.
- Standalone Bash script also launches Turbo immediately; diagnostic CLI self-test remains available for developers.
- Real DJI Neo compatibility remains hardware/firmware-dependent and unverified.
