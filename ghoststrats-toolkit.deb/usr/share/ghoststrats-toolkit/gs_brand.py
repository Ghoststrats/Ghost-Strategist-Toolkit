"""Ghost Strategist terminal branding: color standalone GS initials purple."""
import builtins
import os
import re
import sys
PURPLE = "\033[38;5;141m"
RESET = "\033[0m"
PATTERN = re.compile(r"(?<![A-Za-z0-9_])GS(?![A-Za-z0-9_])")

def color_gs(value):
    if os.environ.get("NO_COLOR") is not None or not sys.stdout.isatty():
        return str(value)
    return PATTERN.sub(PURPLE + "GS" + RESET, str(value))

def print_gs(*args, **kwargs):
    stream = kwargs.get("file", sys.stdout)
    if stream is sys.stdout and os.environ.get("NO_COLOR") is None and sys.stdout.isatty():
        args = tuple(color_gs(a) for a in args)
    return builtins.print(*args, **kwargs)
