# V77 — GS Drone Detector faster live scanning

- FAST live mode requests a Wi-Fi scan every 5 seconds rather than 12; BLE continues listening asynchronously.
- Optional TURBO mode uses 3-second Wi-Fi requests, 0.5-second monitor dwell and 0.15-second terminal refresh.
- Balanced mode retains slower 12-second scans, 3-second dwell, and 0.6-second refresh.
- Bounded reception queue and deduplicated non-RID beacons prevent large captures from freezing the terminal.
- Monitor hopping supports subsecond dwell (0.25-60 seconds), except for single-channel monitoring which stays tuned.
- Existing color warning thresholds, identification confidence and safety limitations are unchanged.
- Physical scan cadence and range are adapter/driver-dependent. Increased scan requests may interrupt networking.
- Continuous BLE/monitor capture and fast dashboard responses are not universal drone-detection guarantees.
