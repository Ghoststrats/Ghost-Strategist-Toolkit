#!/usr/bin/env bash
# Read-only verification of current supported GS BlackOut controls.
# Presence of a firewall deny rule is not proof of network isolation.
set -u
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
msg(){ printf '%s\n' "$*"; }
has(){ command -v "$1" >/dev/null 2>&1; }
read_nm(){ local state; state="$(nmcli "$@" 2>/dev/null)" || { printf 'unknown'; return; }; printf '%s' "$state"; }
service_state(){
  local unit="$1" loaded
  if ! has systemctl; then echo unavailable; return; fi
  loaded="$(systemctl show -p LoadState --value "$unit" 2>/dev/null)" || { echo unknown; return; }
  if [[ "$loaded" != loaded ]]; then echo unavailable
  elif systemctl is-active --quiet "$unit" 2>/dev/null; then echo active
  else echo inactive; fi
}
msg 'GS BLACKOUT — READ-ONLY VERIFICATION'
msg 'These checks inspect current Linux software states, not physical isolation.'
msg ''
if has nmcli; then
  msg "Wi-Fi software radio: $(read_nm radio wifi) (target: disabled)"
  msg "NetworkManager networking: $(read_nm networking) (target: disabled)"
  msg "Mobile broadband: $(read_nm radio wwan) (target: disabled if previously on)"
else msg 'NetworkManager unavailable; wireless/network status UNKNOWN'; fi
if has rfkill; then
  msg 'Bluetooth software block (rfkill):'
  rfkill list bluetooth 2>/dev/null | grep -E 'Soft blocked:|Hard blocked:' || msg '  Bluetooth adapter unavailable or not detected.'
else msg 'Bluetooth rfkill: UNKNOWN (tool unavailable)'; fi
if has bluetoothctl; then
  bt="$(bluetoothctl show 2>/dev/null | grep -m1 'Powered:' || true)"
  msg "Bluetooth controller: ${bt:-unknown}"
fi
if has pactl; then
  msg "Default microphone: $(pactl get-source-mute @DEFAULT_SOURCE@ 2>/dev/null || echo unknown)"
  msg "Default speakers: $(pactl get-sink-mute @DEFAULT_SINK@ 2>/dev/null || echo unknown)"
else msg 'Microphone/speaker mute state: UNKNOWN (pactl unavailable)'; fi
if [[ -d /sys/module/uvcvideo ]]; then msg 'UVC camera kernel module: LOADED — camera may remain available'
else msg 'UVC camera kernel module: not loaded'; fi
msg 'Other cameras, microphones and applications may use separate hardware/drivers.'
msg ''
msg 'Known socket/service activation units:'
for unit in avahi-daemon.socket avahi-daemon.service cups.socket cups.path cups.service bluetooth.service ssh.socket ssh.service sshd.socket sshd.service smbd.service nmbd.service; do
  state="$(service_state "$unit")"
  [[ "$state" == unavailable ]] || printf '  %-27s %s\n' "$unit" "$state"
done
msg ''
if has ufw; then
  if ufw_status="$(LC_ALL=C sudo -n ufw status numbered 2>/dev/null)"; then
    if grep -q '^Status: active' <<< "$ufw_status"; then
      msg 'UFW: ACTIVE'
    else msg 'UFW: INACTIVE — BlackOut firewall is NOT ACTIVE'; fi
    if grep -Fq '# GST_PORT_ALL_V22' <<< "$ufw_status"; then
      msg 'GS tagged inbound DENY rule: PRESENT (check preceding rules/UFW before.rules)'
    else msg 'GS tagged inbound DENY rule: NOT FOUND (standalone/older rules may differ)'; fi
    # Show the first few numbered rules, which reveal possible precedence issues.
    printf '%s\n' "$ufw_status" | grep -E '^\[[[:space:]]*[0-9]+\]' | head -n 8 || true
  else msg 'UFW: UNKNOWN (read-only sudo authorization unavailable; run sudo -v then retry)'; fi
else msg 'UFW: unavailable'; fi
msg ''
msg 'WARNING: No software-only tool guarantees anonymity, complete port closure or physical isolation.'
msg 'If an unexpected feature remains active, BlackOut is INCOMPLETE on this system.'
