# Install Ghost Strategist Toolkit V81 on Linux

GhostStrats Toolkit is a Bash/Python terminal application. **Do not run as root.**

## Supported installation choices

| Distribution | Recommended route | Limitations |
| --- | --- | --- |
| Linux Mint | `Install-and-Run.sh` or V81 `.deb` | Designed and tested in software; test physical hardware controls separately |
| Kali Linux | `Install-and-Run.sh` or V81 `.deb` | Some programs and services may be absent; X11 needed for NullOut |
| Parrot OS | `Install-and-Run.sh` or V81 `.deb` | Wayland defaults on recent Parrot releases; NullOut requires X11 |
| Tails | `Install-and-Run.sh` **only** | **Restricted inspection mode**; install usually disappears after shutdown |
| Debian/Ubuntu-based | `Install-and-Run.sh` | Experimental; varies by system configuration |

## Install and launch — all four Linux systems

Extract the **complete** V81 ZIP and open a terminal in the `GhostStrats-Toolkit` directory.

```bash
./Install-and-Run.sh --check      # reports OS and display session; no changes
./Install-and-Run.sh              # installs for current user, adds launcher and starts
```

If your extraction strips execute permission:

```bash
bash Install-and-Run.sh
```

To install without launching:

```bash
./Install-and-Run.sh --install-only
```

After installation, use `ghoststrats-toolkit` or `~/.local/bin/ghoststrats-toolkit`. The desktop menu shows **GhostStrats Toolkit**. This installer never invokes `sudo`, `apt`, or `pip`. Optional modules show limitations when dependencies are missing. Uninstall per-user files with `./Uninstall-GhostStrats.sh` from the source folder; user-created state/logs remain.

## Alternative system installer (Mint / Kali / Parrot only)

```bash
sudo apt install ./ghoststrats-toolkit_8.1.0_all.deb
# Launch as your regular user; NEVER sudo this command:
ghoststrats-toolkit
```

The `.deb` installs a desktop launcher and terminal command. It does not start the toolkit at install time. Remove with `sudo apt remove ghoststrats-toolkit`.

**Never use the `.deb` package on Tails.**

## Tails special behavior

The per-user installer detects Tails and the program enters restricted mode automatically. Only inspection actions [3], [5], [9], [13] (except Wi-Fi AP scan), [16], [18], and [H] are available. No BlackOut, BugOut, NullOut, Drone Detector, radio changes, UFW lockdown, DHCP changes, or active scanning can be launched from the toolkit UI.

Tails is an intentionally restrictive amnesic operating system. Per-user toolkit installation will **usually not persist across reboot** unless intentionally placed in configured Persistent Storage. Nothing in this project overrides Tor routing or the Tails firewall. This is not an anonymity assurance. The menu restrictions are not a secure sandbox: direct execution of bundled scripts is outside their scope. Do not use the toolkit to alter Tails' network or firewall policies.

## Wayland vs X11

Kali GNOME/KDE and modern Parrot KDE may use **Wayland**. GS NullOut requires the X11 idle library and correctly refuses to arm under Wayland. Other tools are independent of this requirement. Check with `echo "$XDG_SESSION_TYPE"`.

## Dependencies

Basic: Bash, Python 3, `ps` (procps). Optional module-specific commands include `ip`, `ss`, `nmcli`, `rfkill`, `pactl`, `ufw`, `iw`, `bluetoothctl`, and Python Scapy. The installer never installs these automatically; always assess packages and permissions yourself. For Tails, do not install extra packages merely to satisfy the toolkit.

## Safety and verification

```bash
python3 -m unittest discover -s tests -q
bash gs-drone-detector.sh test
```

Run scanning only on systems and networks you're authorized to inspect. Test administrative changes on a noncritical device. Tails restrictions and software tests cannot guarantee OS-level privacy or hardware support.
