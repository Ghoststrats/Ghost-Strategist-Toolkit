#!/usr/bin/env python3
"""UFW adapter that elevates only the specific operation, never the toolkit."""
from gs_brand import print_gs as print
import gs_keys
import shutil
import subprocess
import sys


def run(argv):
    if not shutil.which(argv[0]):
        print('! Required command is missing: ' + argv[0]); return 127
    try:
        return subprocess.run(argv, check=False).returncode
    except OSError as exc:
        print('! Could not run command:', exc); return 1


def status_command(mode, *, executor=subprocess.run, request_input=input):
    """Try read-only UFW status normally; ask for sudo if it is restricted."""
    args = ['ufw', 'status']
    if mode == 'verbose':
        args.append('verbose')
    elif mode == 'rules':
        args.append('numbered')
    try:
        initial = executor(args, text=True, capture_output=True, check=False)
    except OSError as exc:
        print('! UFW status unavailable:', exc)
        return 1
    if initial.returncode == 0:
        print(initial.stdout, end='' if initial.stdout.endswith('\n') else '\n')
        print('! Read-only firewall inspection complete.')
        return 0
    reason = (initial.stderr or initial.stdout or '').strip()
    print('! UFW status requires administrator access on this Linux installation.')
    if reason and 'root' not in reason.lower() and 'permission' not in reason.lower():
        print('! UFW also reported:', reason.splitlines()[0][:180])
    if not shutil.which('sudo'):
        print('! sudo is unavailable. No changes made.')
        return initial.returncode or 1
    try:
        reply = request_input('Check firewall status with sudo? [y/N]: ').strip().lower()
    except (EOFError, KeyboardInterrupt):
        reply = ''
    if reply != 'y':
        print('! Cancelled. No settings changed.')
        return 0
    code = run(['sudo', 'ufw', *args[1:]])
    if code == 0:
        print('! Read-only status displayed with temporary administrator authorization.')
    else:
        print('! Could not read UFW status, even after authorization.')
    return code


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('status','verbose','rules','enable','disable'):
        print('Usage: firewall-controls.py [status|verbose|rules|enable|disable]')
        return 2
    if not shutil.which('ufw'):
        print('! UFW is not installed. No firewall changes made.')
        print('! Install it using Linux Mint package management if you want UFW controls.')
        return 127
    mode = sys.argv[1]
    if mode in ('status', 'verbose', 'rules'):
        return status_command(mode,request_input=gs_keys.read_line)
    if not shutil.which('sudo'):
        print('! sudo not installed; firewall cannot be changed.')
        return 127
    cmd = ['sudo', 'ufw', '--force', 'enable' if mode=='enable' else 'disable']
    result = run(cmd)
    if result:
        print(f'! Firewall command failed (exit {result}). Review administrator permissions.')
        return result
    print('! UFW command completed. Verifying current state...')
    # Do not ask a second sudo question after privileged action.
    status = run(['sudo','ufw','status','verbose'])
    if status:
        print('! Verification unavailable: do not assume the firewall changed.')
    return status

if __name__ == '__main__':
    sys.exit(main())
