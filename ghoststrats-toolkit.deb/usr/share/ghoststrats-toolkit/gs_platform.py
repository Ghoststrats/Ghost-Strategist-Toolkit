#!/usr/bin/env python3
"""Read-only distribution/session detection for GhostStrats Toolkit.

Not a security sandbox. Tails mode is a safety-oriented UI restriction only;
untrusted/malicious code, or direct shell execution of bundled files, is not contained.
"""
from __future__ import annotations

import os
import re
from pathlib import Path


TAILS_ALLOWED = frozenset({'3', '5', '9', '13', '16', '18', 'h'})


def parse_os_release(contents: str) -> dict[str, str]:
    entries = {}
    for raw in contents.splitlines():
        raw = raw.strip()
        if not raw or raw.startswith('#') or '=' not in raw:
            continue
        key, value = raw.split('=', 1)
        if not re.fullmatch(r'[A-Z][A-Z0-9_]*', key):
            continue
        value = value.strip()
        if value[:1] in {'"', "'"} and value[-1:] == value[:1]:
            value = value[1:-1]
            value = value.replace('\\"', '"').replace('\\\\', '\\')
        entries[key] = value
    return entries


def identify(metadata: dict[str, str], tails_marker: bool = False) -> str:
    identity = metadata.get('ID', '').lower()
    like = metadata.get('ID_LIKE', '').lower().split()
    name = metadata.get('NAME', '').lower()
    if tails_marker or identity == 'tails' or 'tails' in name:
        return 'tails'
    if identity in ('linuxmint', 'mint'):
        return 'mint'
    if identity == 'kali':
        return 'kali'
    if identity in ('parrot', 'parrotsec') or name.startswith('parrot'):
        return 'parrot'
    if identity in ('debian', 'ubuntu') or 'debian' in like or 'ubuntu' in like:
        return 'debian-family'
    return 'other-linux'


def detect(release_file: Path | str = '/etc/os-release',
           tails_file: Path | str = '/etc/tails-version') -> str:
    try:
        contents = Path(release_file).read_text(encoding='utf-8', errors='replace')
    except OSError:
        contents = ''
    return identify(parse_os_release(contents), Path(tails_file).is_file())


def label(family: str) -> str:
    return {
        'mint': 'Linux Mint', 'kali': 'Kali Linux',
        'parrot': 'Parrot OS', 'tails': 'Tails (restricted session mode)',
        'debian-family': 'Debian / Ubuntu family (experimental)',
        'other-linux': 'Other Linux (experimental)',
    }.get(family, 'Unknown Linux')


def session() -> str:
    return os.environ.get('XDG_SESSION_TYPE', 'unknown').strip().lower() or 'unknown'


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Identify current Linux family; does not modify the system.')
    parser.add_argument('--id', action='store_true')
    parser.add_argument('--label', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--os-release', default='/etc/os-release', help=argparse.SUPPRESS)
    parser.add_argument('--tails-marker', default='/etc/tails-version', help=argparse.SUPPRESS)
    args = parser.parse_args()
    family = detect(args.os_release, args.tails_marker)
    if args.label:
        print(label(family))
    elif args.check:
        print('Operating system: ' + label(family))
        print('Desktop session: ' + session())
        print('Install type: unprivileged per-user files + application launcher')
        if family == 'tails':
            print('Tails: restricted toolset; no administrative installs or network/firewall changes.')
            print('Tails: installation is normally temporary and may disappear after shutdown.')
        else:
            print('Commands unavailable on this machine are skipped or reported by diagnostics.')
        if session() == 'wayland':
            print('GS NullOut: system-wide inactivity shutdown unavailable under Wayland.')
    else:
        print(family)
