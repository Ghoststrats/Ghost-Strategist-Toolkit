# V78 — Drone-only BLE detection and optional pairing

- Removed RC-car and unrelated radio-device categories from GS Drone Detector candidate dashboards, alerts, logs and demo. Other toolkit modules are unchanged.
- Dedicated **[10] BLE DRONE SCAN** listens continuously for named drone BLE advertisements or supported Open Drone ID 0xFFFA messages using BlueZ / Bleak, with existing signal colors and warning thresholds.
- **[11] Pair/connect my OWN BLE drone** invokes BlueZ only after manually entering a BLE address and explicitly confirming ownership. No automatic pairing or flight controls.
- Displays supported BLE service UUIDs, Bluetooth company ID hints, advertised TX power, RSSI and decoded Remote ID telemetry when provided.
- No radio-driver or proprietary DJI protocol implementation: Bluetooth support depends on OS, adapter, drone firmware and advertisement mode.
- 200 automated tests passed, including six new drone-only / BLE / consent tests, plus embedded decoder self-test. Physical wireless tests not performed.
