#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $(id -u) -eq 0 ]]; then
  echo 'Run Ghost Strategist Toolkit as your regular user, not root.'
  exit 1
fi
exec python3 ./gs.py
