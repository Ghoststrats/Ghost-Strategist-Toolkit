#!/usr/bin/env python3
"""GS File Explorer & Analysis | educational, local, read-only filesystem inspection.

Standard-library only. Does not install software, modify files, or follow
symlinked directories during recursive searches.
"""
from __future__ import annotations
from gs_brand import print_gs as print

import argparse
import datetime as dt
import fnmatch
import hashlib
import mimetypes
import os
from pathlib import Path
import pwd
import grp
import shutil
import stat
import subprocess
import sys
from typing import Iterator
import gs_keys

PURPLE = '\033[38;5;141m'
MUTED = '\033[38;5;245m'
YELLOW = '\033[38;5;221m'
RED = '\033[38;5;203m'
GREEN = '\033[38;5;120m'
RESET = '\033[0m'
BOLD = '\033[1m'
VIRTUAL_ROOTS = {Path('/proc'), Path('/sys'), Path('/dev'), Path('/run')}
PAGE_SIZE = 20
BROWSER_PAGE_SIZE = 10
SEARCH_RESULT_LIMIT = 250



def ink(text: str, color: str = PURPLE) -> str:
    if not sys.stdout.isatty() or os.environ.get('NO_COLOR'):
        return text
    return color + text + RESET


def safe(text: object, max_length: int = 160) -> str:
    s = str(text)
    s = ''.join(c if c.isprintable() else '?' for c in s)
    return s[: max_length - 1] + '…' if len(s) > max_length else s


def header(title: str, subtitle: str) -> None:
    """Compact, consistently bounded filesystem header for every explorer view."""
    width = max(42, min(82, shutil.get_terminal_size((82, 24)).columns - 6))
    inner = width - 2
    def line(value: str, color: str = MUTED):
        value = safe(value, inner - 4)
        content = '  ' + value
        print(ink('  │', MUTED) + ink(content.ljust(inner), color) + ink('│', MUTED))
    print('\n' + ink('  ┌' + '─' * inner + '┐', PURPLE))
    line('GHOST STRATEGIST   /   FILE EXPLORER', BOLD + PURPLE)
    print(ink('  ├' + '─' * inner + '┤', MUTED))
    line(title.upper(), BOLD + PURPLE)
    line(subtitle, MUTED)
    print(ink('  └' + '─' * inner + '┘', MUTED))

def note(msg: str) -> None:
    print(ink('  INFO  ', PURPLE) + msg)


def warn(msg: str) -> None:
    print(ink('  NOTE  ', YELLOW) + msg)


def issue(msg: str) -> None:
    print(ink('  ERROR ', RED) + msg)


def ask(prompt: str, default: str = '') -> str:
    suffix = f' [{default}]' if default else ''
    answer = gs_keys.read_line(f'{prompt}{suffix}: ').strip()
    return answer if answer else default


def path_prompt(default: Path = Path.home(), require_dir: bool = False) -> Path | None:
    raw = ask('Path (you can use ~, /, or a mounted USB path)', str(default))
    p = Path(os.path.expandvars(raw)).expanduser().absolute()
    try:
        if not p.exists() and not p.is_symlink():
            issue('That path does not exist.')
            return None
        if require_dir and not p.is_dir():
            issue('Please enter a directory.')
            return None
    except (OSError, ValueError) as exc:
        issue(f'Cannot access path: {safe(exc)}')
        return None
    return p


def sort_children(path: Path) -> list[os.DirEntry[str]]:
    # Each DirEntry is only used for paths/metadata (no file content is read).
    with os.scandir(path) as iterator:
        items = list(iterator)
    def sort_key(item: os.DirEntry[str]):
        try:
            is_dir = item.is_dir(follow_symlinks=False)
        except OSError:
            is_dir = False
        return (not is_dir, item.name.casefold())
    return sorted(items, key=sort_key)


def skip_virtual(path: Path, exclude_virtual: bool) -> bool:
    return exclude_virtual and path in VIRTUAL_ROOTS


def fmt_size(n: int) -> str:
    value = float(n)
    for unit in ('B', 'KiB', 'MiB', 'GiB', 'TiB'):
        if value < 1024 or unit == 'TiB':
            return f'{int(value)} {unit}' if unit == 'B' else f'{value:.1f} {unit}'
        value /= 1024
    return str(n)


def tree_lines(base: Path, depth_limit: int | None = 3,
               max_entries: int | None = 500,
               exclude_virtual: bool = True) -> Iterator[str]:
    """Yield a bounded folder tree, including dotfiles; never recurse into symlinks."""
    yield safe(base)
    count = 0
    stopped = False

    def descend(folder: Path, prefix: str, depth: int) -> Iterator[str]:
        nonlocal count, stopped
        if stopped or (depth_limit is not None and depth >= depth_limit):
            return
        try:
            children = sort_children(folder)
        except (OSError, PermissionError) as exc:
            yield prefix + '└── ' + f'[unreadable: {safe(exc)}]'
            return
        for index, item in enumerate(children):
            if stopped:
                return
            if max_entries is not None and count >= max_entries:
                yield prefix + '└── [limit reached: choose a higher limit to see more]'
                stopped = True
                return
            last = index == len(children) - 1
            branch = '└── ' if last else '├── '
            next_prefix = prefix + ('    ' if last else '│   ')
            p = Path(item.path)
            symlink = item.is_symlink()
            is_dir = item.is_dir(follow_symlinks=False)
            suffix = '/' if is_dir else ''
            if symlink:
                try:
                    suffix = ' -> ' + safe(os.readlink(p), 90)
                except OSError:
                    suffix = ' -> [unreadable link]'
            elif skip_virtual(p, exclude_virtual):
                suffix = '/ [virtual filesystem skipped]'
            count += 1
            yield prefix + branch + safe(item.name, 100) + suffix
            if is_dir and not skip_virtual(p, exclude_virtual):
                yield from descend(p, next_prefix, depth + 1)

    yield from descend(base, '', 0)


def iter_files(root: Path, max_inspected: int = 75000,
               exclude_virtual: bool = True) -> Iterator[Path]:
    """Walk files and dirs including dotfiles. Symlink dirs aren't traversed."""
    checked = 0
    stack = [root]
    while stack and checked < max_inspected:
        node = stack.pop()
        if skip_virtual(node, exclude_virtual):
            continue
        checked += 1
        yield node
        try:
            if node.is_symlink() or not node.is_dir():
                continue
            children = sort_children(node)
            # Reversed so results appear in sorted order under the stack.
            stack.extend(Path(item.path) for item in reversed(children))
        except (PermissionError, OSError):
            continue


def hidden_matches(root: Path, max_inspected: int = 75000) -> Iterator[Path]:
    for path in iter_files(root, max_inspected=max_inspected):
        if path != root and path.name.startswith('.'):
            yield path


def name_matches(root: Path, query: str,
                 max_inspected: int = 75000) -> Iterator[Path]:
    glob = '*' + query.casefold().strip('*') + '*'
    for path in iter_files(root, max_inspected=max_inspected):
        if path != root and fnmatch.fnmatchcase(path.name.casefold(), glob):
            yield path


def show_paginated(lines: Iterator[str], title: str = '',
                   max_lines: int | None = None, interactive: bool = True) -> int:
    if title:
        print(ink('\n' + title, PURPLE))
    printed = 0
    try:
        for line in lines:
            if max_lines is not None and printed >= max_lines:
                warn(f'Display cap of {max_lines} results reached. Narrow the search to see others.')
                break
            print(line)
            printed += 1
            if interactive and printed % PAGE_SIZE == 0:
                answer = gs_keys.read_line(ink('  Enter = next page  |  q = stop  |  Esc = toolkit home: ', MUTED)).strip().lower()
                if answer == 'q':
                    break
    except KeyboardInterrupt:
        print('\nScan interrupted; no files were changed.')
    return printed


def timestamp(seconds: float) -> str:
    try:
        return dt.datetime.fromtimestamp(seconds).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')
    except (ValueError, OSError, OverflowError):
        return 'unknown'


def identity(uid: int, gid: int) -> tuple[str, str]:
    try:
        owner = pwd.getpwuid(uid).pw_name
    except KeyError:
        owner = str(uid)
    try:
        group = grp.getgrgid(gid).gr_name
    except KeyError:
        group = str(gid)
    return owner, group


def metadata(path: Path) -> dict[str, str]:
    """Return metadata without opening or changing the file."""
    st = path.lstat()
    mode = st.st_mode
    owner, group = identity(st.st_uid, st.st_gid)
    if stat.S_ISLNK(mode):
        kind = 'Symbolic link (not followed)'
    elif stat.S_ISDIR(mode):
        kind = 'Directory'
    elif stat.S_ISREG(mode):
        kind = 'Regular file'
    elif stat.S_ISSOCK(mode):
        kind = 'Socket'
    elif stat.S_ISFIFO(mode):
        kind = 'Named pipe'
    elif stat.S_ISCHR(mode) or stat.S_ISBLK(mode):
        kind = 'Device file'
    else:
        kind = 'Other filesystem entry'
    data = {
        'Path': str(path),
        'Kind': kind,
        'Hidden': 'Yes (dot-prefixed filename)' if path.name.startswith('.') else 'No',
        'Permissions': f'{stat.filemode(mode)} ({stat.S_IMODE(mode):04o})',
        'Owner / Group': f'{owner} ({st.st_uid}) / {group} ({st.st_gid})',
        'Size': f'{fmt_size(st.st_size)} ({st.st_size:,} bytes)',
        'Last modified': timestamp(st.st_mtime),
        'Last accessed': timestamp(st.st_atime),
        'Metadata changed': timestamp(st.st_ctime),
        'File type guess': mimetypes.guess_type(path.name)[0] or 'Unknown',
        'Inode': str(st.st_ino),
        'Hard links': str(st.st_nlink),
    }
    if stat.S_ISLNK(mode):
        data['Link target'] = os.readlink(path)
    if mode & stat.S_ISUID:
        data['Special permission'] = 'setuid bit set; inspect ownership and purpose'
    if mode & stat.S_ISGID:
        data['Set group ID'] = 'setgid bit set'
    if mode & stat.S_IWOTH:
        data['Permission note'] = 'Writable by any local user; may be normal for temporary folders'
    return data


def describe(path: Path) -> None:
    try:
        data = metadata(path)
    except (PermissionError, OSError) as exc:
        issue(f'Cannot inspect: {safe(exc)}')
        return
    header('FILE DETAILS', 'Metadata, permissions, ownership and dates; no changes made')
    for label, value in data.items():
        print(f'  {ink(label + ":", MUTED):30} {safe(value, 200)}')
    print('\n  Why this matters: permissions tell you who can read, write, or execute.')
    print('  A hidden filename is not proof of malware. Open permissions are not')
    print('  automatically malicious; context and the service using the file matter.')
    print('  "Metadata changed" is NOT a reliable original creation date.')
    print('  Read-only inspection does not guarantee visibility of protected files.')
    if not path.is_symlink() and path.is_file():
        while True:
            print('\n' + ink('  FILE INSPECTION ACTIONS', PURPLE))
            print('    [1] SHA-256 checksum      •  fingerprint only')
            print(ink('      Calculate a read-only file fingerprint.', MUTED))
            print('    [2] Text preview          •  may reveal secrets')
            print(ink('      Preview readable content carefully.', MUTED))
            print('    [3] Hex preview           •  first 256 bytes')
            print(ink('      Inspect raw file bytes safely.', MUTED))
            print(ink('    [0] Back to File Explorer', PURPLE))
            choice = ask('Choose', '0')
            if choice == '0':
                return
            if choice == '1':
                hash_file(path)
            elif choice == '2':
                preview_text(path)
            elif choice == '3':
                preview_hex(path)
            else:
                issue('Choose 0, 1, 2, or 3.')


def hash_file(path: Path) -> None:
    try:
        size = path.stat().st_size
        if size > 100 * 1024 * 1024:
            if ask(f'This file is {fmt_size(size)}. Hash anyway? (yes/no)', 'no').lower() != 'yes':
                return
        digest = hashlib.sha256()
        with path.open('rb') as handle:
            for part in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(part)
        note('SHA-256: ' + digest.hexdigest())
        print('  This is a comparison fingerprint, not a malware diagnosis.')
    except (OSError, PermissionError) as exc:
        issue(f'Unable to calculate hash: {safe(exc)}')


def preview_text(path: Path) -> None:
    warn('Previewing files can expose passwords, tokens, or personal information.')
    if ask('Show first 4 KiB of this file? (yes/no)', 'no').lower() != 'yes':
        return
    try:
        with path.open('rb') as handle:
            raw = handle.read(4096)
        if b'\0' in raw:
            warn('This appears to be binary. Use the hex preview instead.')
            return
        print('\n' + ink('--- First 4 KiB (at most 40 lines) ---', MUTED))
        for line in raw.decode('utf-8', errors='replace').splitlines()[:40]:
            print(safe(line, 300))
        print(ink('--- End of preview ---', MUTED))
    except (OSError, PermissionError) as exc:
        issue(f'Unable to preview: {safe(exc)}')


def preview_hex(path: Path) -> None:
    try:
        with path.open('rb') as handle:
            raw = handle.read(256)
        print(ink('\nOFFSET    HEX                                        ASCII', MUTED))
        for i in range(0, len(raw), 16):
            chunk = raw[i:i + 16]
            hx = ' '.join(f'{b:02x}' for b in chunk)
            chars = ''.join(chr(b) if 32 <= b <= 126 else '.' for b in chunk)
            print(f'{i:08x}  {hx:<47}  {chars}')
    except (OSError, PermissionError) as exc:
        issue(f'Unable to preview: {safe(exc)}')


def pause() -> None:
    """Hold a tool result on screen until the user is ready."""
    try:
        gs_keys.read_line(ink('\n  [Enter] Continue  |  Esc = toolkit home ... ', MUTED))
    except EOFError:
        pass


def screen() -> None:
    """Clear menus, but don't emit control sequences in redirected/test output."""
    if sys.stdout.isatty() and not os.environ.get('GS_NO_CLEAR'):
        sys.stdout.write('\033[2J\033[H')
        sys.stdout.flush()


def browser_entries(path: Path, show_hidden: bool = True):
    """Return sorted entries in visible order; never follow directory symlinks."""
    items = sort_children(path)
    return items if show_hidden else [e for e in items if not e.name.startswith('.')]


def page_items(items: list, page: int, per_page: int = BROWSER_PAGE_SIZE):
    """Safe bounds for paging; selection numbers always refer to visible rows."""
    last = max(0, (len(items) - 1) // per_page)
    page = max(0, min(page, last))
    return page, last, items[page * per_page:(page + 1) * per_page]


def entry_kind(item) -> str:
    try:
        if item.is_symlink():
            return 'LINK'
        if item.is_dir(follow_symlinks=False):
            return 'DIR '
    except OSError:
        pass
    return 'FILE'


def numbered_rows(items: list, page: int = 0, per_page: int = BROWSER_PAGE_SIZE):
    """Render exactly the rows selectable on this page."""
    page, last, visible = page_items(items, page, per_page)
    result = []
    for idx, item in enumerate(visible, 1):
        result.append(f'  [{idx:2d}]  {entry_kind(item)}  {safe(item.name, 65)}')
    return page, last, result


def file_actions(path: Path) -> None:
    """Numbered viewer for one entry; read-only and symlink-aware."""
    while True:
        screen()
        header('SELECTED FILE', 'VIEW ONLY • no files are modified')
        print('  ' + ink('Name:', MUTED) + ' ' + safe(path.name, 95))
        print('  ' + ink('Path:', MUTED) + ' ' + safe(path, 170))
        try:
            info = metadata(path)
            for label in ('Kind', 'Size', 'Permissions', 'Owner / Group', 'Last modified'):
                print('  ' + ink(label + ':', MUTED) + ' ' + safe(info.get(label, 'Unavailable'), 110))
        except (OSError, PermissionError) as exc:
            warn('Metadata unavailable: ' + safe(exc))
        print('\n  [1] Full file information')
        print(ink('      Show complete ownership, permissions and timestamps.', MUTED))
        is_file = path.is_file() and not path.is_symlink()
        if is_file:
            print('  [2] Calculate SHA-256 hash')
            print(ink('      Generate a file fingerprint without modifying it.', MUTED))
            print('  [3] Preview text (confirmation required)')
            print(ink('      View limited text after confirming possible sensitive content.', MUTED))
            print('  [4] Preview first 256 bytes as HEX')
            print(ink('      View the first raw bytes without modifying the file.', MUTED))
        print(ink('\n  [0] Back to folder   [Esc] Toolkit home', PURPLE))
        choice = ask('  Select an action', '0')
        if choice == '0':
            return
        if choice == '1':
            # metadata() never follows symlinks.
            try:
                data = metadata(path)
                screen()
                header('FILE DETAILS', 'Owner • permissions • size • dates')
                for key, val in data.items():
                    print(f'  {key}: {safe(val, 175)}')
                note('Hidden files and permissive modes are not automatically dangerous.')
            except (OSError, PermissionError) as exc:
                issue(f'Cannot inspect: {safe(exc)}')
            pause()
        elif is_file and choice in ('2', '3', '4'):
            screen()
            header('FILE INSPECTION', 'Local data only; previews may display private information')
            if choice == '2':
                hash_file(path)
            elif choice == '3':
                preview_text(path)
            else:
                preview_hex(path)
            pause()
        else:
            warn('Choose one of the numbered options.')
            pause()


def search_browser(folder: Path, show_hidden: bool = True) -> Path | None:
    """Select a search hit by number, returning its path or None.

    Searches are bounded, do not recurse through directory symlinks and never
    change the current folder until the user selects a result.
    """
    query = ask('  Part of a filename to search for').strip()
    if not query:
        return None
    results = []
    for hit in name_matches(folder, query, max_inspected=12000):
        if not show_hidden and any(part.startswith('.') for part in hit.relative_to(folder).parts):
            continue
        results.append(hit)
        if len(results) >= SEARCH_RESULT_LIMIT:
            break
    page = 0
    while True:
        screen()
        header('SEARCH RESULTS', f'{len(results)} matches (maximum {SEARCH_RESULT_LIMIT}) • {safe(query, 38)}')
        note('Search location: ' + safe(folder, 150))
        if not results:
            warn('No matching entries found. Try another name or folder.')
            pause()
            return None
        page, last, chunk = page_items(results, page)
        for idx, hit in enumerate(chunk, 1):
            try:
                relative = hit.relative_to(folder)
            except ValueError:
                relative = hit
            tag = 'DIR ' if hit.is_dir() and not hit.is_symlink() else 'LINK' if hit.is_symlink() else 'FILE'
            print(f'  [{idx:2d}]  {tag}  {safe(relative, 87)}')
        print(ink(f'\n  Page {page + 1} of {last + 1}', MUTED))
        print('  [11] Next page       [12] Previous page')
        print(ink('  [ 0] Back to browser   [Esc] Toolkit home', PURPLE))
        choice = ask('  Select a match', '0').strip()
        if choice == '0':
            return None
        if choice == '11':
            page = min(last, page + 1)
        elif choice == '12':
            page = max(0, page - 1)
        elif choice.isdecimal() and 1 <= int(choice) <= len(chunk):
            return chunk[int(choice) - 1]
        else:
            warn('Choose a visible result number or navigation option.')
            pause()


def folder_tools(path: Path) -> None:
    """Advanced read-only actions, still selected by numbers."""
    while True:
        screen()
        header('MORE FOLDER TOOLS', 'Optional read-only inspection')
        print('  [1] Folder tree (two levels)')
        print(ink('      Explore this folder and two levels of subfolders.', MUTED))
        print('  [2] Find hidden entries in this folder')
        print(ink('      Find names beginning with a dot.', MUTED))
        print('  [3] Details and permissions of current folder')
        print(ink('      Show folder ownership, size and permissions.', MUTED))
        print('  [4] System-wide file map (bounded)')
        print(ink('      View a limited, read-only directory map.', MUTED))
        print('  [5] File Explorer help')
        print(ink('      Read navigation and safety guidance.', MUTED))
        print(ink('\n  [0] Back to files   [Esc] Toolkit home', PURPLE))
        choice = ask('  Select', '0')
        if choice == '0':
            return
        screen()
        if choice == '1':
            header('FOLDER TREE', 'Two levels • at most 200 entries')
            show_paginated(tree_lines(path, 2, 200), interactive=True)
        elif choice == '2':
            header('HIDDEN ENTRIES', 'Names beginning with a dot')
            show_paginated((safe(p, 200) for p in hidden_matches(path, max_inspected=12000)), max_lines=250)
        elif choice == '3':
            header('FOLDER DETAILS', 'Current directory • read only')
            try:
                for key, val in metadata(path).items():
                    print(f'  {key}: {safe(val, 160)}')
            except OSError as exc:
                issue(safe(exc))
        elif choice == '4':
            scan_tree(quick=True)
        elif choice == '5':
            help_screen()
        else:
            warn('Choose one of the numbered actions.')
        pause()


def browse(start: Path | None = None) -> None:
    """Simple read-only browser with direct access to file trees and metadata."""
    path = (start or Path.home()).expanduser().absolute()
    if not path.is_dir():
        issue('Starting folder is unavailable.')
        return
    show_hidden = False
    page = 0
    while True:
        screen()
        header('GS FILE EXPLORER', 'Browse • inspect • file tree | READ ONLY')
        print('  ' + ink('Folder:', MUTED) + ' ' + safe(path, 145))
        try:
            items = browser_entries(path, show_hidden)
        except (OSError, PermissionError) as exc:
            issue('Cannot list folder: ' + safe(exc))
            items = []
        page, last, rows = numbered_rows(items, page)
        print(ink('\n  CONTENTS', PURPLE))
        for row in rows:
            print(row)
        if not rows:
            print(ink('  No visible entries.', MUTED))
        print(ink(f'\n  Page {page+1}/{last+1}  •  {len(items)} entries', MUTED))
        print(ink('  SELECT A FILE OR FOLDER  [1–10]  (current page only)', MUTED))
        print(ink('\n  NAVIGATION', PURPLE))
        print('  [11] Next page             [12] Previous page')
        print(ink('       Browse more items; numbers 1–10 reset on each page.', MUTED))
        print('  [13] Up folder             [14] Home folder')
        print(ink('       Navigate to the parent folder or your home directory.', MUTED))
        print(ink('\n  INSPECTION  —  READ ONLY', PURPLE))
        print('  [15] File tree             [16] Folder information')
        print(ink('       See a bounded directory hierarchy or folder metadata.', MUTED))
        print('  [17] Search by name        [18] Open a folder path')
        print(ink('       Find matching names or navigate to a location.', MUTED))
        print(f"  [19] {'Hide' if show_hidden else 'Show'} hidden files")
        print(ink('       Toggle display of names starting with a dot.', MUTED))
        print(ink('\n  [0] Back to toolkit', PURPLE))
        choice = ask('  Select', '0').strip()
        if choice == '0':
            return
        if choice == '11':
            page = min(page + 1, last)
        elif choice == '12':
            page = max(0, page - 1)
        elif choice == '13':
            path, page = path.parent, 0
        elif choice == '14':
            path, page = Path.home(), 0
        elif choice == '15':
            screen()
            header('FOLDER TREE', 'Current folder • 3 levels • up to 250 items • read only')
            show_paginated(tree_lines(path, 3, 250), interactive=True)
            pause()
        elif choice == '16':
            screen()
            header('FOLDER INFO', 'Permissions • ownership • size • modified time')
            try:
                for key, value in metadata(path).items():
                    print(f'  {key}: {safe(value, 160)}')
            except (OSError, PermissionError) as exc:
                issue('Cannot inspect folder: ' + safe(exc))
            pause()
        elif choice == '17':
            selected = search_browser(path, show_hidden)
            if selected is not None:
                if selected.is_dir() and not selected.is_symlink():
                    path, page = selected, 0
                else:
                    file_actions(selected)
        elif choice == '18':
            new = path_prompt(path, require_dir=True)
            if new is not None:
                path, page = new, 0
        elif choice == '19':
            show_hidden, page = not show_hidden, 0
        elif choice.isdecimal() and 1 <= int(choice) <= len(rows):
            idx = page * BROWSER_PAGE_SIZE + int(choice) - 1
            if idx < len(items):
                selected = Path(items[idx].path)
                try:
                    if items[idx].is_dir(follow_symlinks=False):
                        path, page = selected, 0
                    else:
                        file_actions(selected)
                except (OSError, PermissionError) as exc:
                    issue('Cannot open selection: ' + safe(exc))
                    pause()
        else:
            warn('Choose a visible file number or one of the actions.')
            pause()


def scan_tree(quick: bool = False) -> None:
    if quick:
        base, depth, max_entries, exclude = Path('/'), 4, 2000, True
        header('SYSTEM FILE MAP', 'Starting at /; virtual filesystems excluded to prevent hangs')
        warn('Some protected paths will be unreadable without privileges.')
    else:
        base = path_prompt(require_dir=True)
        if base is None:
            return
        d = ask('Maximum folder depth (1–10, or all)', '3').lower()
        depth = None if d == 'all' else int(d) if d.isdecimal() and 1 <= int(d) <= 10 else 3
        m = ask('Maximum displayed entries (100–10000, or all)', '500').lower()
        max_entries = None if m == 'all' else int(m) if m.isdecimal() and 100 <= int(m) <= 10000 else 500
        exclude = ask('Skip /proc, /sys, /dev and /run virtual filesystems? (yes/no)', 'yes').lower() != 'no'
        if depth is None and max_entries is None:
            warn('An unlimited recursive scan can take a long time and print millions of lines.')
            if ask('Continue? (yes/no)', 'no').lower() != 'yes':
                return
        header('FOLDER TREE', 'Includes hidden dotfiles; symbolic links are not followed')
    shown = show_paginated(tree_lines(base, depth, max_entries, exclude), interactive=True)
    note(f'Displayed {shown} lines. Scans are read-only; this is not a malware scan.')


def scan_hidden() -> None:
    header('HIDDEN FILES', 'Find names starting with a dot, including .config and .ssh')
    base = path_prompt(require_dir=True)
    if base is None:
        return
    limit_raw = ask('Maximum results (100–5000)', '500')
    limit = int(limit_raw) if limit_raw.isdecimal() and 100 <= int(limit_raw) <= 5000 else 500
    warn('Hidden does not mean suspicious. Protected files may not be visible.')
    shown = show_paginated((safe(p, 220) for p in hidden_matches(base)),
                           title='HIDDEN ENTRIES', max_lines=limit)
    note(f'Displayed {shown} matching entries; at most 75,000 filesystem entries checked.')


def find_names() -> None:
    header('SEARCH FILE NAMES', 'Case-insensitive filename search, including hidden entries')
    base = path_prompt(require_dir=True)
    if base is None:
        return
    query = ask('Part of filename to find')
    if not query:
        issue('Enter a filename fragment.')
        return
    shown = show_paginated((safe(p, 220) for p in name_matches(base, query)),
                           title='MATCHING FILES', max_lines=500)
    note(f'Displayed {shown} matches; at most 75,000 filesystem entries checked.')


def help_screen() -> None:
    header('HELP & LEARNING', 'Understand what filesystem inspection can and cannot prove')
    print('''
  FILE TREES: Directories organize files. The root "/" is the top of Linux.
  HOME FOLDER: "~" means your current user’s home directory.
  HIDDEN FILES: Names starting with a dot are hidden in ordinary listings.
                Many are normal user/application configuration files.
  PERMISSIONS: r = read, w = write, x = execute; owner/group/others
               determine which accounts can do each action.
  HASHES: SHA-256 creates a fingerprint to compare copies of a file.
          It does NOT tell you whether a file is malicious.
  SYMBOLIC LINKS: Shortcuts/pointers to another location; this tool
                  does not follow them during recursive scans.
  VIRTUAL FOLDERS: /proc, /sys, /dev and /run are special system paths.
                   They are skipped in broad scans to avoid hangs.
  LIMITATIONS: You may not have permission to list everything.
               Scanning huge trees can take time. This tool does not
               determine whether software or a system is safe.

  PRIVACY IS AN ILLUSION — understanding what files, logs, and metadata
  reveal is a step toward making informed choices about your privacy.

  STRICTLY FOR EDUCATIONAL PURPOSES ONLY.
  Inspect computers and data that you own or are authorized to review.
  No file scanner or privacy utility guarantees anonymity or safety.
''')


def interactive_menu() -> None:
    """Open directly into the guided file browser, with no initial path question."""
    try:
        browse()
    except gs_keys.HomeRequested:
        print('\nEsc pressed — returning to Ghost Strategist main menu.')
    except KeyboardInterrupt:
        print('\nFile browsing cancelled. Nothing was changed.')
    except (OSError, PermissionError, ValueError) as exc:
        issue('File Explorer could not continue: ' + safe(exc))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Ghost Strategist read-only file explorer for Linux')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--tree', metavar='PATH', help='Print a folder tree and exit')
    group.add_argument('--inspect', metavar='PATH', help='Print file metadata and exit')
    parser.add_argument('--depth', type=int, default=3, help='Folder tree depth (default: 3)')
    parser.add_argument('--limit', type=int, default=500, help='Maximum entries for --tree (default: 500)')
    args = parser.parse_args(argv)
    if args.tree is not None:
        root = Path(args.tree).expanduser().absolute()
        for line in tree_lines(root, max(0, args.depth), max(1, args.limit)):
            print(line)
        return 0
    if args.inspect is not None:
        try:
            data = metadata(Path(args.inspect).expanduser().absolute())
            for key, value in data.items():
                print(f'{key}: {safe(value, 400)}')
        except OSError as exc:
            print(f'Inspection error: {safe(exc)}', file=sys.stderr)
            return 1
        return 0
    try:
        interactive_menu()
    except (EOFError, KeyboardInterrupt):
        print('\nFile Explorer closed; no files were changed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
