#!/usr/bin/env python3
"""Read-only local networking inventory for Ghost Strategist Tool.

No active network scanning, internet lookup, or automatic file writes.
"""
from gs_brand import print_gs as print
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

SECTIONS = {
    '1': ('INTERFACES & ADDRESSES', [
        ['ip', '-brief', 'link'], ['ip', '-brief', 'address'],
        ['nmcli', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device', 'status'],
    ]),
    '2': ('ROUTING / GATEWAYS / NEIGHBORS', [
        ['ip', '-4', 'route', 'show'], ['ip', '-6', 'route', 'show'],
        ['ip', 'neigh', 'show'], ['ip', 'rule', 'show'],
    ]),
    '3': ('DNS & DHCP', [
        ['nmcli', '-f', 'IP4,IP6', 'device', 'show'],
        ['resolvectl', 'status'],
    ]),
    '4': ('CONNECTIONS & LISTENERS', [
        ['ss', '-tuna'], ['ss', '-tuln'],
    ]),
    '5': ('RADIOS / HARDWARE / VPN / TRAFFIC', [
        ['nmcli', 'radio', 'all'], ['iw', 'dev'], ['rfkill', 'list'],
        ['ip', '-s', 'link'], ['nmcli', '-f', 'NAME,TYPE,DEVICE', 'connection', 'show', '--active'],
        ['lspci', '-nn'], ['lsusb'],
    ]),
    '6': ('FIREWALL & LOCAL SECURITY', [
        ['sudo', '-n', 'ufw', 'status', 'verbose'],
        ['ip', '-d', 'link', 'show'],
    ]),
}
MAX_LINES = 34
MAX_CHARS = 120


def execute(argv, *, timeout=4):
    if not shutil.which(argv[0]):
        return f'! Unavailable: {argv[0]} is not installed.'
    try:
        proc = subprocess.run(argv, capture_output=True, text=True,
                              errors='replace', timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        return '! This command exceeded the 4-second time limit.'
    except OSError as exc:
        return '! Command could not run: ' + str(exc)
    result = (proc.stdout or '').strip()
    if proc.returncode:
        if argv[:3] == ['sudo', '-n', 'ufw']:
            return '! Firewall status needs administrator authorization. No password requested.'
        hint = (proc.stderr or '').strip().splitlines()
        return f'! Command unavailable (exit {proc.returncode}): ' + (hint[0][:110] if hint else 'no data')
    if not result:
        return '! No entries reported.'
    rows = result.splitlines()
    display = '\n'.join(row[:MAX_CHARS] for row in rows[:MAX_LINES])
    if len(rows) > MAX_LINES:
        display += f'\n! {len(rows) - MAX_LINES} more rows omitted for readability.'
    return display


def generate(keys=None):
    keys = list(keys if keys is not None else SECTIONS)
    lines = ['GS NETWORK INTELLIGENCE — LOCAL READ-ONLY REPORT',
             'Generated: ' + datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
             '! Output shows only information visible to your user session.',
             '! No network discovery probes or public IP lookup are performed.']
    for key in keys:
        title, commands = SECTIONS[key]
        lines += ['', '=== ' + title + ' ===']
        for argv in commands:
            lines += ['', '$ ' + ' '.join(argv), execute(argv)]
    return '\n'.join(lines) + '\n'


def show_section(key=None):
    print(generate(None if key is None else [key]))
    print('! IP/MAC details, gateways and DNS addresses can be sensitive. Do not post the raw report publicly.')
    return 'Read-only network report completed.'


if __name__ == '__main__':
    sys.exit(0 if show_section(sys.argv[1] if len(sys.argv) > 1 else None) else 1)
