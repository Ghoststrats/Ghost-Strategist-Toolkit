#!/usr/bin/env bash
# Best-effort supplementary BlackOut: preserve original service, socket and radio states.
# This script never changes enable-on-boot settings and never installs packages.
set -u
umask 077
DIR="${XDG_STATE_HOME:-$HOME/.local/state}/ghost-strategist-tool"
STATE="$DIR/blackout-extra-v47.tsv" # keep V67 path for recovery compatibility
mode="${1:-status}"
msg(){ printf '%s\n' "$*"; }
has(){ command -v "$1" >/dev/null 2>&1; }
net_state(){ local s; s="$(nmcli networking 2>/dev/null)" || { echo unknown; return; }; case "$s" in enabled|disabled) echo "$s";; *) echo unknown;; esac; }
wwan_state(){ local s; s="$(nmcli radio wwan 2>/dev/null)" || { echo unknown; return; }; case "$s" in enabled|disabled) echo "$s";; *) echo unknown;; esac; }
# is-active prints "inactive" and returns non-zero for stopped units; do not append "unknown".
unit_state(){
  local unit="$1" loaded
  if ! has systemctl; then echo unavailable; return; fi
  loaded="$(systemctl show -p LoadState --value "$unit" 2>/dev/null)" || { echo unknown; return; }
  case "$loaded" in loaded) ;; not-found|masked|'') echo unavailable; return;; *) echo unavailable; return;; esac
  if systemctl is-active --quiet "$unit" 2>/dev/null; then echo active; else echo inactive; fi
}
# Stop socket/path activation mechanisms before their services, preventing instant restarts.
UNITS=(avahi-daemon.socket avahi-daemon.service cups.socket cups.path cups.service bluetooth.service smbd.service nmbd.service)
stop_unit(){ sudo systemctl stop "$1"; }
start_unit(){ sudo systemctl start "$1"; }
case "$mode" in
 apply)
  if [[ -e "$STATE" || -L "$STATE" ]]; then msg 'An earlier extra-control backup already exists; not overwriting.'; exit 1; fi
  if [[ -L "$DIR" ]]; then msg 'Unsafe state directory symlink; refusing.'; exit 1; fi
  mkdir -p -m 700 "$DIR" || exit 1
  chmod 700 "$DIR" || exit 1
  tmp="$(mktemp "$DIR/.blackout-extra.XXXXXX")" || exit 1
  {
    printf 'NETWORK|%s\n' "$(net_state)"
    printf 'WWAN|%s\n' "$(wwan_state)"
    for unit in "${UNITS[@]}"; do printf 'SERVICE|%s|%s\n' "$unit" "$(unit_state "$unit")"; done
  } > "$tmp"
  if ! ln -- "$tmp" "$STATE"; then rm -f -- "$tmp"; msg 'Failed to save extra-control snapshot.'; exit 1; fi
  rm -f -- "$tmp"
  errors=0
  while IFS='|' read -r type a b; do
    if [[ "$type" == SERVICE && "$b" == active ]]; then
      if stop_unit "$a" && [[ "$(unit_state "$a")" == inactive ]]; then msg "VERIFIED off: $a"
      else msg "FAILED to stop or verify: $a"; errors=1; fi
    fi
  done < "$STATE"
  if [[ "$(wwan_state)" == enabled ]]; then
    if nmcli radio wwan off && [[ "$(wwan_state)" == disabled ]]; then msg 'VERIFIED: mobile broadband radio OFF'
    else msg 'FAILED to verify mobile broadband OFF'; errors=1; fi
  fi
  # NetworkManager networking last: it may terminate active connections/remote terminals.
  if [[ "$(net_state)" == enabled ]]; then
    if nmcli networking off && [[ "$(net_state)" == disabled ]]; then msg 'VERIFIED: NetworkManager networking OFF'
    else msg 'FAILED to verify NetworkManager networking OFF'; errors=1; fi
  fi
  if ((errors)); then msg 'INCOMPLETE: one or more extra privacy controls are still active or could not be verified.'
  else msg 'Supplementary controls verified where available. Not a physical hardware kill switch.'; fi
  exit "$errors";;
 restore)
  if [[ ! -f "$STATE" || -L "$STATE" ]]; then msg 'No extra-control BlackOut backup; nothing to restore.'; exit 1; fi
  errors=0
  # Restore network first; only reverse the states recorded before BlackOut.
  while IFS='|' read -r type a b; do
    case "$type" in
      NETWORK) case "$a" in enabled|disabled) if [[ "$(net_state)" != "$a" ]]; then
          if ! nmcli networking "$([[ "$a" == enabled ]] && echo on || echo off)" || [[ "$(net_state)" != "$a" ]]; then errors=1; msg 'NetworkManager restore could not be verified'; fi
        fi;; esac;;
      WWAN) case "$a" in enabled|disabled) if [[ "$(wwan_state)" != "$a" ]]; then
          if ! nmcli radio wwan "$([[ "$a" == enabled ]] && echo on || echo off)" || [[ "$(wwan_state)" != "$a" ]]; then errors=1; msg 'WWAN restore could not be verified'; fi
        fi;; esac;;
    esac
  done < "$STATE"
  # Services restored before socket activation units. Only originally active units are restarted.
  while IFS='|' read -r type a b; do
    if [[ "$type" == SERVICE && "$b" == active && "$a" != *.socket && "$a" != *.path ]]; then
      if [[ "$(unit_state "$a")" == active ]]; then msg "Already active: $a"
      elif start_unit "$a" && [[ "$(unit_state "$a")" == active ]]; then msg "Restored: $a"
      else msg "FAILED to restore: $a"; errors=1; fi
    fi
  done < "$STATE"
  while IFS='|' read -r type a b; do
    if [[ "$type" == SERVICE && "$b" == active && ( "$a" == *.socket || "$a" == *.path ) ]]; then
      if [[ "$(unit_state "$a")" == active ]]; then msg "Already active: $a"
      elif start_unit "$a" && [[ "$(unit_state "$a")" == active ]]; then msg "Restored: $a"
      else msg "FAILED to restore: $a"; errors=1; fi
    fi
  done < "$STATE"
  if ((errors == 0)); then rm -f -- "$STATE"; msg 'Additional recorded settings restored. Backup cleared.'
  else msg 'INCOMPLETE restore: extra-control backup kept for retry.'; fi
  exit "$errors";;
 status)
  msg "NetworkManager networking: $(net_state)"
  msg "Mobile broadband radio: $(wwan_state)"
  for unit in "${UNITS[@]}"; do msg "$unit: $(unit_state "$unit")"; done
  [[ -f "$STATE" ]] && msg 'Additional BlackOut backup: saved' || msg 'Additional BlackOut backup: none';;
 *) msg 'Usage: bash blackout-extra.sh apply|restore|status'; exit 2;;
esac
