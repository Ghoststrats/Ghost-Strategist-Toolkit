# V76 — GS Drone Detector signal-warning colors

- Red **90–100** signal index, including **DANGER: MAX SIGNAL — POSSIBLY CLOSE** at 100.
- Yellow **50–89**; green **0–49**; unknown signal remains gray.
- Colorized signal bar and advisory are visible for possible drone/RC matches.
- dBm readings are mapped to an *uncalibrated display index*, not to distance.
- Once a detected candidate crosses into the red zone, a new alert fires without a bell on every scan.
- Demonstration includes fabricated red/yellow/green examples.
- Offline tests now cover boundary behavior and unavailable readings.

**Important:** All proximity words are intentionally tentative. Received signal strength cannot reliably calculate range, direction, or time of arrival. A possible brand match does not authenticate an aircraft.
