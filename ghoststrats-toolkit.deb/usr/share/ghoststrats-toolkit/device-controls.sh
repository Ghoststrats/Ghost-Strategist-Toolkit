#!/usr/bin/env bash
# Mint/Cinnamon device control helpers. All changes are explicit, no startup side effects.
set -u
umask 077
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/ghost-strategist-tool"
STATE="${GS_BLACKOUT_DEVICE_STATE:-$STATE_DIR/blackout-devices-v23.tsv}"
REMOTE_STATE="$STATE_DIR/remote-lockdown-state.tsv"
PORT_STATE="$STATE_DIR/port-lockdown-v22.state"
mode="${1:-status}"
setting="${2:-}"
run(){ "$@" >/dev/null 2>&1; }
report(){
 local line="$*"
 if [[ -t 1 && -z "${NO_COLOR+x}" ]]; then
   local purple=$'\033[38;5;141m' reset=$'\033[0m'
   line="${line//GS/${purple}GS${reset}}"
 fi
 printf '%s\n' "$line"
}
read_wifi(){
 local state
 state="$(nmcli radio wifi 2>/dev/null || true)"
 case "$state" in enabled|disabled) echo "$state";; *) echo unknown;; esac
}
read_bt_block(){
 local value
 if command -v rfkill >/dev/null 2>&1; then
   value="$(rfkill list bluetooth 2>/dev/null | awk -F': ' '/Soft blocked:/ {print $2; exit}' || true)"
   case "$value" in yes|no) echo "$value"; return;; esac
 fi
 echo unknown
}
read_bt_power(){
 local value
 value="$(bluetoothctl show 2>/dev/null | awk -F': ' '/^[[:space:]]*Powered:/ {print $2; exit}' || true)"
 case "$value" in yes|no) echo "$value";; *) echo unknown;; esac
}
read_mute(){
 local type="$1" out
 case "$type" in microphone) out="$(pactl get-source-mute @DEFAULT_SOURCE@ 2>/dev/null || true)";; speakers) out="$(pactl get-sink-mute @DEFAULT_SINK@ 2>/dev/null || true)";; esac
 case "$out" in *'Mute: yes'*) echo yes;; *'Mute: no'*) echo no;; *) echo unknown;; esac
}
read_camera(){
 if [[ -d /sys/module/uvcvideo ]]; then echo loaded; else echo unloaded; fi
}
change(){
 local kind="$1" value="$2" cmd key level
 case "$kind" in
 wifi)
   if ! command -v nmcli >/dev/null || ! run nmcli radio wifi "$value"; then
     report 'Wi-Fi operation FAILED (nmcli command).'; return 1
   fi
   local expected=enabled
   [[ "$value" == off ]] && expected=disabled
   if [[ "$(read_wifi)" != "$expected" ]]; then
     report "Wi-Fi NOT VERIFIED: expected $expected; actual $(read_wifi)"; return 1
   fi
   report "Wi-Fi VERIFIED: $expected";;
 bluetooth)
   if [[ "$value" == off ]]; then
     if run rfkill block bluetooth || { command -v sudo >/dev/null && run sudo -n rfkill block bluetooth; }; then
       # Also request power off, when bluetoothctl exists.
       command -v bluetoothctl >/dev/null && run bluetoothctl power off || true
       if [[ "$(read_bt_block)" == yes || "$(read_bt_power)" == no ]]; then report 'Bluetooth VERIFIED: software blocked/powered off';
       else report 'Bluetooth NOT VERIFIED: radio may still be operating.'; return 1; fi
     elif command -v bluetoothctl >/dev/null && run bluetoothctl power off && [[ "$(read_bt_power)" == no ]]; then report 'Bluetooth VERIFIED: controller powered OFF';
     else report 'Bluetooth operation failed'; return 1; fi
   else
     # Unblocking rfkill and powering the controller are separate operations.
     # The old implementation returned success after rfkill unblock even if the
     # controller stayed powered off. Both steps are now attempted and checked.
     if command -v rfkill >/dev/null 2>&1; then
       if ! run rfkill unblock bluetooth && ! run sudo rfkill unblock bluetooth; then
         report 'Bluetooth: could not clear software rfkill block.'; return 1
       fi
       if [[ "$(read_bt_block)" == yes ]]; then
         report 'Bluetooth remains soft-blocked after unblock request.'; return 1
       fi
     fi
     if command -v bluetoothctl >/dev/null 2>&1; then
       if ! run bluetoothctl power on; then
         report 'Bluetooth: could not power on the controller.'; return 1
       fi
       if [[ "$(read_bt_power)" != yes ]]; then
         report 'Bluetooth power-on could not be verified.'; return 1
       fi
       report 'Bluetooth: controller powered ON (previously paired devices may reconnect)'
     elif command -v rfkill >/dev/null 2>&1; then
       report 'Bluetooth: rfkill unblocked, but controller power status is unverified (bluetoothctl unavailable).'
     else
       report 'Bluetooth: no supported control utility available.'; return 1
     fi
   fi;;
 microphone|speakers)
   key=@DEFAULT_SOURCE@; cmd=set-source-mute
   if [[ "$kind" == speakers ]]; then key=@DEFAULT_SINK@; cmd=set-sink-mute; fi
   level=1; [[ "$value" == on ]] && level=0
   if command -v pactl >/dev/null && run pactl "$cmd" "$key" "$level"; then
      local desired=no
      [[ "$value" == off ]] && desired=yes
      if [[ "$(read_mute "$kind")" == "$desired" ]]; then
        report "$kind VERIFIED: software mute=$level (hardware not disabled)"
      else report "$kind NOT VERIFIED: mute state differs from request"; return 1; fi
   else report "$kind mute operation failed"; return 1; fi;;
 camera)
   if [[ "$value" == off ]]; then
     if [[ -d /sys/module/uvcvideo ]]; then
       if run sudo modprobe -r uvcvideo && [[ "$(read_camera)" == unloaded ]]; then report 'Camera VERIFIED: uvcvideo unloaded; other camera types unverified';
       else report 'Camera: unable to unload uvcvideo (permission or device busy)'; return 1; fi
     else report 'Camera: uvcvideo not loaded; OTHER CAMERA DRIVERS AND DEVICES NOT VERIFIED'; fi
   else
     if run sudo modprobe uvcvideo && [[ "$(read_camera)" == loaded ]]; then report 'Camera VERIFIED: uvcvideo loaded; other camera types unverified';
     else report 'Camera: could not load uvcvideo (admin access may be required)'; return 1; fi
   fi;;
 *) report "Unknown device: $kind"; return 2;;
 esac
}
snapshot(){
 # A baseline is captured automatically on first toolkit launch. Never replace
 # it on subsequent runs while there may be changes awaiting restoration.
 if [[ -e "$STATE" || -L "$STATE" ]]; then
   if [[ -f "$STATE" && ! -L "$STATE" ]] && grep -q '^WIFI|' "$STATE" && grep -q '^MIC_MUTE|' "$STATE"; then
     report 'Startup settings already saved. Original snapshot preserved.'
     return 0
   fi
   report 'Existing settings snapshot is unsafe or incomplete. Will not overwrite it.'
   return 1
 fi
 if [[ -L "$STATE_DIR" ]]; then report 'Snapshot folder must not be a symbolic link.'; return 1; fi
 mkdir -p -m 700 "$STATE_DIR" || return 1
 chmod 700 "$STATE_DIR" || return 1
 local tmp; tmp="$(mktemp "$STATE_DIR/.blackout-devices.XXXXXX")" || return 1
 {
  printf 'CAPTURED_AT|%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf 'WIFI|%s\n' "$(read_wifi)"
  printf 'BT_BLOCK|%s\n' "$(read_bt_block)"
  printf 'BT_POWER|%s\n' "$(read_bt_power)"
  printf 'MIC_MUTE|%s\n' "$(read_mute microphone)"
  printf 'SPK_MUTE|%s\n' "$(read_mute speakers)"
  printf 'UVC|%s\n' "$(read_camera)"
  [[ -f "$REMOTE_STATE" ]] && echo 'REMOTE_PREEXIST|yes' || echo 'REMOTE_PREEXIST|no'
  [[ -f "$PORT_STATE" ]] && echo 'PORT_PREEXIST|yes' || echo 'PORT_PREEXIST|no'
  [[ -f "$STATE_DIR/blackout-extra-v47.tsv" ]] && echo 'EXTRA_PREEXIST|yes' || echo 'EXTRA_PREEXIST|no'
 } > "$tmp"
 if ! ln -- "$tmp" "$STATE"; then rm -f "$tmp"; report 'Could not save device state; refusing to apply BlackOut.'; return 1; fi
 rm -f -- "$tmp"
 report "Initial device settings saved for later restoration."
}
restore_devices(){
 if [[ ! -f "$STATE" ]]; then
   report 'No GS BlackOut snapshot from this version. Cannot safely restore unknown initial device states.'
   report 'Use the individual device controls to enable Wi-Fi/Bluetooth and unmute audio if needed.'
   return 1
 fi
 local key value wifi=unknown bt_block=unknown bt_power=unknown mic=unknown spk=unknown uvc=unknown failed=0
 while IFS='|' read -r key value; do
  case "$key" in
   WIFI) wifi="$value";; BT_BLOCK) bt_block="$value";; BT_POWER) bt_power="$value";;
   MIC_MUTE) mic="$value";; SPK_MUTE) spk="$value";; UVC) uvc="$value";;
  esac
 done < "$STATE"
 # Do not blindly toggle every device: a startup backup usually matches the
 # current machine. Change only states that differ, reducing disruption and
 # avoiding unnecessary sudo requests on restore.
 local current
 current="$(read_wifi)"
 case "$wifi" in
  enabled|disabled)
   if [[ "$current" == "$wifi" ]]; then report 'Wi-Fi already matches saved state.'
   elif [[ "$wifi" == enabled ]]; then change wifi on || failed=1
   else change wifi off || failed=1; fi;;
  *) report 'Wi-Fi state was not detectable at startup; skipping.';;
 esac
 current="$(read_bt_block)"
 case "$bt_block" in
  yes)
   if [[ "$current" == yes ]]; then report 'Bluetooth is already soft-blocked.'
   elif command -v rfkill >/dev/null 2>&1 && { run rfkill block bluetooth || run sudo rfkill block bluetooth; }; then
      report 'Bluetooth soft block restored.'
   else report 'Could not restore Bluetooth rfkill block.'; failed=1; fi;;
  no)
   if [[ "$current" == no ]]; then report 'Bluetooth is already unblocked.'
   elif command -v rfkill >/dev/null 2>&1 && { run rfkill unblock bluetooth || run sudo rfkill unblock bluetooth; }; then
      report 'Bluetooth soft block removed.'
   else report 'Could not restore Bluetooth rfkill unblock state.'; failed=1; fi;;
  *) report 'Bluetooth soft block state unknown at startup; skipping.';;
 esac
 if command -v bluetoothctl >/dev/null 2>&1; then
  current="$(read_bt_power)"
  case "$bt_power" in
   yes)
    if [[ "$current" == yes ]]; then report 'Bluetooth power already matches saved state.'
    elif [[ "$bt_block" != yes ]] && run bluetoothctl power on; then report 'Bluetooth controller power restored ON.'
    else report 'Could not restore Bluetooth controller power ON.'; failed=1; fi;;
   no)
    if [[ "$current" == no ]]; then report 'Bluetooth power already matches saved state.'
    elif run bluetoothctl power off; then report 'Bluetooth controller power restored OFF.'
    else report 'Could not restore Bluetooth controller power OFF.'; failed=1; fi;;
   *) report 'Bluetooth controller power state unknown at startup; skipping.';;
  esac
 fi
 current="$(read_mute microphone)"
 case "$mic" in
  yes|no)
   if [[ "$current" == "$mic" ]]; then report 'Microphone mute already matches saved state.'
   elif [[ "$mic" == yes ]]; then change microphone off || failed=1
   else change microphone on || failed=1; fi;;
  *) report 'Microphone mute state unknown at startup; skipping.';;
 esac
 current="$(read_mute speakers)"
 case "$spk" in
  yes|no)
   if [[ "$current" == "$spk" ]]; then report 'Speaker mute already matches saved state.'
   elif [[ "$spk" == yes ]]; then change speakers off || failed=1
   else change speakers on || failed=1; fi;;
  *) report 'Speaker mute state unknown at startup; skipping.';;
 esac
 current="$(read_camera)"
 case "$uvc" in
  loaded|unloaded)
   if [[ "$current" == "$uvc" ]]; then report 'Supported camera module already matches saved state.'
   elif [[ "$uvc" == loaded ]]; then change camera on || failed=1
   else change camera off || failed=1; fi;;
  *) report 'Supported camera state unknown at startup; skipping.';;
 esac
 if [[ "$failed" == 0 ]]; then
  report 'Device restore requests completed. Check actual states before assuming restoration succeeded.'
 else
  report 'Some device restore commands FAILED. The backup has been retained for retry.'
 fi
 return "$failed"
}
case "$mode" in
 snapshot) snapshot;;
 ghost)
   report 'GS BlackOut: attempting device lockdown, remote-service lockdown, and block ALL incoming ports.'
   # Require privilege authorization BEFORE recording or changing any settings.
   # If authorization is declined, do not leave a misleading pending snapshot.
   if ! command -v sudo >/dev/null || ! sudo -v; then
     report 'GS BlackOut cancelled: administrator authorization was not granted.'
     exit 1
   fi
   snapshot || exit 1
   errors=0
   for device in wifi bluetooth microphone speakers camera; do change "$device" off || errors=1; done
   report 'Applying Remote Access Lockdown: UFW policy and known remote services...'
   bash "$BASE/remote-lockdown.sh" apply --confirmed || { report 'Remote access lockdown failed/incomplete.'; errors=1; }
   report 'Applying GS Port Lockdown: block ALL incoming connections through UFW...'
   bash "$BASE/gs-port-lockdown.sh" apply-all --confirmed || { report 'Port lockdown failed/incomplete; check firewall status.'; errors=1; }
   report 'Applying extra privacy controls (networking, WWAN and active services)...'
   bash "$BASE/blackout-extra.sh" apply || { report 'Some additional privacy controls failed or had an existing saved state.'; errors=1; }
   report 'Run the BlackOut Verification Report (option [3]) to inspect remaining exposure.'
   report 'GS BlackOut does not block outgoing network traffic or physically disable hardware.'
   if ((errors)); then report 'INCOMPLETE BLACKOUT: some steps failed. Review and verify before relying on controls.'; else report 'BlackOut requests verified where supported. Unrecognized devices remain unverified.'; fi
   report 'Use Turn It All On [19] to undo only GS BlackOut changes.'
   exit "$errors";;
 restore) restore_devices;;
 wifi|bluetooth|microphone|speakers|camera)
   [[ "$setting" == on || "$setting" == off ]] || { report "Usage: $0 $mode on|off"; exit 2; }
   change "$mode" "$setting";;
 status)
   printf 'Wi-Fi: %s\n' "$(read_wifi)"
   printf 'Bluetooth soft-blocked: %s\n' "$(read_bt_block)"
   printf 'Bluetooth powered: %s\n' "$(read_bt_power)"
   printf 'Microphone muted: %s\n' "$(read_mute microphone)"
   printf 'Speakers muted: %s\n' "$(read_mute speakers)"
   printf 'Webcam uvcvideo module: %s (other cameras unverified)\n' "$(read_camera)"
   [[ -f "$STATE" ]] && report 'GS startup baseline: recorded (BlackOut has a separate activation snapshot)' || report 'GS startup settings backup: missing';;
 *) report 'Usage: device-controls.sh snapshot|ghost|restore|status|wifi|bluetooth|microphone|speakers|camera'; exit 2;;
esac
