#!/usr/bin/env python3
"""Automatic, read-only first-run settings backup for Ghost Strategist.

No privilege escalation, device toggles, network reconnects, or package installs.
The device snapshot is shared with GS BlackOut restoration to prevent a second,
incompatible baseline from being recorded after changes have already begun.
"""
from __future__ import annotations

import os
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
REQUIRED = {'WIFI', 'BT_BLOCK', 'BT_POWER', 'MIC_MUTE', 'SPK_MUTE', 'UVC'}
LABELS = {
    'CAPTURED_AT': 'First recorded (UTC)',
    'WIFI': 'Wi-Fi radio',
    'BT_BLOCK': 'Bluetooth soft block',
    'BT_POWER': 'Bluetooth controller',
    'MIC_MUTE': 'Microphone muted',
    'SPK_MUTE': 'Speakers muted',
    'UVC': 'USB camera driver (uvcvideo)',
}
OTHER_BACKUPS = (
    ('Remote access', 'remote-lockdown-state.tsv'),
    ('GS BlackOut extra controls', 'blackout-extra-v47.tsv'),
    ('GS firewall rules', 'port-lockdown-v22.state'),
    ('DHCP client identity', 'ip-changer-v42.json'),
)


def directory() -> Path:
    return Path(os.getenv('XDG_STATE_HOME', str(Path.home() / '.local' / 'state'))) / 'ghost-strategist-tool'


def snapshot_path() -> Path:
    return directory() / 'blackout-devices-v23.tsv'


def read_snapshot() -> dict[str, str] | None:
    location = snapshot_path()
    try:
        if location.is_symlink() or not location.is_file():
            return None
        if location.stat().st_size > 8192:
            return None
        rows = location.read_text(encoding='utf-8').splitlines()
        data = {}
        for line in rows:
            if '|' not in line:
                return None
            key, value = line.split('|', 1)
            if not key.isupper() or key in data or len(value) > 96:
                return None
            data[key] = value
        return data if REQUIRED.issubset(data) else None
    except (OSError, UnicodeError):
        return None


def ensure_initial_snapshot(runner=subprocess.run) -> str:
    """Capture once without sudo. Preserve earlier backups across app restarts.

    Returns a concise status; failure doesn't make the toolkit unusable.
    """
    state_dir = directory()
    path = snapshot_path()
    if path.exists() or path.is_symlink():
        if read_snapshot() is not None:
            return 'SAVED — initial settings preserved (not overwritten)'
        return 'WARNING — existing settings backup needs review; not overwritten'
    if state_dir.is_symlink():
        return 'WARNING — unsafe settings folder; backup not written'
    try:
        proc = runner(['bash', str(BASE / 'device-controls.sh'), 'snapshot'],
                      capture_output=True, text=True, timeout=15, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return 'WARNING — initial settings capture unavailable; no settings changed'
    if proc.returncode == 0 and read_snapshot() is not None:
        return 'SAVED — original settings recorded automatically'
    return 'WARNING — could not verify initial settings backup; no settings changed'


def preview() -> str:
    data = read_snapshot()
    if data is None:
        return ('! No valid startup backup was found. Relaunch the toolkit to retry.\n'
                '! Existing unreadable backups are never overwritten automatically.')
    lines = ['SAVED INITIAL SETTINGS',
             '! Recorded automatically on the first launch; not overwritten on restart.']
    for key, label in LABELS.items():
        if key not in data:
            continue
        value = data[key]
        if value == 'unknown':
            value = 'Unavailable — will not be guessed'
        lines.append(f'  {label:<32} {value}')
    lines += ['', 'OTHER FEATURE RESTORE POINTS']
    root = directory()
    for label, filename in OTHER_BACKUPS:
        p = root / filename
        status = 'Available' if p.is_file() and not p.is_symlink() else 'None'
        lines.append(f'  {label:<32} {status}')
    lines.extend(['', '! Only supported settings can be restored; this is not a system image.',
                  '! Network and remote-access changes may require additional checks after restoration.'])
    return '\n'.join(lines)
