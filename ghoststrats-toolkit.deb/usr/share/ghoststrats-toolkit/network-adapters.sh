#!/usr/bin/env bash
# Read-only network adapter information for Linux Mint.
set -u
printf '\n\033[35mGHOST STRATEGIST TOOL — NETWORK ADAPTERS\033[0m\n'
printf 'Read-only information. This does not scan the network or change adapters.\n\n'
if command -v nmcli >/dev/null 2>&1; then
  printf '\033[1mNetworkManager device status\033[0m\n'
  nmcli -f DEVICE,TYPE,STATE,CONNECTION device status || true
  printf '\n'
else
  echo 'nmcli unavailable (NetworkManager may not be installed).'
fi
if command -v ip >/dev/null 2>&1; then
  printf '\033[1mInterface link status\033[0m\n'
  ip -br link show || true
  printf '\n\033[1mInterface IP addresses\033[0m\n'
  ip -br address show || true
  printf '\n'
else
  echo 'ip command unavailable; install iproute2 for interface details.'
fi
printf 'DOWN or disconnected adapters may still be present; this is a status view.\n'
