# Publish GhostStrats Toolkit on GitHub

These files are prepared from the **V81** source release. They have not been uploaded to your GitHub account.

## Repository settings

- Repository name: `Ghost-Strategist-Toolkit`
- Description: See [`GITHUB_DESCRIPTION.txt`](GITHUB_DESCRIPTION.txt).
- Suggested topics: `linux`, `linux-mint`, `kali-linux`, `parrot-os`, `tails`, `privacy`, `cybersecurity`, `networking`, `terminal`, `bash`, `python`, `remote-id`, `drone-detection`.
- Visibility: Public if you want the community to see the source; private if you are not ready to publish.
- README: already provided as `README.md`. Don't generate another one with GitHub's initialization wizard if uploading these files by Git.
- License: **Not selected**. Choose one deliberately before granting redistribution rights. No license file has been invented or added.

## Upload using Git

Extract the `Ghost-Strategist-Toolkit-GitHub-Ready-V81.zip` archive. Open a terminal in the extracted `Ghost-Strategist-Toolkit` directory.

### Create an empty repository on github.com

Sign in to GitHub, select **New repository**, enter `Ghost-Strategist-Toolkit`, paste the About description from `GITHUB_DESCRIPTION.txt`, and create the repository **without** auto-adding a README, `.gitignore` or license (those first two are already in the project folder).

Then run in your local extracted directory:

```bash
git init
git add .
git commit -m "Initial release: GhostStrats Toolkit V81"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/Ghost-Strategist-Toolkit.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your account or organization. GitHub may request authentication using your Git credentials or a token. **Do not publish passwords or tokens in repository files.**

If the repository already exists, use its actual remote URL and reconcile its files rather than overwriting its history.

## Release files

When you create a **V81 release** on GitHub, you can attach the existing downloadable V81 ZIP and the `ghoststrats-toolkit_8.1.0_all.deb` binary package as release assets. The source repo intentionally does not duplicate these binary downloads.

## What is in the prepared source ZIP

- All V81 application source scripts and bundled features
- Installer, portable runner and uninstaller
- Current polished `README.md` plus drone-detector guide
- Automated regression tests
- `.gitignore` for caches, venvs and local data
- This setup guide and ready-to-paste GitHub description

The source package deliberately omits **old version-by-version changelogs and spoiler-heavy Easter egg guide documents** to make the public repository easier to browse. Application logic and its Easter eggs are not modified. The source code itself remains readable, as expected for an open GitHub source repository.

## Verify locally before publishing

```bash
python3 -m unittest discover -s tests -q
bash gs-drone-detector.sh test
bash -n gs.sh Install-and-Run.sh Run-Portable.sh Uninstall-GhostStrats.sh
```

For an actual device test, verify controls on a spare Linux Mint installation and use authorized networks. Passing software tests cannot guarantee physical hardware control or Remote ID reception.
