#!/usr/bin/env python3
"""Read-only built-in MAC address and local-link inspection."""
from gs_brand import print_gs as print
import sys
import subprocess
import shutil
from pathlib import Path


def run(*args):
    if not shutil.which(args[0]):
        print(f"Unavailable: {args[0]} is not installed. No packages will be installed.")
        return
    try:
        result=subprocess.run(args, text=True, capture_output=True, timeout=20, check=False)
        print(result.stdout.strip() or result.stderr.strip() or 'No data reported.')
    except (OSError, subprocess.TimeoutExpired) as error:
        print(f'Unable to run command: {error}')


def addresses():
    print('LOCAL INTERFACE MAC ADDRESSES (READ ONLY)')
    for iface in sorted(Path('/sys/class/net').glob('*')):
        def read(name):
            try: return (iface/name).read_text().strip()
            except OSError: return 'unavailable'
        print(f'{iface.name:18} address={read("address"):20} state={read("operstate"):10} type={read("type")}')


def permanent():
    print('PERMANENT MAC ADDRESSES (READ ONLY)')
    addresses()
    if shutil.which('ethtool'):
        for iface in sorted(Path('/sys/class/net').glob('*')):
            print(f'\n{iface.name}:')
            run('ethtool', '-P', iface.name)
    else:
        print('\nPermanent hardware addresses require ethtool; unavailable without it.')
    print('Note: permanent-address reporting varies by driver and device.')


def neighbors():
    print('KNOWN NEIGHBORS — CACHE ONLY (NO ACTIVE SCAN)')
    run('ip','neigh','show')


def stats():
    print('NETWORK INTERFACE STATISTICS (READ ONLY)')
    run('ip','-s','link','show')


def wifi():
    print('NEARBY WI-FI BSSIDs — NETWORKMANAGER')
    run('nmcli','-f','SSID,BSSID,CHAN,FREQ,SIGNAL,SECURITY','device','wifi','list')


def nm():
    print('NETWORKMANAGER DEVICE DETAILS')
    run('nmcli','device','show')


if __name__ == '__main__':
    actions={'1':addresses,'2':permanent,'3':neighbors,'4':stats,'5':wifi,'6':nm,
             'check':addresses}
    if len(sys.argv)!=2 or sys.argv[1] not in actions:
        print('Usage: python3 mac-controls.py [1|2|3|4|5|6]')
        sys.exit(2)
    actions[sys.argv[1]]()
