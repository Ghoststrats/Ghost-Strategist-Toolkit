#!/usr/bin/env python3
"""Ghost Strategist Toolkit: built-in Linux utilities and privacy controls."""
from gs_brand import print_gs as print
import ctypes, ctypes.util, os, re, select, shutil, subprocess, sys, time, textwrap, termios, tty
import gs_keys
from pathlib import Path
import scanning
import persistence_privacy
import easter_eggs
import gs_snake
import task_manager
import diagnostics
import startup_settings
import gs_platform
import importlib.util

def load_local_module(filename, name):
    spec=importlib.util.spec_from_file_location(name, Path(__file__).resolve().parent / filename)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

network_intelligence=load_local_module("network-intelligence.py", "gs_network_intelligence")
ip_changer=load_local_module("ip-changer.py", "gs_ip_changer")

BASE = Path(__file__).resolve().parent
TEST = os.getenv('GHOSTSTRAT_TEST_MODE') == '1'
PLATFORM = gs_platform.detect()
TAILS_SAFE = PLATFORM == 'tails'
PURPLE='\033[38;5;141m'; WHITE='\033[97m'; GRAY='\033[90m'; RED='\033[91m'; RESET='\033[0m'
DIM='\033[38;5;245m'; BOLD='\033[1m'
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')
COLOR_ON = os.getenv('NO_COLOR') is None and sys.stdout.isatty()

# At startup, remember a *known-good* terminal mode. Some external tools and
# live viewers leave ECHO/ICANON disabled after an unexpected exit. If the next
# menu inherits that state, keystrokes can appear blank or unresponsive.
_TERMINAL_FD = None
_TERMINAL_BASELINE = None


def remember_terminal():
    """Capture console settings once, before opening any tool or submenu."""
    global _TERMINAL_FD, _TERMINAL_BASELINE
    _TERMINAL_FD = None
    _TERMINAL_BASELINE = None
    try:
        fd = sys.stdin.fileno()
        if os.isatty(fd) and sys.stdout.isatty():
            _TERMINAL_BASELINE = termios.tcgetattr(fd)
            _TERMINAL_FD = fd
    except (AttributeError, OSError, ValueError, termios.error):
        pass


def restore_terminal():
    """Recover terminal echo/input state after a command without flushing keys.

    Do not force a global `stty sane`: restore only the precise attributes
    captured at startup so terminal preferences and control characters survive.
    No change occurs on redirected input or during an active child process.
    """
    if _TERMINAL_BASELINE is None or _TERMINAL_FD is None:
        return False
    try:
        current = termios.tcgetattr(_TERMINAL_FD)
        if current != _TERMINAL_BASELINE:
            termios.tcsetattr(_TERMINAL_FD, termios.TCSADRAIN, _TERMINAL_BASELINE)
            return True
    except (OSError, ValueError, termios.error):
        return False
    return False

def paint(content, tone):
    """Style text consistently; GS branding remains purple inside any other tone."""
    if not COLOR_ON:
        return str(content)
    data = str(content)
    data = re.sub(r'(?<![A-Za-z0-9_])GS(?![A-Za-z0-9_])',
                  lambda match: PURPLE + match.group(0) + RESET + tone, data)
    return tone + data + RESET


def purple_gs(value):
    # Color just the standalone GS initials in every toolkit-owned menu/status.
    if os.getenv('NO_COLOR') is not None or not sys.stdout.isatty():
        return value
    return re.sub(r'\bGS\b', PURPLE+'GS'+RESET, value)


class X11Idle:
    class Info(ctypes.Structure):
        _fields_=[('window',ctypes.c_ulong),('state',ctypes.c_int),('kind',ctypes.c_int),('since',ctypes.c_ulong),('idle',ctypes.c_ulong),('mask',ctypes.c_ulong)]
    def __init__(self):
        if not os.getenv('DISPLAY') or os.getenv('XDG_SESSION_TYPE','x11').lower()=='wayland':
            raise RuntimeError('Requires an X11 desktop session for system-wide idle detection')
        a,b=ctypes.util.find_library('X11'),ctypes.util.find_library('Xss')
        if not a or not b: raise RuntimeError('X11 idle libraries not installed')
        self.x=ctypes.CDLL(a); self.ss=ctypes.CDLL(b)
        self.x.XOpenDisplay.argtypes=[ctypes.c_char_p]; self.x.XOpenDisplay.restype=ctypes.c_void_p
        self.x.XDefaultRootWindow.argtypes=[ctypes.c_void_p]; self.x.XDefaultRootWindow.restype=ctypes.c_ulong
        self.ss.XScreenSaverAllocInfo.restype=ctypes.POINTER(self.Info)
        self.ss.XScreenSaverQueryInfo.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(self.Info)]
        self.ss.XScreenSaverQueryInfo.restype=ctypes.c_int
        self.d=self.x.XOpenDisplay(None)
        if not self.d: raise RuntimeError('Could not open X display')
        self.root=self.x.XDefaultRootWindow(self.d); self.info=self.ss.XScreenSaverAllocInfo()
    def seconds(self):
        if not self.ss.XScreenSaverQueryInfo(self.d,self.root,self.info): raise RuntimeError('Idle query failed')
        return self.info.contents.idle//1000

idle=None
armed=False
armed_at=None
idle_error=None
msg=''

# A fixed-size text header. No image conversions, redraw loops, or external art tools.
COUNT_ROW = 0
LAST_COUNT = object()

# Nineteen distinct front-page workflows. Related hardware controls are grouped;
# read-only scanning remains directly discoverable. Subtool scripts are retained
# where their functionality is genuinely different, not duplicated on home.
MAIN_SECTIONS = (('GHOSTSTRATS TOOLS', (('1', 'GS BlackOut'),
    ('2', 'GS NullOut'),
    ('3', 'GS Threat Analysis'),
    ('4', 'GS BugOut'),
    ('5', 'GS Network Intelligence'),
    ('6', 'GS Drone Detector'))),
    ('DISCOVERY & SCANNING', (('7', 'Wireless & LAN Discovery'),
    ('8', 'Built-in Network Tools'),
    ('9', 'File Explorer'),
    ('10', 'Network & IP Settings'))),
    ('DEVICE & ACCESS CONTROL', (('11', 'Wi-Fi & Bluetooth'),
    ('12', 'Camera, Mic & Audio'),
    ('13', 'MAC Address Inspector'),
    ('14', 'Firewall & Port Security'),
    ('15', 'Remote Access Lockdown'))),
    ('SYSTEM & UTILITIES', (('16', 'Startup & Privacy Audit'),
    ('17', 'Task Manager'),
    ('18', 'System & Device Overview'),
    ('19', 'Turn It All On'))))

# Reserved for future help integration. Submenu explanations remain unchanged.
MAIN_DESCRIPTIONS = {'1': 'Review and disable supported radios, audio, camera and remote services.', '2': 'Configure the inactivity shutdown timer and check its status.', '3': 'Inspect local security findings, open ports and active connections.', '4': 'Run a confirmed full session cleanup followed by system shutdown.', '5': 'Inspect local routing, DNS, sockets and network configuration.', '7': 'Explore visible wireless networks and known LAN devices.', '8': 'Run built-in Linux networking information commands.', '9': 'Browse files, inspect metadata and view folder trees.', '10': 'Review network addresses, interfaces, routes and DNS settings.', '11': 'Review and control supported Wi-Fi and Bluetooth radios.', '12': 'Inspect and manage supported camera, microphone and audio controls.', '13': 'Inspect current, factory and neighboring MAC addresses.', '14': 'Review firewall rules, listening ports and supported controls.', '15': 'Inspect or disable supported remote-access services.', '16': 'Review startup entries, persistence points and privacy residue.', '17': 'Inspect running processes and manage supported tasks.', '18': 'Review system information, devices and hardware status.', '19': 'Only reverse changes recorded during GS BlackOut; not a general restore.', '6': 'Launch Turbo drone-only Wi-Fi/BLE/Remote ID scan. Esc stops and goes home.'}


def main_menu_options():
    """Introspectable menu; rendering chooses layout suitable for width."""
    lines=[]
    for title, entries in MAIN_SECTIONS:
        lines.append(title)
        lines.extend(f'[{int(key)}]  {label}' for key,label in entries)
        lines.append('')
    lines += ['[H]  Help & Diagnostics', '[0]  Exit']
    return lines


# Responsive labels retain a meaningful name even on a 40-column terminal.
# Only the *display* text changes. The numbered actions and handlers do not.
MAIN_SHORT_LABELS = {'1': 'GS BlackOut', '2': 'GS NullOut', '3': 'GS Threat', '4': 'GS BugOut', '5': 'GS Network', '7': 'Wi-Fi / LAN', '8': 'Network Tools', '9': 'File Explorer', '10': 'Network / IP', '11': 'Wi-Fi / BT', '12': 'Cam / Audio', '13': 'MAC Inspector', '14': 'Firewall', '15': 'Remote Access', '16': 'Startup Audit', '17': 'Task Manager', '18': 'System Info', '19': 'Turn It All On', '6': 'GS Drone'}
MAIN_TINY_LABELS = {'1': 'BlackOut', '2': 'NullOut', '3': 'GS Threat', '4': 'BugOut', '5': 'GS Net', '7': 'Wi-Fi/LAN', '8': 'Net Tools', '9': 'Files', '10': 'Net/IP', '11': 'Wi-Fi/BT', '12': 'Cam/Audio', '13': 'MAC Info', '14': 'Firewall', '15': 'Remote', '16': 'Startup', '17': 'Tasks', '18': 'Hardware', '19': 'Turn On', '6': 'GS Drone'}
def format_home_choice(key, label, available):
    """Fit the numbered tool name; the main menu shows no inline notes."""
    for name in (label, MAIN_SHORT_LABELS[key], MAIN_TINY_LABELS[key]):
        option = f'[{key}] {name}'
        if len(option) <= available:
            return option
    return f'[{key}]'


def countdown_text(remain):
    """Create a status snapshot; never move the cursor or alter terminal input."""
    if armed:
        if remain is None:
            return 'GS NullOut: ERROR — idle monitoring unavailable (disabled)'
        status = ('GS NullOut: ACTIVE — inactivity shutdown armed'
                  if not TEST else 'GS NullOut: TEST MODE — shutdown disabled')
        meter = '[' + '#' * max(0, min(15, (remain + 3)//4)) + '-' * (15 - max(0, min(15, (remain + 3)//4))) + ']'
        return (f'! GS NULLOUT — SHUTDOWN WARNING: {remain}s LEFT — MOVE MOUSE OR TYPE'
                if remain <= 15 else f'{status}  {meter}  {remain}s  |  [2] controls')
    if TAILS_SAFE:
        return 'GS NullOut: UNAVAILABLE ON TAILS (restricted session)'
    return 'GS NullOut: INACTIVE — enable in [2]'


def show_countdown(remain):
    """Compatibility function; active timer updates are handled by _refresh_status."""
    return countdown_text(remain)

def ui(title, body, remain, show_nullout=False, clear=True):
    """Render a compact home dashboard and single-column tool submenus.

    User-selected settings are never changed during rendering. The input
    reader preserves partially typed text when refreshing the timer status.
    """
    global COUNT_ROW, LAST_COUNT
    if clear:
        sys.stdout.write('\033[2J\033[H')
    else:
        print()
    terminal_columns = shutil.get_terminal_size((100, 32)).columns
    width = max(32, min(112, terminal_columns - 6))
    visual_rows = 0

    def edge(symbol='middle'):
        nonlocal visual_rows
        left, right = {'top': ('┌','┐'), 'middle': ('├','┤'), 'bottom': ('└','┘')}[symbol]
        print(paint('  '+left+'─'*width+right, PURPLE if symbol=='top' else DIM))
        visual_rows += 1

    def line(text='', style=''):
        nonlocal visual_rows
        text = ANSI_RE.sub('', str(text)).rstrip()
        usable = width - 3
        wrapped = textwrap.wrap(text, width=usable,
                   break_long_words=False, break_on_hyphens=False,
                   replace_whitespace=False, drop_whitespace=False) or ['']
        for fragment in wrapped:
            print(paint('  │ ', DIM) + paint(fragment, style) + ' '*max(0,width-2-len(fragment)) + paint('│', DIM))
            visual_rows += 1

    edge('top')
    line('Ghost Strategist Toolkit', BOLD+PURPLE)
    line('PRIVACY / SAFETY IS AN ILLUSION', BOLD+WHITE)
    line('STRICTLY FOR EDUCATIONAL PURPOSES ONLY', RED+BOLD)
    if TAILS_SAFE:
        line('TAILS RESTRICTED MODE — INSPECTION TOOLS ONLY', RED+BOLD)
    if title != 'MAIN MENU':
        edge()
        line(title.upper(), BOLD+WHITE)
        line('ESC  Home     0  Back     ?  Guide     ENTER  Select', DIM)
        edge()

    # The real main menu is a fixed composition; test-provided arbitrary body
    # text still renders normally for unit tests and compatibility.
    real_dashboard = title == 'MAIN MENU' and body == main_menu_options()
    if real_dashboard:
        # Four category panels in a two-column / two-row grid. This avoids the
        # V63 long scrolling output that could leave status updates inside the
        # visible menu on a standard 24-line terminal.
        inner = width - 3
        gutter = 2
        left_width = (inner - gutter) // 2
        right_width = inner - gutter - left_width

        def grid_row(left_text, right_text, left_tone=WHITE, right_tone=WHITE):
            nonlocal visual_rows
            left_text = str(left_text)[:left_width]
            right_text = str(right_text)[:right_width]
            print(paint('  │ ', DIM) +
                  paint(left_text, left_tone) + ' ' * (left_width-len(left_text)) +
                  ' ' * gutter +
                  paint(right_text, right_tone) + ' ' * (right_width-len(right_text)) +
                  paint('│', DIM))
            visual_rows += 1

        def panel_pair(first, second):
            heading_a, entries_a = first
            heading_b, entries_b = second
            if left_width < len(heading_a):
                heading_a = 'GS TOOLS' if heading_a == 'GHOSTSTRATS TOOLS' else 'DEVICE CONTROLS'
            if right_width < len(heading_b):
                heading_b = 'DISCOVERY' if heading_b == 'DISCOVERY & SCANNING' else 'SYSTEM TOOLS'
            grid_row(heading_a, heading_b, PURPLE+BOLD, PURPLE+BOLD)
            for i in range(max(len(entries_a), len(entries_b))):
                first_key, first_label = entries_a[i] if i < len(entries_a) else ('', '')
                second_key, second_label = entries_b[i] if i < len(entries_b) else ('', '')
                a = format_home_choice(first_key, first_label, left_width) if first_key else ''
                b = format_home_choice(second_key, second_label, right_width) if second_key else ''
                grid_row(a, b,
                         DIM if TAILS_SAFE and first_key and first_key not in gs_platform.TAILS_ALLOWED else WHITE,
                         DIM if TAILS_SAFE and second_key and second_key not in gs_platform.TAILS_ALLOWED else WHITE)

        edge()
        panel_pair(MAIN_SECTIONS[0], MAIN_SECTIONS[1])
        # At very narrow terminal widths this spacer would scroll the footer.
        if terminal_columns >= 48:
            line('  ' + '─' * max(1, width-8), DIM)
        panel_pair(MAIN_SECTIONS[2], MAIN_SECTIONS[3])
    else:
        for raw in (body[:-2] if real_dashboard else body):
            plain=ANSI_RE.sub('',str(raw)).strip()
            if not plain:
                line()
            elif plain in {section[0] for section in MAIN_SECTIONS} or plain in (
                     'OVERVIEW','AVAILABLE ACTIONS','HELP TOPICS','TOOLS','ABOUT THIS TOOL',
                     'WHY I BUILT THIS','BEFORE YOU BEGIN') or (
                     len(plain) <= 65 and plain.upper() == plain
                     and len(plain) > 3 and not plain.startswith(('!', '[', '-'))
                     and bool(re.search('[A-Z]', plain))):
                line('  '+plain, PURPLE+BOLD)
            elif plain.startswith('['):
                line('  '+plain, WHITE if not re.match(r'\[(?:0|H)\]',plain,re.I) else PURPLE)
            elif plain.startswith('!') or plain.startswith('- '):
                line('  '+plain, DIM)
            else:
                line('  '+plain, DIM)
    if real_dashboard:
        edge()
        line('  [H] HELP & WALKTHROUGHS         [0] EXIT' if width >= 52
             else '  [H] HELP   [0] EXIT', WHITE)
    edge('bottom')

    if show_nullout:
        notice_rows = (len(textwrap.wrap('! '+str(msg).lstrip('! '),
                       width=max(28, terminal_columns - 4))) if msg else 0)
        terminal_rows = shutil.get_terminal_size((80, 24)).lines
        # Long stacked menus scroll. Their status row ends up near the bottom
        # of the *visible* terminal; avoid cursor moves beyond screen height.
        COUNT_ROW = (visual_rows+1 if visual_rows+2+notice_rows < terminal_rows
                     else max(1, terminal_rows-1-notice_rows))
        print(_status_line(remain))
        if msg:
            for fragment in textwrap.wrap('! '+str(msg).lstrip('! '), width=max(28, terminal_columns - 4)):
                print('  '+paint(fragment, DIM))
        if title != 'MAIN MENU':
            print()
    else:
        COUNT_ROW=0
        print()
    sys.stdout.write(paint('  gs', PURPLE) + paint('  ›  ', DIM))
    sys.stdout.flush()
    LAST_COUNT=countdown_text(remain)

def _status_line(remain):
    """Render a bounded NullOut footer; the separate input row is never touched."""
    status = countdown_text(remain)
    if not armed and startup_settings.read_snapshot() is not None:
        status += '  |  SETTINGS SAVED'
    terminal_width = shutil.get_terminal_size((80, 24)).columns
    status = status[:max(12, terminal_width - 4)]
    style = RED if armed and (remain is None or remain <= 15) else PURPLE if armed else DIM
    return '  ' + paint(status, style)


def _refresh_status(remain):
    """In-place single-line update with cursor save/restore. Never clears the screen.

    The cursor returns to the exact input position so partial commands survive.
    Deliberately avoids terminal scroll, extra newlines and full-menu repainting.
    """
    if COUNT_ROW <= 0 or not (sys.stdin.isatty() and sys.stdout.isatty()):
        return
    sys.stdout.write('\0337' + f'\033[{COUNT_ROW};1H' + '\033[2K' + _status_line(remain) + '\0338')
    sys.stdout.flush()


def _read_main_choice(body):
    """Stable, single-prompt main menu: do not animate/repaint while typing.

    Earlier versions used a second keyboard reader and wrote a changing status
    to an absolute screen row every 200ms. Terminal scrolling, resize or a
    child program's screen modes could move that row into the selection prompt
    or blank the visible menu. All toolkit-owned prompts now use gs_keys and
    never reposition the cursor on a timer.

    GS NullOut is still checked by the input watchdog every 200ms; its
    remaining time is shown as a snapshot each time the menu is opened.
    """
    ui('MAIN MENU', body, remaining(), show_nullout=True, clear=True)
    while True:
        try:
            choice = gs_keys.read_line('', watchdog=remaining, interval=0.2).strip()
        except gs_keys.HomeRequested:
            # Esc already means Home; on Home it is a harmless no-op, not a
            # reason to clear and redraw continuously.
            continue
        if choice:
            return choice
        # Empty Enter should not erase the screen or start another input loop
        # in a new terminal mode. Keep the same displayed menu and prompt.
        sys.stdout.write(paint('  gs', PURPLE) + paint('  ›  ', DIM))
        sys.stdout.flush()


def wait_for_continue():
    """Keep the result visible; Enter or Esc returns to the main menu."""
    try:
        gs_keys.read_line(paint('\n  [Enter / Esc] Return to main menu ...', DIM), watchdog=remaining)
    except gs_keys.HomeRequested:
        return


def ask(question):
    return gs_keys.read_line(purple_gs('\n' + question + ' [y/N]: '), watchdog=remaining).strip().lower() == 'y'


def cmd_run(cmd):
    """Run a toolkit action without suspending GS NullOut checks while it waits.

    The child retains the terminal for confirmations and output. We don't read
    stdin here, so user prompts inside the child continue to function.
    """
    try:
        process = subprocess.Popen(cmd, cwd=str(BASE))
    except OSError as exc:
        print('Could not run command:', exc)
        return 1
    try:
        while True:
            try:
                return process.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                if armed:
                    remaining()
    except KeyboardInterrupt:
        # Interactive Ctrl+C usually reaches the child too; avoid orphaning it.
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        print('\nAction interrupted.')
        return 130
    finally:
        restore_terminal()


def monitored_runner(command, *, check=False, timeout=120):
    """Stream an external scanner's output while retaining the NullOut watchdog."""
    process=subprocess.Popen(command,cwd=str(BASE))
    deadline=time.monotonic()+timeout if timeout else None
    try:
        while True:
            try:
                return subprocess.CompletedProcess(command,process.wait(timeout=0.35))
            except subprocess.TimeoutExpired:
                if armed:
                    remaining()  # critical: do not suspend the inactivity watchdog
                if deadline and time.monotonic()>=deadline:
                    process.terminate()
                    try:process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        process.kill();process.wait()
                    raise subprocess.TimeoutExpired(command,timeout)
    except BaseException:
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill();process.wait()
        raise
    finally:
        restore_terminal()


def run_script(script, *args):
    # Stay in the SAME terminal. No child terminal window or auto-closer.
    code=cmd_run(['bash', str(BASE / script), *args])
    return 'Action completed.' if code == 0 else f'Action exited with error code {code}. See output above.'


def run_python(script, *args):
    code=cmd_run([sys.executable, str(BASE / script), *args])
    return 'Action completed.' if code == 0 else f'Action exited with error code {code}. See output above.'


def note(message):
    """Small light-gray educational or action-result evaluation."""
    for line in _wrap_lines('! ' + message, '  '):
        print(paint(line, DIM))

def info_status():
    print('\nDEVICE STATUS — read only')
    return run_script('device-controls.sh', 'status')


def blackout_status():
    print('\nGS BLACKOUT STATUS — read only')
    return run_script('blackout-verify.sh')


def blackout_apply():
    print('\nGS BlackOut attempts to turn Wi-Fi/Bluetooth OFF, mute mic/speakers,')
    print('disable supported cameras, stop known remote-access services and')
    print('block NEW incoming traffic covered by UFW, stop optional services,')
    print('disable NetworkManager networking and mobile broadband where supported.')
    print('Wi-Fi and local or remote access may be interrupted. Previous state is backed up.')
    if not ask('Apply GS BlackOut now?'):
        return 'GS BlackOut cancelled; no changes requested.'
    code = cmd_run(['bash', str(BASE / 'blackout-control.sh'), 'apply'])
    print('\n--- CURRENT BLACKOUT STATUS (READ-ONLY) ---')
    cmd_run(['bash', str(BASE / 'blackout-verify.sh')])
    if code != 0:
        return ('GS BlackOut INCOMPLETE (exit %s). Some settings may remain ON. '
                'See the checks above; do not assume full lockdown. '
                'Turn It All On [19] can reverse the recorded session.' % code)
    return ('GS BlackOut finished and its supported actions reported success. '
            'Review the verification above: unknown radios, cameras, sockets '
            'and UFW exceptions are not guaranteed to be disabled.')


def restore_all():
    """Reverse GS BlackOut only, from its activation-time snapshot."""
    code = cmd_run(['bash', str(BASE / 'restore-all.sh')])
    if code == 0:
        return ('GS BlackOut recovery completed. Check the actual Wi-Fi, Bluetooth, '
                'network, audio, camera, service and firewall states; no other '
                'tool settings were deliberately restored.')
    if code == 10:
        return 'Turn It All On cancelled before changes began. BlackOut backup retained.'
    if code == 2:
        return 'No GS BlackOut activation backup; nothing was turned on or changed.'
    return ('GS BlackOut recovery incomplete (exit %s). Some settings may have '
            'changed; inspect the messages and retry the recorded BlackOut steps.' % code)


def show_blackout_record():
    """Read only: display BlackOut-specific backup and ownership flags."""
    path = Path(os.getenv('XDG_STATE_HOME', str(Path.home()/'.local/state'))) / 'ghost-strategist-tool' / 'blackout-session-v66.tsv'
    if not path.is_file() or path.is_symlink():
        return ('No GS BlackOut activation snapshot was found. Turn It All On will '
                'not change any devices or services unless BlackOut has recorded a session.')
    permitted = {'CAPTURED_AT','WIFI','BT_BLOCK','BT_POWER','MIC_MUTE','SPK_MUTE',
                 'UVC','REMOTE_PREEXIST','PORT_PREEXIST','EXTRA_PREEXIST'}
    try:
        values = {k:v for k,v in (line.strip().split('|',1)
                  for line in path.read_text(encoding='utf-8').splitlines()
                  if '|' in line) if k in permitted}
    except (OSError, UnicodeError, ValueError) as exc:
        return f'Could not read the recorded GS BlackOut state: {exc}'
    if not {'WIFI','MIC_MUTE','REMOTE_PREEXIST','PORT_PREEXIST','EXTRA_PREEXIST'} <= values.keys():
        return 'GS BlackOut backup is incomplete; no restoration should be attempted.'
    return ('GS BLACKOUT ACTIVATION RECORD (READ ONLY)\n' +
            '\n'.join(f'  {k:<18} {values[k]}' for k in sorted(values)) +
            '\nOnly settings with a BlackOut-created backup can be restored.')


def show_initial_settings():
    print('\n' + startup_settings.preview())
    return 'Read-only preview complete. No settings changed.'



def network_status():
    return run_script('network-adapters.sh')


def task_view():
    # Integrated viewer returns on a single 0/Q key, and keeps NullOut monitored.
    return task_manager.live(remaining)


def wifi_do(action):
    return run_script('device-controls.sh','wifi',action)


def dev_do(dev,action):
    return run_script('device-controls.sh',dev,action)


def mac_do(action):
    return run_python('mac-controls.py',action)


def remote_do(action):
    """Report the outcome honestly; a read-only status is not a lockdown."""
    argv = ['bash', str(BASE / 'remote-lockdown.sh'), action]
    if action == 'details':
        argv = ['bash', str(BASE / 'remote-lockdown.sh'), 'status', '--details']
    code = cmd_run(argv)
    if action in ('status', 'details'):
        return ('Inspection finished (read only). An active firewall or zero '
                'recognized services does not prove that all remote access is blocked.'
                if code == 0 else 'Could not complete remote-access inspection; check errors above.')
    if code == 3 and action == 'apply':
        return ('NOT APPLIED: An earlier recovery backup is pending. '
                'Review status [1], then restore the appropriate prior session '
                'before attempting another lockdown.')
    if code == 2 and action == 'restore':
        return 'NOTHING TO RESTORE: No previous remote lockdown snapshot exists.'
    if code == 10:
        return 'Cancelled. No remote-access settings were changed by this request.'
    if code:
        return (f'INCOMPLETE (exit {code}): some changes may have occurred. '
                'Read the errors and inspect status [1]. Recovery backup is retained if present.')
    if action == 'apply':
        return ('Lockdown sequence completed for recognized services. Check status [1]; '
                'UFW allow rules, unknown services and outbound sessions may remain.')
    return 'Restore finished. Check status [1] to verify services and firewall policy.'


def port_do(action):
    return run_script('gs-port-lockdown.sh',action)


def print_sys():
    print('\nSYSTEM INFORMATION — read only')
    results = [cmd_run(command) for command in
               (['uname','-a'],['id'],['uptime'],['free','-h'])]
    return ('System information displayed.' if all(code == 0 for code in results)
            else 'Some system information was unavailable; see command errors above.')

def menu_sub(name, options, show_nullout=False, clear=True):
    global msg
    if name == 'MAIN MENU' and show_nullout:
        choice = _read_main_choice(options)
        return None if choice in (None, '0') else choice
    ui(name, options, remaining(), show_nullout, clear=clear)
    choice = gs_keys.read_line('', watchdog=remaining).strip()
    return None if choice == '0' else choice


def remaining():
    global armed, idle, armed_at, msg, idle_error
    if not armed:
        return None
    try:
        seconds = idle.seconds()
    except Exception as exc:
        armed=False
        armed_at=None
        idle_error=str(exc)
        msg='GS NullOut stopped: idle monitoring failed — '+idle_error
        return None
    # A full 60s grace period from enabling prevents an accidental immediate
    # shutdown if the system was already idle before the timer was armed.
    grace = max(0, 60-int(time.monotonic()-armed_at))
    left=max(grace, max(0,60-seconds))
    if left==0 and not TEST:
        sys.stdout.write('\033[2J\033[H'+RED+purple_gs('GS NullOut: 60 seconds of inactivity; requesting full system shutdown.')+'\n'+RESET)
        sys.stdout.flush()
        # Disarm first so a rejected shutdown request cannot repeatedly fire.
        armed=False
        armed_at=None
        rc=cmd_run(['systemctl','poweroff'])
        msg=f'GS NullOut shutdown request returned {rc}. Timer now inactive.'
    return left


def toggle_nullout():
    """A manual opt-in to the poweroff timer, with no startup side effects."""
    global idle, armed, armed_at, msg, idle_error
    if armed:
        armed=False
        armed_at=None
        msg='GS NullOut disabled. Automatic shutdown is OFF.'
        return
    print(purple_gs('\nGS NullOut is currently INACTIVE.'))
    print('Enabling it will attempt to power off the ENTIRE computer after 60 seconds')
    print('of system-wide mouse/keyboard inactivity (not a secure memory wipe).')
    if TEST: print('TEST MODE is on: countdown only, no actual shutdown.')
    if not ask('Enable GS NullOut now?'):
        msg='GS NullOut remains INACTIVE.'
        return
    try:
        new_idle=X11Idle()
        new_idle.seconds()  # Verify detection really works before saying ACTIVE.
        idle=new_idle
        armed_at=time.monotonic()
        armed=True
        idle_error=None
        msg='GS NullOut ENABLED. Choose [2] to disable.'
    except Exception as exc:
        idle=None
        armed=False
        armed_at=None
        idle_error=str(exc)
        msg='GS NullOut could not be enabled: '+idle_error


def explained_menu(title, purpose, notes, entries, handlers):
    """Concise action-first menu; detailed help appears on actual selection."""
    content = ['PURPOSE', '  '+purpose, '', 'AVAILABLE ACTIONS']
    briefs={}
    for key, heading, explanation, briefing in entries:
        content.append(f'[{key}] {heading}')
        briefs[key]=(heading, explanation+' '+briefing)
    content += ['', '[0] Back to Main Menu', '']
    if notes:
        # One contextual note on the menu; remaining safety details are shown
        # immediately before actions in addition to specific confirmations.
        content.extend(_wrap_lines('! '+notes[0].lstrip('! '), '  '))
    persistent_menu(title,content,handlers,briefs)

def _wrap_lines(text, indentation):
    # Respect narrower terminal windows; don't wrap option numbers or headings.
    columns = max(48, min(shutil.get_terminal_size((82, 24)).columns, 100))
    return textwrap.wrap(text, width=max(38, columns - len(indentation) - 3),
                         initial_indent=indentation, subsequent_indent=indentation,
                         break_long_words=False, break_on_hyphens=False) or [indentation]


MENU_HINTS = {
    'getting started': 'Learn how to navigate and launch the toolkit.',
    'ghost privacy controls': 'Understand BlackOut, NullOut, and device controls.',
    'network & scanning basics': 'Learn safe discovery and network inspection basics.',
    'why true privacy is difficult': 'Understand the limits of software privacy controls.',
    'safety & troubleshooting': 'Review cautions and common problems.',
    'persistence & privacy awareness': 'Understand startup entries and privacy traces.',
    'guided workflow by feature': 'Step-by-step instructions for using each category safely.',
    'toolkit diagnostics (read-only)': 'Check available commands and toolkit health without making changes.',
    'toolkit diagnostics': 'Check core requirements and optional utilities; read-only and no installations.',
    'activate gs blackout': 'Save existing settings and attempt the privacy shutdown controls.',
    'undo gs blackout / turn everything back on': 'Attempt to restore the settings recorded before BlackOut.',
}

WORKFLOW_TIPS = {
    'GS BLACKOUT': (
        'Save your work and open the toolkit on the computer itself, not over SSH.',
        'Check [3] for current hardware states and [4] for recorded initial settings.',
        'Select [1] and confirm to attempt Wi-Fi, Bluetooth, WWAN and managed networking shutdown.',
        'BlackOut also attempts mic/speaker software mute, supported webcam-driver control, stopping known remote/print/discovery services and UFW firewall restrictions.',
        'Not every control is installed or supported; read each success/failure line.',
        'Select [2] to undo supported changes from recorded settings; [3] verifies results.',
        'A software switch is not a physical kill switch; BlackOut does not erase logs, browser traces, RAM, files or guarantee anonymity.',
    ),
    'GS BUGOUT': ('Read each shutdown stage and save open work first.', 'Run Preview to check which apps, caches and USB mounts are eligible.', 'Type BUGOUT to activate; press Ctrl+C during the 3-second countdown to cancel.', 'After the countdown cleanup cannot be undone; systemd then requests poweroff.'),
    'GS NULLOUT': ('Start with test mode so no shutdown occurs.', 'Verify that idle detection resets when you move the mouse.', 'Save your files before enabling normal mode.', 'An automatic shutdown is not secure memory erasure.'),
    'GS THREAT ANALYSIS': ('Start with the complete read-only review.', 'Inspect listening ports and active connections for context.', 'Interpret the rating as a lead for investigation, not evidence of malware.', 'Use device and firewall status to verify each recommendation.'),
    'GS NETWORK INTELLIGENCE': ('Identify your active network interface.', 'Read addresses, routes and DNS settings.', 'Compare findings before changing anything.', 'Unexpected devices or routes should be investigated, not assumed malicious.'),
    'BUILT-IN LINUX NETWORK TOOLS': ('Start with interfaces and local IP addresses.', 'Review gateway and DNS settings.', 'Use neighbor cache for already-seen LAN devices.', 'Listening-port commands show this machine, not the whole network.'),
    'WIRELESS & LAN DISCOVERY': ('Verify you have permission to inspect the network.', 'Start with passive Wi-Fi or local neighbor information.', 'Choose a single authorized host for active checks.', 'Wireless strength is not a reliable distance measurement.'),
    'MAC ADDRESS INSPECTOR': ('Compare active and permanent MAC addresses if supported.', 'Examine neighbor-cache entries for known LAN devices.', 'Review wireless BSSIDs separately from your own adapter MAC.', 'These tools inspect addresses; they do not spoof or change them.'),
    'HELP & ABOUT': ('Read Getting Started first.', 'Choose the relevant privacy or networking guide.', 'Run Diagnostics if features report missing commands.', 'Use 0 to return without changing settings.'),
}

def submenu_guide(title, options, briefs=None):
    """Read-only guided explanation available from every primary submenu."""
    tips = WORKFLOW_TIPS.get(title.upper(), (
        'Read the gray description beneath each menu selection.',
        'Start with a read-only status or information option when available.',
        'Review warnings and required permissions before changing settings.',
        'After making a change, inspect its result; an error is not success.',
    ))
    output = ['\n  ' + paint('GUIDED WALKTHROUGH — ' + title.upper(), PURPLE),
              '  ' + paint('This page is informational. No commands run here.', DIM), '']
    for n, tip in enumerate(tips, 1):
        output.extend(paint(line, DIM) for line in _wrap_lines(f'Step {n}: {tip}', '  '))
    output += ['', '  ' + paint('AVAILABLE SELECTIONS', PURPLE)]
    details = {k: v[1] for k, v in (briefs or {}).items()}
    for raw in options:
        m = re.match(r'^\s*\[(\d+)\]\s+(.+)$', str(raw))
        if not m or m.group(1) == '0':
            continue
        key, heading = m.groups()
        output.append('  ' + paint(f'[{key}] {heading}', WHITE))
        descr = details.get(key, MENU_HINTS.get(heading.lower(),
             'Read the description on the menu and inspect the results carefully.'))
        output.extend(paint(line, DIM) for line in _wrap_lines(descr, '      '))
    output += ['', '  ' + paint('Enter redraws the menu. 0 returns. ESC goes home.', DIM)]
    return '\n'.join(output)


def persistent_menu(title, options, handlers, briefs=None):
    """Show a submenu once, then provide a clean navigation prompt after actions.

    Enter redraws the submenu; choosing another number runs that action directly.
    A 500ms read loop preserves GS NullOut checks during interactive navigation.
    """
    # Place concise explanations directly below every numbered submenu action.
    # A briefing shown AFTER selection is useful, but not a substitute for
    # visible descriptions while deciding what to select.
    described = []
    descriptions = {k: v[1] for k, v in (briefs or {}).items()}
    for raw in options:
        described.append(raw)
        match = re.match(r'^\s*\[(\d+)\]\s+(.+)$', str(raw))
        if not match:
            continue
        key, heading = match.groups()
        if key == '0':
            note_text = 'Return to the previous menu without running an action.'
        elif key in descriptions:
            note_text = descriptions[key]
        else:
            note_text = MENU_HINTS.get(heading.strip().lower(), 'Open this tool to inspect its current status or review its available actions.')
        note_text = re.split(r'(?<=[.!?])\s+', note_text.strip(), maxsplit=1)[0]
        if len(note_text) > 122:
            note_text = note_text[:119].rsplit(' ', 1)[0] + '...'
        described.extend(_wrap_lines(note_text, '      '))
    described += ['', '?  Guided Walkthrough — steps, meanings and safety notes']
    first = True
    while True:
        if first:
            choice = menu_sub(title, described, clear=True)
            first = False
        else:
            print(paint('\n  ── WHAT NEXT? ' + '─' * 35, DIM))
            print('  [Enter] Redraw menu   [?] Walkthrough   [0] Back')
            print(paint('  Type an option number to run another action.', DIM))
            sys.stdout.write(paint('  ghost@strategist', PURPLE) + '  ›  ')
            sys.stdout.flush()
            try:
                choice = gs_keys.read_line('', watchdog=remaining).strip()
            except EOFError:
                return
            if choice == '':
                first = True
                continue
        if choice is None or choice == '0':
            return
        if choice in ('?', 'help'):
            print(submenu_guide(title, options, briefs))
            continue
        fn = handlers.get(choice)
        if fn is None:
            print(paint('\n  Unknown option. Press Enter to see the available numbers.', RED))
        else:
            if briefs and choice in briefs:
                name, explanation = briefs[choice]
                print(paint('\n  ── ' + name.upper() + ' ──', PURPLE))
                for line in _wrap_lines('! ' + explanation, '  '):
                    print(paint(line, DIM))
                print(paint('  ' + '─' * 48, DIM))
            try:
                result = fn()
                if result: note(str(result))
            except gs_keys.HomeRequested:
                raise
            except (KeyboardInterrupt, EOFError):
                print('\n  Action cancelled; submenu remains open.')
            except Exception as exc:
                print('  Action failed:', exc)
            finally:
                restore_terminal()


def diagnostics_from_home():
    """Keep direct-access results on screen until the reader is finished."""
    diagnostics.run()
    wait_for_continue()


def sub_blackout():
    """Brief, professional action menu with a complete on-demand walkthrough."""
    content = [
        'PURPOSE',
        '  One controlled privacy lockdown, with a recorded return path.',
        '  No settings change simply by opening this menu.',
        '',
        'WHAT CHANGES',
        '  CONNECTIONS   Wi-Fi, Bluetooth, managed networking, WWAN.',
        '  PERIPHERALS   Default mic/speakers muted; supported webcam blocked.',
        '  SERVICES      SSH/Samba, Avahi/CUPS, and their activation sockets.',
        '  FIREWALL      Tagged UFW deny rule where supported; existing exceptions vary.',
        '',
        'HOW UNDO WORKS',
        '  Only reverses changes from the recorded GS BlackOut session.',
        '  Previously disabled features remain disabled.',
        '  Each operation is verified when Linux exposes its current state.',
        '  Some steps need sudo or manual intervention; unknown is not OFF.',
        '',
        'BEFORE ACTIVATING',
        '  Save work and use a local terminal; remote access may be lost.',
        '  This is not a physical kill switch, secure wipe or anonymity mode.',
        '  Use [3] to verify what is actually disabled; [?] explains limitations.',
        '',
        'AVAILABLE ACTIONS',
        '[1] Activate GS BlackOut',
        '[2] Turn It All On (Undo GS BlackOut)',
        '[3] Verify BlackOut Status (Read-Only)',
        '[4] Review GS BlackOut Backup (Read-Only)',
        '[0] Back to Main Menu',
    ]
    briefs = {
        '1': ('Activate GS BlackOut',
              'Records supported settings and attempts wireless, networking, audio, camera, service and UFW restrictions; confirmation required.'),
        '2': ('Turn It All On (Undo GS BlackOut)',
              'Restores ONLY BlackOut-recorded network, radio, audio, camera, service and firewall changes; verify results afterward.'),
        '3': ('Verify BlackOut Status',
              'Inspect actual radio, network, audio, camera, service/socket and firewall states. Read-only; may report unknown controls.'),
        '4': ('Review GS BlackOut Backup',
              'Show the saved BlackOut activation values and identify which protections existed before BlackOut.'),
    }
    persistent_menu('GS BLACKOUT', content,
                    {'1': blackout_apply, '2': restore_all,
                     '3': blackout_status, '4': show_blackout_record}, briefs)


def sub_bugout():
    """Full BugOut only, with stage-by-stage explanations before activation."""
    content = [
        '  Full session exit with cleanup followed by shutdown.',
        '  MANUAL ONLY — does nothing just by opening this menu.',
        '',
        'SEQUENCE — WHAT HAPPENS WHEN ACTIVATED',
        '  1. Gracefully close recognized non-system applications and',
        '     selected user-owned background sync services.',
        '     Linux system/desktop tasks are NOT mass-killed.',
        '  2. Delete only GS BugOut-owned temporary /tmp files.',
        '     Other /tmp files, documents and logs are preserved.',
        '  3. Clear supported thumbnail, font, shader and browser',
        '     content caches; keep browser profiles, history, cookies.',
        '  4. Clear clipboard using an already-installed utility.',
        '  5. Disable NetworkManager networking, Wi-Fi, Bluetooth and',
        '     other software radios (where tools are available).',
        '  6. Attempt safe unmount of removable USB devices, but not',
        '     the toolkit drive. Busy/unsupported drives are skipped.',
        '  7. Allow systemd to stop remaining sessions and services.',
        '  8. Request a normal FULL SYSTEM SHUTDOWN at the end.',
        '',
        'ACTIVATION AND SAFETY',
        '  Save work first. Type BUGOUT to confirm destructive changes.',
        '  3-second countdown: press Ctrl+C to cancel before changes.',
        '  No undo after cleanup starts; deleted caches cannot return.',
        '  A failed shutdown can leave changes on a running system.',
        '  Radios may stay off after restarting. Use local terminal.',
        '  No new packages; unavailable tools are reported and skipped.',
        '  NOT a secure wipe, memory erase or anonymity guarantee.',
        '',
        'ACTIONS',
        '[1] Activate Full GS BugOut',
        '[2] Preview GS BugOut (Read-Only)',
        '[0] Back to Main Menu',
    ]
    briefs = {
        '1': ('Activate Full GS BugOut', 'Explicit BUGOUT confirmation, 3-second '
              'cancelable countdown, then graceful user-app exit, restricted '
              'temporary/cache cleanup, clipboard/network/USB controls and '
              'final systemd poweroff. Unsaved data may be lost.'),
        '2': ('Preview GS BugOut (Read-Only)', 'Preview eligible user applications, '
              'cache folders, supported networking controls and removable '
              'USB mounts. No files, tasks or system settings change.'),
    }
    def activate():
        if armed:
            return 'Disable GS NullOut [2] first to prevent competing automatic shutdowns.'
        result = cmd_run([sys.executable, str(BASE/'gs_bugout.py'), '--execute'])
        if TEST: return 'GS BugOut TEST MODE: preview only; no cleanup or shutdown.'
        if result == 10: return 'GS BugOut cancelled. Nothing changed.'
        if result == 130: return 'GS BugOut interrupted; read the preceding stage results.'
        if result == 0: return 'Shutdown request accepted. If still running, inspect poweroff status.'
        return f'GS BugOut incomplete (exit {result}). Any previous steps may persist.'
    persistent_menu('GS BUGOUT', content, {
        '1': activate,
        '2': lambda: run_python('gs_bugout.py', '--preview')
    }, briefs)


def sub_nullout():
    def null_enable():
        if gs_platform.session() == 'wayland':
            return 'GS NullOut unavailable on Wayland: X11 system-wide idle monitoring is required. Nothing was armed.'
        if armed: return 'GS NullOut is already active.'
        toggle_nullout()
        return msg
    def null_disable():
        if not armed: return 'GS NullOut is already inactive.'
        toggle_nullout()
        return msg
    def null_status():
        if armed:
            return f'GS NullOut ACTIVE: approximately {remaining()} seconds left. Test mode: {TEST}.'
        return 'GS NullOut INACTIVE: no automatic shutdown is armed.'
    explained_menu('GS NULLOUT',
        'An optional 60-second system-wide inactivity timer. When armed, it '
        'requests shutdown of the whole computer after 60 seconds without input.',
        ['OFF by default; does not securely wipe RAM or storage.',
         'Requires Linux X11 idle detection. Test safely with GHOSTSTRAT_TEST_MODE=1 bash gs.sh.'], [
        ('1', 'Enable 60-Second Shutdown',
         'Start watching system-wide idle time after an explicit confirmation.',
         'Validates X11 idle detection before arming. In normal mode, reaching '
         '60 seconds requests systemctl poweroff; save your work first.'),
        ('2', 'Disable GS NullOut',
         'Stop the timer so it will not request a shutdown.',
         'Disarms the timer within the running toolkit.'),
        ('3', 'Check Timer Status',
         'Show whether the feature is armed and the current time remaining.',
         'Read-only status; TEST MODE never requests shutdown.'),
    ], {'1': null_enable, '2': null_disable, '3': null_status})


def sub_restore():
    explained_menu('TURN IT ALL ON — GS BLACKOUT ONLY',
        'Undo only the changes applied by GS BlackOut using its activation-time backup.',
        ['Not a factory reset or a restore for GS BugOut, DHCP identity, or other tools.',
         'No BlackOut backup means no changes. Previously disabled devices stay disabled.',
         'Wi-Fi, firewall and remote services may reconnect. Use a local terminal and confirm.'], [
        ('1', 'Inspect BlackOut Backup',
         'Read saved device/radio states and see which lockdown backups belong to BlackOut.',
         'Read-only. A backup is created only after you choose Activate GS BlackOut.'),
        ('2', 'Turn It All On — Undo BlackOut',
         'Reverse only saved GS BlackOut changes to networking, devices, services and firewall.',
         'Requires confirmation; verify every reported result. Partial failures retain the backup.'),
    ], {'1': show_blackout_record, '2': restore_all})


def sub_radios():
    explained_menu('WI-FI & BLUETOOTH',
        'Manage wireless radios independently. Nothing changes until you choose an action.',
        ['Changing Wi-Fi may disconnect you. Bluetooth settings do not isolate hardware physically.'], [
        ('1','Check Radio Status','Review current wireless and Bluetooth states.','Read-only.'),
        ('2','Disable Wi-Fi','Request Wi-Fi radio OFF.','May disconnect the current network.'),
        ('3','Enable Wi-Fi','Request Wi-Fi radio ON.','A connection may need to be re-established.'),
        ('4','Disable Bluetooth','Request a Bluetooth soft block or power off.','Devices may disconnect.'),
        ('5','Enable Bluetooth','Request radio unblock and controller power on.','May not reconnect paired devices automatically.'),
    ], {'1':info_status,'2':lambda:dev_do('wifi','off'),'3':lambda:dev_do('wifi','on'),
        '4':lambda:dev_do('bluetooth','off'),'5':lambda:dev_do('bluetooth','on')})


def sub_peripherals():
    explained_menu('MICROPHONE / CAMERA / AUDIO',
        'Privacy controls for default microphone, speakers, and supported webcams.',
        ['Software mute is not hardware isolation; camera driver support varies.'], [
        ('1','View Device Status','Check detected audio and camera driver states.','Read-only.'),
        ('2','Mute Microphone','Mute the default recording source.','Other microphones can be separate.'),
        ('3','Unmute Microphone','Restore recording from the default source.','Software only.'),
        ('4','Disable Camera','Attempt uvcvideo webcam driver unload.','Requires support/permissions.'),
        ('5','Enable Camera','Attempt to reload the uvcvideo driver.','May require administrator rights.'),
        ('6','Mute Speakers','Mute the default output sink.','Software only.'),
        ('7','Unmute Speakers','Unmute the default output sink.','Software only.'),
    ], {'1':info_status,'2':lambda:dev_do('microphone','off'),
        '3':lambda:dev_do('microphone','on'), '4':lambda:dev_do('camera','off'),
        '5':lambda:dev_do('camera','on'),'6':lambda:dev_do('speakers','off'),
        '7':lambda:dev_do('speakers','on')})


def sub_overview():
    explained_menu('SYSTEM & DEVICE OVERVIEW',
        'A single entry point for machine identity, peripheral status and compatibility.',
        ['Status checks are read-only; unsupported controls report limited visibility.'], [
        ('1','System Information','Kernel, logged-in user, uptime and available memory.','Read-only.'),
        ('2','Privacy Device Status','Wi-Fi, Bluetooth, audio and supported camera driver states.','Read-only.'),
        ('3','Network Interfaces','List local adapters and addresses.','Read-only.'),
        ('4','Toolkit Diagnostics','Check required commands and supported environments.','Read-only.'),
    ], {'1':print_sys,'2':info_status,'3':network_status,'4':diagnostics.run})

def sub_network():
    explained_menu('NETWORK ADAPTERS',
        'Inspect interfaces, inspect NetworkManager connections, or request a new local DHCP lease.',
        ['! IP Changer can briefly disconnect this computer. Do not run it in a remote SSH session.',
         '! DHCP may give you the same local IP; public IP changes are not guaranteed.'], [
        ('1', 'List Interfaces and IP Addresses',
         'See interface names, adapter status and local IP addresses.',
         'Read-only; does not contact other devices.'),
        ('2', 'Show Connection Status',
         'Show NetworkManager connected and disconnected devices.',
         'Read-only status via nmcli.'),
        ('3', 'Renew Current DHCP Lease',
         'Ask the router for a lease and compare the old/new local IPv4 addresses.',
         'May return the same IP; explicit confirmation required.'),
        ('4', 'Request Different Local IP (Alternate DHCP Identity)',
         'Try a different DHCP client identity, then verify the assigned address.',
         'This can disrupt network rules and still does not guarantee a new IP. Original profile setting is backed up.'),
        ('5', 'Restore Original DHCP Identity',
         'Reapply the previous DHCP profile setting and reconnect.',
         'Use this after option [4]. Does not guarantee the previous local address.'),
    ], {'1':network_status,
        '2':lambda: 'NetworkManager status displayed.' if cmd_run(['nmcli','device','status']) == 0 else '! NetworkManager unavailable.',
        '3':lambda:ip_changer.refresh(input_fn=lambda prompt:gs_keys.read_line(prompt,watchdog=remaining)),
        '4':lambda:ip_changer.request_different(input_fn=lambda prompt:gs_keys.read_line(prompt,watchdog=remaining)),
        '5':lambda:ip_changer.restore_identity(input_fn=lambda prompt:gs_keys.read_line(prompt,watchdog=remaining))})


def sub_network_intelligence():
    explained_menu('GS NETWORK INTELLIGENCE',
        'Read comprehensive local network details without probing nearby devices or contacting the internet.',
        ['! Sensitive addresses, routes and adapter details may appear. Avoid sharing unredacted reports.',
         '! Missing tools or root-only sections are labeled rather than guessed.'], [
        ('1', 'Full Local Network Readout', 'Run every available read-only diagnostic category.', 'Includes addresses, routes, DNS, neighbors, ports, Wi-Fi, adapters and traffic.'),
        ('2', 'Interfaces and IP Addresses', 'Read interface and connection facts.', 'Read-only.'),
        ('3', 'Routes, Gateways and Neighbors', 'Inspect local routing and ARP/ND caches.', 'Does not scan the LAN.'),
        ('4', 'DNS and DHCP', 'Inspect resolver and NetworkManager details.', 'Read-only.'),
        ('5', 'Sockets and Listening Ports', 'Inspect available TCP and UDP connections.', 'Read-only.'),
        ('6', 'Hardware, VPN and Traffic', 'Inspect radio and virtual-interface status.', 'Read-only.'),
        ('7', 'Firewall and Local Security', 'Check accessible firewall and link status.', 'Some details need admin authorization.'),
    ], {'1':lambda:network_intelligence.show_section(),
        '2':lambda:network_intelligence.show_section('1'),
        '3':lambda:network_intelligence.show_section('2'),
        '4':lambda:network_intelligence.show_section('3'),
        '5':lambda:network_intelligence.show_section('4'),
        '6':lambda:network_intelligence.show_section('5'),
        '7':lambda:network_intelligence.show_section('6')})


def sub_mac():
    explained_menu('MAC ADDRESS INSPECTOR',
        'Read-only tools for inspecting local network hardware and known MAC addresses.',
        ['No MAC spoofing, address changes, disconnects, or new software.',
         'Neighbor cache is limited to hosts this computer has recently communicated with.',
         'MAC addresses do not expose your public IP; locally administered addresses can be randomized.'], [
        ('1', 'Current Interface MAC Addresses',
         'List local adapters, MAC addresses, and connection state.',
         'Reads Linux sysfs; no changes to any network configuration.'),
        ('2', 'Permanent Hardware MAC Addresses',
         'Compare current and permanent addresses, where the kernel exposes both.',
         'Uses existing ethtool only if installed; unavailable values are clearly labeled.'),
        ('3', 'Known Neighbor MAC Addresses',
         'Show MAC addresses in the existing ARP/IPv6 neighbor cache.',
         'Uses ip neigh without scanning or contacting other devices.'),
        ('4', 'Interface Statistics',
         'Show adapter link details and received/transmitted byte counters.',
         'Reads ip -s link and available kernel counters.'),
        ('5', 'Wi-Fi Access Point BSSIDs',
         'View known nearby Wi-Fi access point MAC addresses and signal information.',
         'Uses NetworkManager if present; may trigger an ordinary Wi-Fi scan.'),
        ('6', 'NetworkManager Device Details',
         'View NetworkManager adapter properties, including hardware identifiers.',
         'Reads the currently reported device details only.'),
    ], {str(i): (lambda n=i: ('Wi-Fi access-point scanning is disabled in Tails restricted mode.'
                               if TAILS_SAFE and i == 5 else mac_do(str(n)))) for i in range(1,7)})


def sub_task():
    explained_menu('TASK MANAGER',
        'See running programs and processes and how much CPU or memory they use.',
        ['Monitoring is read-only here. Processes running as other users may show limited details.'], [
        ('1', 'Open Live Process Viewer',
         'Show a continuously updating process list, CPU and memory information.',
         'Uses the built-in read-only process viewer. Press 0 or Q (no Enter needed) to return. Press R to refresh.'),
        ('2', 'Show Process Snapshot',
         'List processes sorted by CPU use at a single moment.',
         'Runs ps with PID, user, state, CPU, memory and command columns; read only.'),
    ], {'1': task_view, '2': task_manager.snapshot})


def remote_recovery_state():
    """Read only; never conflate a pending snapshot with successful protection."""
    state_root = Path(os.getenv('XDG_STATE_HOME', str(Path.home() / '.local/state'))) / 'ghost-strategist-tool'
    remote_backup = state_root / 'remote-lockdown-state.tsv'
    blackout_backup = state_root / 'blackout-session-v66.tsv'
    if remote_backup.exists():
        if blackout_backup.exists():
            return ('BACKUP PENDING — This may belong to GS BlackOut. '
                    'Use [19] Turn It All On if BlackOut created it; do not overwrite it.')
        return ('BACKUP PENDING — A previous Remote Access Lockdown can be restored '
                'with [3]. Applying again is blocked until recovery is completed.')
    return 'NO PENDING BACKUP — A new lockdown can save your current settings.'


def sub_remote():
    """Direct, action-first submenu without duplicate banners or warnings."""
    options = [
        'CURRENT RECOVERY STATE',
        '  ' + remote_recovery_state(),
        '',
        'WHAT WOULD YOU LIKE TO DO?',
        '[1] View Remote Access Status',
        '[2] Apply Remote Access Lockdown',
        '[3] Restore Previous Remote Settings',
        '[4] Technical Details',
        '',
        '[0] Back to Main Menu',
        '',
        '! Local terminal recommended. Applying changes can disconnect remote sessions.',
    ]
    briefs = {
        '1': ('View Remote Access Status',
              'Read only: summarize recognized services, firewall state and whether a recovery backup blocks new activation.'),
        '2': ('Apply Remote Access Lockdown',
              'Save the prior state, then attempt to stop recognized remote services and apply UFW incoming deny. Existing allow rules may still work.'),
        '3': ('Restore Previous Remote Settings',
              'Restore saved services and firewall state from an earlier standalone remote lockdown. No backup means no changes.'),
        '4': ('Technical Details',
              'Read only: list recognized system/user services, TCP listening sockets, and UFW information.'),
    }
    persistent_menu('REMOTE ACCESS LOCKDOWN', options, {
        '1': lambda: remote_do('status'),
        '2': lambda: remote_do('apply'),
        '3': lambda: remote_do('restore'),
        '4': lambda: remote_do('details'),
    }, briefs)


NETWORK_SHORTCUTS = (
    ('1','Show IP Addresses','ip -brief address','View local network interface names and assigned IP addresses.'),
    ('2','Show Network Interfaces','ip link show','View interfaces, MAC addresses and link status.'),
    ('3','Show Routes and Gateway','ip route show','Show IPv4 routes and your default gateway.'),
    ('4','Known LAN Neighbors','ip neigh show','Display neighbors already learned by the computer; does NOT scan an entire LAN.'),
    ('5','Listening Ports','ss -tuln','List local TCP/UDP listening ports.'),
    ('6','Active Connections','ss -tunap','Show connections and process information when accessible.'),
    ('7','Wi-Fi Access Points','nmcli -f IN-USE,SSID,BSSID,CHAN,FREQ,SIGNAL,SECURITY device wifi list','List visible Wi-Fi access points when NetworkManager and a Wi-Fi adapter are available.'),
    ('8','Network Adapters','nmcli device status','Show managed interfaces and connectivity states.'),
    ('9','Saved Connection Profiles','nmcli connection show','List saved NetworkManager profiles; does not show stored passwords.'),
    ('10','Network DNS Settings','nmcli device show','Show per-device DNS, gateways and connection details.'),
    ('11','Local IP Summary','hostname -I','Show assigned host IP addresses.'),
    ('12','Resolve Domain Name','getent ahosts example.com','Resolve the example.com hostname using system name services.'),
    ('13','Check Local Gateway','ip route get 1.1.1.1','Show the route Linux would select; no network packets are sent.'),
    ('14','Interface Traffic Counters','cat /proc/net/dev','Show kernel counters for network interfaces.'),
    ('15','Radio Block Status','rfkill list','Show whether supported wireless radios are software/hardware blocked.'),
    ('16','Network Manager Radio Status','nmcli radio all','Read Wi-Fi and mobile broadband radio state.'),
    ('17','IPv6 Addresses','ip -6 address show','Show IPv6 addresses on local interfaces.'),
    ('18','IPv6 Routes','ip -6 route show','Show IPv6 routes known to the system.'),
    ('19','Kernel Network Statistics','cat /proc/net/snmp','Show kernel IPv4/TCP/UDP statistics counters.'),
)

def _run_network_shortcut(arguments):
    import shlex
    argv=shlex.split(arguments)
    if not shutil.which(argv[0]):
        print('Unavailable: '+argv[0]+' is not installed. No package is installed by this toolkit.')
        return
    print('\nRunning: '+arguments+'\n')
    try:
        result=subprocess.run(argv, timeout=25, check=False)
        if result.returncode:
            print('Command returned exit code '+str(result.returncode))
    except (OSError, subprocess.TimeoutExpired) as exc:
        print('Command could not complete: '+str(exc))
    finally:
        restore_terminal()

def sub_network_shortcuts():
    entries=[(key,title,detail,'Read-only. Command: '+command) for key,title,command,detail in NETWORK_SHORTCUTS]
    handlers={key:(lambda command=command:_run_network_shortcut(command)) for key,_,command,_ in NETWORK_SHORTCUTS}
    explained_menu('BUILT-IN LINUX NETWORK TOOLS',
        'Read-only terminal shortcuts for utilities available on many Linux Mint systems; no Nmap or extra packages.',
        ['! These are status and discovery shortcuts, not a complete network scanner. Missing commands are skipped; nothing is installed.'],
        entries,handlers)


def launch_drone_detector():
    """Launch drone-only Turbo and return directly to the toolkit on Esc.

    The child consumes Esc and restores its terminal mode before exiting.
    No separate drone submenu is displayed and no scanning continues in the
    background after the scanner has stopped.
    """
    detector = BASE / 'gs-drone-detector.sh'
    if not detector.is_file():
        return 'GS Drone Detector missing. Extract the complete toolkit again.'
    if not shutil.which('bash'):
        return 'Bash is missing; GS Drone Detector cannot start.'
    try:
        result = subprocess.run(['bash', str(detector), 'scan'], cwd=str(BASE), check=False)
    except KeyboardInterrupt:
        return 'Turbo scan interrupted. Returned to main menu.'
    except OSError as exc:
        return 'GS Drone Detector could not start: ' + str(exc)
    finally:
        restore_terminal()
    if result.returncode not in (0, 130):
        return f'GS Drone Detector exited with status {result.returncode}.'
    return 'Turbo scan stopped. Returned to Ghost Strategist main menu.'


def sub_scanning():
    explained_menu('WIRELESS & LAN DISCOVERY',
        'Explore wireless broadcasts and perform bounded local/LAN checks. No report files.',
        ['Only scan devices and networks you own or have authorization to assess.'], [
        ('1','Nearby Wi-Fi Networks','Inspect advertised networks and signal quality.','May optionally enable Wi-Fi with confirmation.'),
        ('2','Nearby Bluetooth Devices','Discover local Bluetooth advertisements.','May optionally enable Bluetooth with confirmation.'),
        ('3','Network Neighbor Cache','List devices your machine has previously discovered.','Not a full network scan.'),
        ('4','Check Local TCP Ports','Connect-test common ports on 127.0.0.1.','No external targets.'),
        ('5','Scan Authorized LAN Host','Connect-test common ports on one private IPv4 address.','Requires permission confirmation.'),
        ('6','Watch Traffic Counters','Sample local adapter data transfer rates.','No packet contents captured.'),
    ], {'1':scanning.wifi_scan,'2':scanning.bluetooth_scan,
        '3':scanning.neighbors,'4':scanning.tcp_scan,
        '5':scanning.lan_scan,'6':scanning.monitor})


def run_threat_report():
    print('\nGS Threat Analysis — read-only local security review')
    print('No firewall, hardware, network, service, or package settings will be changed.')
    return run_python('threat-analysis.py')


def sub_threat():
    explained_menu('GS THREAT ANALYSIS',
        'Run a read-only educational review of local network exposure, firewall, '
        'remote-access processes, radios, audio mute, camera nodes and connections. '
        'Read explanations, recommended actions and a final exposure rating.',
        ['A listening port is not proof of a vulnerability or internet exposure.',
         'This is NOT a virus scanner. It cannot detect all malware, compromised accounts, '         'misconfigurations or privacy leaks; UNKNOWN checks remain UNKNOWN.',
         'The score is a simple prioritization heuristic, not a validated security score.'], [
        ('1','Run Complete Threat Review',
         'Review system information and display possible exposure findings with next steps.',
         'Runs read-only local commands (ss, ufw, ps, nmcli, rfkill, pactl, ip) when available. '
         'No external hosts are scanned and nothing is repaired automatically.'),
        ('2','Understand Threat Rating',
         'Explain how the LOW, MODERATE, ELEVATED and HIGH exposure categories are calculated.',
         'Shows the scoring formula and limitations; no settings are changed.'),
        ('3','Listening Ports and Exposure',
         'See each visible TCP/UDP listener, bound address and whether it listens beyond localhost.',
         'This does not scan the internet or prove a port is accessible externally.'),
        ('4','Active TCP Connections',
         'Review established outbound and inbound TCP connections visible on this machine.',
         'Connections are not automatically malicious; displayed remote addresses can be sensitive.'),
        ('5','Privacy and Device Status',
         'Inspect wireless radio blocks, microphone/speaker mute, camera device nodes and configured DNS.',
         'Reports UNKNOWN when tools are missing; software controls are not physical kill switches.'),
    ], {'1':run_threat_report,
        '2':lambda:run_python('threat-analysis.py','--explain'),
        '3':lambda:run_python('threat-analysis.py','--ports'),
        '4':lambda:run_python('threat-analysis.py','--connections'),
        '5':lambda:run_python('threat-analysis.py','--privacy')})


def fw_action(mode):
    return run_python('firewall-controls.py', mode)


def fw_enable():
    print('\nUFW ENABLE: activates your EXISTING firewall configuration, including existing allow rules.')
    print('This does NOT guarantee all incoming ports are blocked. Remote access may be interrupted.')
    if not ask('Enable UFW firewall now?'): return 'Cancelled. No changes made.'
    return fw_action('enable')


def fw_disable():
    print('\nWARNING: Disabling UFW removes UFW firewall enforcement.')
    print('This may expose network services to accessible networks. It is NOT a safety improvement.')
    if not ask('Disable UFW now?'): return 'Cancelled. No changes made.'
    return fw_action('disable')


def sub_firewall():
    explained_menu('FIREWALL & PORT SECURITY',
        'Inspect ports and UFW policies or apply explicit, reversible firewall changes.',
        ['Changing firewall rules can disconnect remote users. Use the local console.'], [
        ('1','Firewall Status','Check UFW enforcement.','Read-only; may request authorization if needed.'),
        ('2','Listening Ports','Inspect currently listening local TCP/UDP services.','Read-only; local sockets are not necessarily public.'),
        ('3','Detailed Rules','Show verbose firewall policies and rules.','Read-only.'),
        ('4','Enable UFW','Enable the existing firewall configuration.','Existing allow rules remain; confirmation required.'),
        ('5','Block Common Remote Ports','Apply tagged incoming restrictions for common remote ports.','Review services before applying.'),
        ('6','Block New Incoming Traffic','Apply GS-managed inbound restrictions.','May interfere with sharing and remote access.'),
        ('7','Restore GS Port Rules','Remove previously recorded GS-managed rules.','Leaves unrelated UFW settings alone.'),
        ('8','Disable UFW (Advanced)','Turn off UFW enforcement.','Potentially exposes services; requires confirmation.'),
    ], {'1':lambda:fw_action('status'), '2':scanning.listening,
        '3':lambda:fw_action('verbose'),'4':fw_enable,
        '5':lambda:port_do('apply-common'),'6':lambda:port_do('apply-all'),
        '7':lambda:port_do('restore'),'8':fw_disable})


def sub_persistence():
    explained_menu('PERSISTENCE & PRIVACY',
        'Explore what may start automatically, continue running or leave local '
        'privacy traces. Review common Linux persistence mechanisms without changing them.',
        ['All inspection options are read-only. No services or files are removed.',
         'This is educational exposure review, NOT proof of malware or a complete '
         'forensic examination. Output can include private file paths.'], [
        ('1', 'Startup Applications',
         'Review desktop autostart entries for this user and the system.',
         'Lists .desktop file names and metadata from common autostart folders. '
         'No applications are started or disabled.'),
        ('2', 'Enabled Background Services',
         'List recognized systemd services enabled to start automatically.',
         'Queries systemctl for system and user services. An enabled service '
         'is not automatically suspicious or necessarily running.'),
        ('3', 'Scheduled Tasks',
         'Review cron entry counts and known systemd timers.',
         'Cron command contents are hidden to avoid displaying sensitive '
         'arguments. System timers and cron folder metadata are shown.'),
        ('4', 'Login & Persistence Hooks',
         'Check shell profiles and known user service directories.',
         'Displays file names, sizes, permissions and modification times. '
         'File contents are not opened or changed.'),
        ('5', 'Recent Configuration Changes',
         'Inspect timestamps of common startup and package-management files.',
         'A modification may be legitimate. This is not a complete system '
         'change log and cannot establish who changed a file.'),
        ('6', 'Privacy Residue',
         'See whether common history, thumbnail, recent-file and trash locations exist.',
         'Only metadata and bounded file counts are shown. No history or '
         'browser data is read, deleted or cleared.'),
    ], persistence_privacy.ACTIONS)



def _help_text(title, paragraphs):
    """Produce a readable, terminal-width guide without changing any settings."""
    out = [PURPLE + title.upper() + RESET, '']
    for paragraph in paragraphs:
        out.extend(_wrap_lines(paragraph, '  '))
        out.append('')
    return '\n'.join(out).rstrip()


def sub_help():
    """User-facing educational guide; all actions are read-only explanations."""
    lines = [
        'OVERVIEW',
        'Detected Linux system: ' + gs_platform.label(PLATFORM),
        'Desktop session: ' + gs_platform.session(),
        *(['Tails restricted mode blocks system-changing actions. This is not an anonymity guarantee.'] if TAILS_SAFE else []),
        *_wrap_lines('Ghost Strategist Tool teaches practical Linux privacy, device '
                     'controls and security inspection. It is not a separate OS and '
                     'does not guarantee anonymity.', '  '),
        '', 'HELP TOPICS',
        '[1] Getting Started',
        '[2] Ghost Privacy Controls',
        '[3] Network & Scanning Basics',
        '[4] Why True Privacy Is Difficult',
        '[5] Safety & Troubleshooting',
        '[6] Persistence & Privacy Awareness',
        '[7] Toolkit Diagnostics (Read-Only)',
        '[8] Guided Workflow by Feature',
        '', '[0] Back to Main Menu',
        '', '! Read-only information and optional actions; no tools start automatically.',
        '', RED + 'STRICTLY FOR EDUCATIONAL PURPOSES ONLY.' + RESET,
    ]
    handlers = {
        '1': lambda: _help_text('Getting Started', [
            'Run bash gs.sh as your normal user on Linux Mint, Kali, or Parrot. On Tails, '
            'a limited set of read-only tools is available. Select a numbered option and press Enter. Inside each submenu you can use '
            'multiple options; choose 0 to return to the main menu.',
            'Nothing activates at launch. GS BlackOut and GS NullOut are manual. '
            'Status and scanning views are generally read-only, while control '
            'options may change device settings or network connectivity.',
            'GhostStrats YouTube: https://www.youtube.com/@GhostStrats. '
            'Fun bonus: the main menu has hidden GhostStrats and community easter eggs. '
            'Try typing ghostsignal for clues, or safety is an illusion for a narrated-style message. '
            'Easter eggs only display text; the long message clears the terminal screen, not any files.',
            'Read each ACTION explanation before confirming a change. If an '
            'operation reports failure or UNKNOWN, do not assume it worked.'
        ]),
        '2': lambda: _help_text('Ghost Privacy Controls', [
            'GS BlackOut attempts to switch off Wi-Fi and Bluetooth, mute the '
            'default microphone and speakers, disable compatible webcams, '
            'restrict known remote-access services, and block new incoming '
            'connections through the firewall. Some steps require sudo and '
            'may not be supported on your hardware.',
            'GS NullOut is an optional 60-second system-wide inactivity '
            'shutdown. It requests a computer poweroff: it is NOT a secure '
            'memory wipe. Test its timer safely using '
            'GHOSTSTRAT_TEST_MODE=1 bash gs.sh.',
            'GS BugOut [4] performs a complete opt-in session exit and cleanup, followed by a systemd poweroff request. A 3-second countdown follows explicit confirmation.',
            'Turn It All On [19] reverses only changes saved by GS BlackOut at activation. '
            'It does not undo GS BugOut, DHCP identity or independent firewall changes. '
            'Use System & Device Overview [18] to verify results.'
        ]),
        '3': lambda: _help_text('Network & Scanning Basics', [
            'Network & IP Settings [10] show local network interfaces and '
            'IP addresses. A MAC address identifies a network adapter on '
            'a local network; it does not hide your public IP address.',
            'Port checks show listening services or whether a TCP connection '
            'succeeds. A firewall block restricts traffic; it does not '
            'necessarily stop the program listening on a port.',
            'Nearby Wi-Fi and Bluetooth scans can reveal advertised networks '
            'and devices. Signal strength is affected by obstacles, antennas '
            'and interference, so it cannot provide reliable physical distance.',
            'Network monitoring reads current counters or connections, not a '
            'complete picture of every device and communication.'
        ]),
        '4': lambda: _help_text('Why True Privacy Is Difficult', [
            'Privacy depends on multiple layers: local hardware, operating '
            'system permissions, network routing, DNS, websites, accounts, '
            'metadata, and what you voluntarily reveal.',
            'Turning off radios reduces some exposure but does not undo '
            'information already shared. MAC randomization changes a local '
            'identifier, not your online identity. Blocking incoming ports '
            'does not stop all outbound connections or every form of tracking.',
            'Ghost Strategist Tool does not route all traffic through Tor, '
            'erase stored data, or make Linux Mint an anonymous operating '
            'system. Learning what a setting actually changes is more useful '
            'than assuming a label means complete protection.'
        ]),
        '5': lambda: _help_text('Safety & Troubleshooting', [
            'Use a local terminal when changing firewall or remote-access '
            'settings; you could disconnect yourself from an SSH session. '
            'Save work before enabling GS NullOut, and try TEST MODE first.',
            'If a device control fails, check System & Device Overview [18] and inspect '
            'the printed command output. Audio mute is software-based and '
            'webcam-driver controls do not cover every camera.',
            'Only scan networks and devices you own or have explicit '
            'authorization to test. Keep an independent recovery method '
            'available, and do not treat a successful command as proof '
            'of complete privacy.'
        ]),
        '6': lambda: _help_text('Persistence & Privacy Awareness', [
            'Persistence describes techniques that make programs or settings '
            'remain active or reappear after a restart. Normal software also '
            'uses startup applications, scheduled tasks, services and login hooks.',
            'Startup & Privacy Audit [16] helps inspect common startup, service '
            'and local trace locations without saving a baseline or altering files.',
            'Local histories, thumbnail caches, recent-document records and '
            'trash may leave traces of activity. Simply disabling Wi-Fi or '
            'changing a MAC address does not remove those traces.'
        ]),
        '7': diagnostics.run,
        '8': lambda: _help_text('Practical Walkthrough by Feature', [
            'First-time setup: launch as a normal user, inspect System & Device Overview [18], then open Help [H] > [7] for read-only diagnostics.',
            'Privacy: open GS BlackOut [1] and read what will turn off. Save work and use a local terminal before activating. Turn It All On [19] only undoes its recorded changes; check the actual status.',
            'Idle protection: open GS NullOut [2], run test mode and verify idle detection before arming an actual shutdown. This is not a secure wipe.',
            'Emergency exit: open GS BugOut [4], read every step, Preview first, save work, type BUGOUT to confirm and use Ctrl+C during its 3-second countdown if you need to cancel. A completed run asks Linux to power off.',
            'Threat inspection: run GS Threat Analysis [3], then review listening ports, established connections, and the limitations of severity ratings.',
            'Network discovery: start with Built-in Network Tools [8], inspect interfaces, routes, DNS and the known neighbor cache. Scan only systems you own or have permission to test.',
            'Files: use File Explorer [9] to browse and inspect metadata or view a bounded tree. A file name or a recent modification alone does not mean malware.',
            'Troubleshooting: review command errors, check read-only status, and use Help [H] > [7] for Toolkit Diagnostics. Keep a local recovery path.'
        ]),
    }
    persistent_menu('HELP & ABOUT', lines, handlers)

def main():
    global idle, armed, msg
    if not sys.stdin.isatty():
        sys.exit('Run in an interactive terminal')
    if os.geteuid()==0:
        sys.exit('Run as a normal user, not root')
    remember_terminal()
    # Read-only, silent and unprivileged initial capture. Crucially this occurs
    # BEFORE the user can select a device / privacy control; later launches
    # preserve the first snapshot even if settings have been changed.
    if TAILS_SAFE:
        msg = ('Tails restricted mode: only [3] Threat Analysis, [5] Network Intelligence, '
               '[9] Files, [13] MAC Inspector, [16] Startup Audit, [18] System Overview '
               'and [H] Help are available. Other features are disabled.')
    else:
        startup_result = startup_settings.ensure_initial_snapshot()
        msg = 'Initial settings: ' + startup_result if startup_result.startswith('WARNING') else ''
    idle=None
    armed=False
    handlers={
        '1':sub_blackout,
        '2':sub_nullout,
        '3':sub_threat,
        '4':sub_bugout,
        '5':sub_network_intelligence,
        '7':sub_scanning,
        '8':sub_network_shortcuts,
        '9':lambda:run_python('gs_file_explorer.py'),
        '10':sub_network,
        '11':sub_radios,
        '12':sub_peripherals,
        '13':sub_mac,
        '14':sub_firewall,
        '15':sub_remote,
        '16':sub_persistence,
        '17':sub_task,
        '18':sub_overview,
        '19':sub_restore,
        '6':launch_drone_detector,
        'h':sub_help,
    }
    while True:
        restore_terminal()
        choice=menu_sub('MAIN MENU',main_menu_options(),show_nullout=True)
        if choice is None:
            return
        choice=choice.lower().strip()
        if not choice:
            continue
        choice=str(int(choice)) if choice.isdigit() else choice
        # Tails deliberately has a read-only subset. Guard at dispatch, not just menu text.
        # This is a workflow safety guard, not a sandbox against direct script execution.
        if TAILS_SAFE and choice not in gs_platform.TAILS_ALLOWED and choice not in ('0',):
            msg = ('Unavailable on Tails: this action may change radios, connectivity, '
                   'services, shutdown behavior or other settings. Restricted mode '
                   'keeps only inspection tools. Choose [H] for details.')
            continue
        handler=handlers.get(choice)
        if handler is not None:
            try:
                handler()
            except gs_keys.HomeRequested:
                msg='Returned to home menu.'
            finally:
                restore_terminal()
        elif choice == 'game':
            # Hidden, local terminal-only Snake. A collision automatically
            # returns here, then the normal main menu is drawn again.
            gs_snake.play()
        elif easter_eggs.is_manifesto_command(choice):
            easter_eggs.play_manifesto()
            wait_for_continue()
        elif easter_eggs.run(choice,out=lambda output:print(purple_gs(output))):
            wait_for_continue()
        else:
            msg='Select a numbered tool (1–19), H for Help or 0 to Exit.'

if __name__=='__main__':
    try: main()
    except (KeyboardInterrupt, EOFError): print('\nGhost Strategist Tool exited.')
