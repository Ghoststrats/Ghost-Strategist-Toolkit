#!/usr/bin/env python3
"""Opt-in NetworkManager DHCP lease refresh with verified IPv4 comparison.

NetworkManager reconnect may return the same IP and may fail to reconnect.
This module never promises a new external/public IP.
"""
from gs_brand import print_gs as print
import shutil
import re
import subprocess
import sys


def run(args, timeout=22):
    try:
        return subprocess.run(args, text=True, capture_output=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return subprocess.CompletedProcess(args, 1, '', str(exc))


def ipv4(iface):
    result = run(['ip', '-4', '-o', 'addr', 'show', 'dev', iface])
    if result.returncode:
        return ()
    return tuple(line.split(' inet ', 1)[1].split()[0]
                 for line in result.stdout.splitlines() if ' inet ' in line)


def connected_devices():
    result = run(['nmcli', '-t', '-f', 'DEVICE,TYPE,STATE', 'device', 'status'])
    if result.returncode:
        return []
    options = []
    for row in result.stdout.splitlines():
        # nmcli -t escapes literal colon in names. We use the first field as iface;
        # normal Linux device names cannot contain colon.
        fields = row.split(':')
        if len(fields) >= 3 and fields[1] in ('wifi', 'ethernet') and fields[2] == 'connected':
            options.append(fields[0])
    return options


def refresh(input_fn=input, output=print, runner=run):
    if not shutil.which('nmcli') or not shutil.which('ip'):
        return '! NetworkManager (nmcli) and iproute2 are required; no changes made.'
    devices = connected_devices()
    if not devices:
        return '! No connected NetworkManager Ethernet/Wi-Fi devices were found. No changes made.'
    output('GS IP CHANGER — local IPv4 / DHCP renew')
    output('! This may disconnect your network; use the local console, not SSH.')
    output('! It does not change your public internet IP and cannot guarantee a new local IP.')
    for index, iface in enumerate(devices, 1):
        output(f' [{index}] {iface} — {", ".join(ipv4(iface)) or "no IPv4 address"}')
    answer = input_fn('Choose device (0 cancels): ').strip()
    if not answer.isdigit() or not 1 <= int(answer) <= len(devices):
        return 'Cancelled. No changes made.'
    iface = devices[int(answer) - 1]
    before = ipv4(iface)
    if input_fn(f'Reconnect {iface} to request a fresh DHCP lease? [y/N]: ').strip().lower() != 'y':
        return 'Cancelled. No changes made.'
    # Bind to the currently active connection UUID for THIS adapter, not a
    # potentially duplicated human-readable profile name.
    details = runner(['nmcli', '-t', '-f', 'UUID,DEVICE', 'connection', 'show', '--active'])
    profile = ''
    if details.returncode == 0:
        for row in details.stdout.splitlines():
            match = re.fullmatch(r'([0-9a-fA-F-]{36}):(.+)', row.strip())
            if match and match.group(2) == iface:
                profile = match.group(1)
                break
    if not profile:
        return '! Could not identify the active connection UUID. No changes made.'
    output('Previous local IPv4: ' + (', '.join(before) if before else '(none)'))
    down = runner(['nmcli', 'connection', 'down', 'uuid', profile], timeout=30)
    if down.returncode != 0:
        output('! Disconnect failed. Reconnection has not been attempted.')
        return '! DHCP refresh did not complete: ' + (down.stderr.strip()[:200] or 'NetworkManager error')
    up = runner(['nmcli', 'connection', 'up', 'uuid', profile, 'ifname', iface], timeout=40)
    after = ipv4(iface)
    output('Current local IPv4:  ' + (', '.join(after) if after else '(none)'))
    if up.returncode:
        return '! Reconnection failed. Your connection may be offline; reconnect with Linux Mint Network settings.'
    if tuple(a.split('/')[0] for a in after) != tuple(a.split('/')[0] for a in before) and after:
        return '! Verified: the assigned LOCAL IPv4 address changed. Your public IP may not have changed.'
    if after:
        return '! Reconnected, but your router assigned the SAME IPv4 address. This is normal for DHCP.'
    return '! Reconnected but no local IPv4 address could be verified. Check NetworkManager.'


if __name__ == '__main__':
    print(refresh())

# V42 additional DHCP identity workflow: optional and fully opt-in.
# It may produce a different lease but cannot force the router to comply.
import json
import os
import secrets
import tempfile
from pathlib import Path

STATE = Path(os.getenv('XDG_STATE_HOME', str(Path.home()/'.local'/'state'))) / 'ghost-strategist-tool' / 'ip-changer-v42.json'


def active_uuid(iface, runner=run):
    result=runner(['nmcli','-t','-f','UUID,DEVICE','connection','show','--active'])
    if result.returncode: return None
    for row in result.stdout.splitlines():
        match=re.fullmatch(r'([0-9a-fA-F-]{36}):(.+)',row.strip())
        if match and match.group(2)==iface:return match.group(1)
    return None


def dhcp_id(uuid, runner=run):
    result=runner(['nmcli','-g','ipv4.dhcp-client-id','connection','show','uuid',uuid])
    if result.returncode:return None
    val=result.stdout.strip()
    return '' if val in ('--','') else val


def backup_identity(uuid,iface,old):
    if STATE.exists() or STATE.is_symlink():return False
    try:
        STATE.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        os.chmod(STATE.parent,0o700)
        fd,path=tempfile.mkstemp(prefix='.ip-state-',dir=STATE.parent)
        try:
            with os.fdopen(fd,'w') as f:json.dump({'uuid':uuid,'interface':iface,'original':old},f)
            os.chmod(path,0o600)
            os.replace(path,STATE)
        finally:
            if os.path.exists(path):os.unlink(path)
        return True
    except (OSError,ValueError):return False


def request_different(input_fn=input,output=print,runner=run):
    if not shutil.which('nmcli') or not shutil.which('ip'):
        return '! NetworkManager and iproute2 are needed; no changes made.'
    if STATE.exists():
        return '! A previous GS IP change is saved. Restore it before trying another identity.'
    devices=connected_devices()
    if not devices:return '! No connected NetworkManager Ethernet/Wi-Fi devices found.'
    output('GS IP CHANGER — alternate DHCP identity')
    output('! Changing DHCP client identity can disrupt networking, reserved leases or access rules.')
    output('! No guaranteed new IP; this does not change your public internet address.')
    for i,dev in enumerate(devices,1):output(f' [{i}] {dev}: {", ".join(ipv4(dev)) or "no local IPv4"}')
    selected=input_fn('Choose adapter (0 cancels): ').strip()
    if not selected.isdecimal() or not 1<=int(selected)<=len(devices):return 'Cancelled.'
    iface=devices[int(selected)-1]
    uuid=active_uuid(iface,runner)
    if not uuid:return '! Could not identify active profile. No changes made.'
    original=dhcp_id(uuid,runner)
    if original is None:return '! Cannot read original DHCP identity. No changes made.'
    if input_fn('Change DHCP client identity for this profile, and reconnect? [y/N]: ').strip().lower()!='y':return 'Cancelled.'
    if not backup_identity(uuid,iface,original):return '! Could not securely save original identity. No changes made.'
    old=ipv4(iface)
    new_id='gs-'+secrets.token_hex(8)
    changed=runner(['nmcli','connection','modify','uuid',uuid,'ipv4.dhcp-client-id',new_id])
    if changed.returncode:
        STATE.unlink(missing_ok=True)
        return '! NetworkManager rejected the profile change. No lease request was made.'
    res=runner(['nmcli','connection','down','uuid',uuid],timeout=30)
    up=runner(['nmcli','connection','up','uuid',uuid,'ifname',iface],timeout=40)
    if up.returncode:
        # Attempt immediate restore and reconnect; keep backup unless both succeed.
        rollback=runner(['nmcli','connection','modify','uuid',uuid,'ipv4.dhcp-client-id',original])
        recover=runner(['nmcli','connection','up','uuid',uuid,'ifname',iface],timeout=40)
        if rollback.returncode==0 and recover.returncode==0:STATE.unlink(missing_ok=True)
        return '! Reconnect failed. Attempted to restore original profile; check Mint Network Settings if offline.'
    current_ips=ipv4(iface)
    output('Previous local IPv4: '+(', '.join(old) or '(none)'))
    output('Current local IPv4:  '+(', '.join(current_ips) or '(none)'))
    if current_ips and tuple(a.split('/')[0] for a in old)!=tuple(a.split('/')[0] for a in current_ips):
        return '! Local IPv4 verified CHANGED. Original DHCP setting saved for [Restore].'
    return '! Router returned the same address (or no verified address). Original DHCP setting saved for [Restore].'


def restore_identity(input_fn=input,output=print,runner=run):
    if not STATE.exists() or STATE.is_symlink():return '! No saved IP Changer identity to restore.'
    try:data=json.loads(STATE.read_text())
    except (OSError,ValueError):return '! Saved network identity is unreadable.'
    uuid,iface,original=data.get('uuid'),data.get('interface'),data.get('original')
    if not isinstance(uuid,str) or not re.fullmatch(r'[0-9a-fA-F-]{36}',uuid) or not isinstance(iface,str) or not isinstance(original,str):
        return '! Invalid saved configuration.'
    output(f'! This will restore DHCP client identity on {iface} and briefly reconnect.')
    if input_fn('Restore original DHCP profile setting? [y/N]: ').strip().lower()!='y':return 'Cancelled.'
    modified=runner(['nmcli','connection','modify','uuid',uuid,'ipv4.dhcp-client-id',original])
    if modified.returncode:return '! Could not restore DHCP identity. Backup retained.'
    down=runner(['nmcli','connection','down','uuid',uuid],timeout=30)
    up=runner(['nmcli','connection','up','uuid',uuid,'ifname',iface],timeout=40)
    if up.returncode:return '! Identity restored in profile, but reconnect failed. Backup retained for review.'
    STATE.unlink(missing_ok=True)
    output('Current local IPv4: '+(', '.join(ipv4(iface)) or '(none)'))
    return '! Original DHCP client identity restored. The router may still assign a different local IP.'
