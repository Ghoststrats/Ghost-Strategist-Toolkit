#!/usr/bin/env bash
# Ghost Strategist Tool — best-effort remote access lockdown for Linux Mint.
# Manual only. Changes system UFW + known systemd remote-desktop / SSH services.
set -u
umask 077
STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/ghost-strategist-tool"
STATE="$STATE_DIR/remote-lockdown-state.tsv"
SYSTEM_UNITS=(ssh.service ssh.socket sshd.service sshd.socket xrdp.service xrdp-sesman.service x11vnc.service vino-server.service gnome-remote-desktop.service rustdesk.service anydesk.service teamviewerd.service wayvnc.service)
USER_UNITS=(gnome-remote-desktop.service vino-server.service wayvnc.service x11vnc.service rustdesk.service)

msg(){
    local line="$*"
    if [[ -t 1 && -z "${NO_COLOR+x}" ]]; then
        local purple=$'\033[38;5;141m' reset=$'\033[0m'
        line="${line//GS/${purple}GS${reset}}"
    fi
    printf '%s\n' "$line"
}
usage(){ msg 'Usage: bash remote-lockdown.sh menu|apply|restore|status'; exit 2; }
requires(){ command -v "$1" >/dev/null 2>&1; }
unit_loaded(){
    local scope="$1" unit="$2" load
    if [[ "$scope" == system ]]; then
        load="$(systemctl show --property=LoadState --value "$unit" 2>/dev/null || true)"
    else
        load="$(systemctl --user show --property=LoadState --value "$unit" 2>/dev/null || true)"
    fi
    [[ -n "$load" && "$load" != not-found && "$load" != masked ]]
}
unit_active(){
    if [[ "$1" == system ]]; then systemctl is-active --quiet "$2" 2>/dev/null; else systemctl --user is-active --quiet "$2" 2>/dev/null; fi
}
unit_enabled(){
    local status
    if [[ "$1" == system ]]; then status="$(systemctl is-enabled "$2" 2>/dev/null || true)"
    else status="$(systemctl --user is-enabled "$2" 2>/dev/null || true)"; fi
    [[ "$status" == enabled || "$status" == enabled-runtime ]]
}
firewall_active(){ sudo -n ufw status 2>/dev/null | grep -q '^Status: active'; }
firewall_default_before(){
    # UFW's built-in policy file holds this even if UFW is inactive.
    if [[ -r /etc/default/ufw ]]; then
        sed -n 's/^DEFAULT_INPUT_POLICY="\([A-Z]*\)".*/\1/p' /etc/default/ufw | head -n 1
    fi
}
check(){
    msg 'REMOTE ACCESS STATUS — informational, not an intrusion scan'
    if requires ufw; then
        if sudo -n true >/dev/null 2>&1; then sudo -n ufw status verbose 2>&1 || true
        else msg 'Firewall: admin access required to verify. Administrator status may need sudo authentication.'; fi
    else msg 'Firewall: ufw is not installed. Cannot apply UFW policy.'; fi
    msg ''
    if requires ss; then
        msg 'Listening TCP sockets (other services may be present):'
        ss -lnt 2>/dev/null | head -n 35 || true
    else msg 'Network sockets: ss not found'; fi
    msg ''
    msg 'Recognized remote access units:'
    local scope unit found=0
    for scope in system user; do
        if [[ "$scope" == system ]]; then units=("${SYSTEM_UNITS[@]}"); else units=("${USER_UNITS[@]}"); fi
        for unit in "${units[@]}"; do
            if unit_loaded "$scope" "$unit"; then
                found=1
                local active=inactive enabled=disabled
                unit_active "$scope" "$unit" && active=active
                unit_enabled "$scope" "$unit" && enabled=enabled
                printf '  %-7s %-31s %-9s %s\n' "$scope" "$unit" "$active" "$enabled"
            fi
        done
    done
    [[ "$found" == 0 ]] && msg '  None of the known service units found.'
    if [[ -f "$STATE" ]]; then msg 'Lockdown backup: saved (restorable by this tool)'; else msg 'Lockdown backup: none'; fi
    msg 'Note: listener checks cannot prove remote access is impossible.'
}

check_short(){
    msg 'REMOTE ACCESS | CURRENT STATUS'
    local scope unit active_count=0 recognized=0
    for scope in system user; do
        if [[ "$scope" == system ]]; then units=("${SYSTEM_UNITS[@]}"); else units=("${USER_UNITS[@]}"); fi
        for unit in "${units[@]}"; do
            if unit_loaded "$scope" "$unit"; then
                ((recognized+=1))
                if unit_active "$scope" "$unit"; then
                    printf '  ACTIVE: %-33s (%s)\n' "$unit" "$scope"
                    ((active_count+=1))
                fi
            fi
        done
    done
    msg "Recognized remote service units: $recognized installed; $active_count running."
    if (( recognized == 0 )); then
        msg '  No known remote service units found. Other remote-control software may exist.'
    elif (( active_count == 0 )); then
        msg '  None of the recognized services were active at inspection time.'
    fi
    if requires ufw; then
        local status
        status="$(sudo -n ufw status 2>/dev/null | head -n1)"
        if [[ "$status" == 'Status: active' ]]; then msg 'UFW firewall: ACTIVE — existing ALLOW rules may permit incoming connections'
        elif [[ "$status" == 'Status: inactive' ]]; then msg 'UFW firewall: INACTIVE — not an active inbound firewall policy'
        else msg 'UFW firewall: UNKNOWN — sudo access may be required'; fi
    else msg 'UFW firewall: NOT AVAILABLE'; fi
    if [[ -f "$STATE" ]]; then
        msg 'RECOVERY: PENDING BACKUP. Another apply will be refused.'
        if [[ -f "$STATE_DIR/blackout-session-v66.tsv" ]]; then
            msg '  GS BlackOut snapshot detected. If BlackOut created this state, use main [19] Turn It All On.'
        else
            msg '  Next step: choose [3] Restore Previous Remote Settings first.'
        fi
    else
        msg 'RECOVERY: No previous standalone remote lockdown backup.'
    fi
    msg 'Not a proof of total isolation; select [4] Technical Details for listening sockets.'
}


apply(){
    if [[ -f "$STATE" ]]; then
        msg 'NOT APPLIED: A recovery snapshot already exists; original settings were preserved.'
        if [[ -f "$STATE_DIR/blackout-session-v66.tsv" ]]; then
            msg 'If created by GS BlackOut, choose main menu [19] Turn It All On.'
        else
            msg 'Choose [3] Restore Previous Remote Settings, then check status.'
        fi
        return 3
    fi
    if ! requires systemctl; then msg 'systemctl is missing; cannot manage remote services.'; return 1; fi
    if ! requires ufw; then msg 'ufw not available. Not applying a partial lockdown; install UFW through Mint first.'; return 1; fi
    # Prompt for administrator rights BEFORE saving or changing anything.
    msg 'Admin authorization may be required. This can terminate existing remote sessions.'
    if ! sudo -v; then msg 'Cancelled: administrator authorization failed.'; return 1; fi
    mkdir -p "$STATE_DIR" || return 1
    local tmp; tmp="$(mktemp "$STATE_DIR/.remote-lockdown.XXXXXX")" || return 1
    local fw=inactive before
    if firewall_active; then fw=active; fi
    before="$(firewall_default_before)"
    case "$before" in ACCEPT|DROP|REJECT) ;; *) msg 'Could not safely read current UFW default policy; making no changes.'; rm -f "$tmp"; return 1;; esac
    printf 'FIREWALL|%s|%s\n' "$fw" "$before" > "$tmp"
    local scope unit active enabled
    for scope in system user; do
        if [[ "$scope" == system ]]; then units=("${SYSTEM_UNITS[@]}"); else units=("${USER_UNITS[@]}"); fi
        for unit in "${units[@]}"; do
            if unit_loaded "$scope" "$unit"; then
                active=0; enabled=0
                unit_active "$scope" "$unit" && active=1
                unit_enabled "$scope" "$unit" && enabled=1
                printf 'UNIT|%s|%s|%s|%s\n' "$scope" "$unit" "$active" "$enabled" >> "$tmp"
            fi
        done
    done
    # State saved before modifications for recovery from a partial failure.
    if ! ln -- "$tmp" "$STATE"; then rm -f "$tmp"; msg 'Backup could not be saved.'; return 1; fi
    rm -f -- "$tmp"
    msg 'Saved previous UFW and recognized service states.'
    local error=0
    # This changes only the default input policy, not existing explicit UFW allow rules.
    if ! sudo ufw default deny incoming; then msg 'WARNING: could not change incoming policy'; error=1; fi
    if ! sudo ufw --force enable; then msg 'WARNING: could not enable UFW'; error=1; fi
    for scope in system user; do
        if [[ "$scope" == system ]]; then units=("${SYSTEM_UNITS[@]}"); else units=("${USER_UNITS[@]}"); fi
        for unit in "${units[@]}"; do
            if unit_loaded "$scope" "$unit"; then
                if [[ "$scope" == system ]]; then
                    if ! sudo systemctl disable --now "$unit" >/dev/null 2>&1; then
                        # Static units may be stoppable even if not disable-able.
                        if ! sudo systemctl stop "$unit" >/dev/null 2>&1; then error=1; msg "WARNING: unable to stop $unit"; fi
                    fi
                else
                    if ! systemctl --user disable --now "$unit" >/dev/null 2>&1; then
                        if ! systemctl --user stop "$unit" >/dev/null 2>&1; then error=1; msg "WARNING: unable to stop user service $unit"; fi
                    fi
                fi
            fi
        done
    done
    # Do not report success merely because systemctl accepted the command.
    # A socket or user service may remain active or reactivate a stopped unit.
    for scope in system user; do
        if [[ "$scope" == system ]]; then units=("${SYSTEM_UNITS[@]}"); else units=("${USER_UNITS[@]}"); fi
        for unit in "${units[@]}"; do
            if unit_loaded "$scope" "$unit" && unit_active "$scope" "$unit"; then
                msg "NOT DISABLED: $unit ($scope) remains active."; error=1
            fi
        done
    done
    if [[ "$error" == 0 ]]; then msg 'VERIFIED: recognized remote services and sockets inactive.'
    else msg 'INCOMPLETE: some recognized remote-access services remain active or were not stopped.'; fi
    msg 'IMPORTANT: Existing UFW ALLOW rules may still permit inbound access.'
    msg 'Non-systemd tools and outbound remote-control sessions may remain. Use Status to verify the result.'
    msg "To reverse standalone remote changes, use this tool's own restore option."
    return "$error"
}

restore(){
    if [[ ! -f "$STATE" ]]; then msg 'No saved Remote Access Lockdown state. Nothing was changed.'; return 2; fi
    if ! sudo -v; then msg 'Administrator authorization required to restore.'; return 1; fi
    local record scope unit active enabled fw= before= policy
    # Never execute data from the saved file as shell script.
    while IFS='|' read -r record scope unit active enabled; do
        if [[ "$record" == FIREWALL ]]; then fw="$scope"; before="$unit"; fi
    done < "$STATE"
    case "$before" in ACCEPT) policy=allow;; DROP) policy=deny;; REJECT) policy=reject;; *) msg 'Backup policy invalid; stop.'; return 1;; esac
    case "$fw" in active|inactive) ;; *) msg 'Backup firewall state invalid; stop.'; return 1;; esac
    local error=0
    # Restore only known systemd units with a recorded active/enabled state.
    while IFS='|' read -r record scope unit active enabled; do
        [[ "$record" == UNIT ]] || continue
        [[ "$scope" == system || "$scope" == user ]] || { error=1; continue; }
        # Do not trust arbitrary unit names in backup file.
        case "$unit" in ssh.service|ssh.socket|sshd.service|sshd.socket|xrdp.service|xrdp-sesman.service|x11vnc.service|vino-server.service|gnome-remote-desktop.service|rustdesk.service|anydesk.service|teamviewerd.service|wayvnc.service) ;; *) error=1; continue;; esac
        [[ "$active" =~ ^[01]$ && "$enabled" =~ ^[01]$ ]] || { error=1; continue; }
        if [[ "$scope" == system ]]; then
            if [[ "$enabled" == 1 ]] && ! sudo systemctl enable "$unit" >/dev/null 2>&1; then msg "Restore failed: enable $unit"; error=1; fi
            if [[ "$active" == 1 ]] && ! sudo systemctl start "$unit" >/dev/null 2>&1; then msg "Restore failed: start $unit"; error=1; fi
        else
            if [[ "$enabled" == 1 ]] && ! systemctl --user enable "$unit" >/dev/null 2>&1; then msg "Restore failed: enable user $unit"; error=1; fi
            if [[ "$active" == 1 ]] && ! systemctl --user start "$unit" >/dev/null 2>&1; then msg "Restore failed: start user $unit"; error=1; fi
        fi
    done < "$STATE"
    if ! sudo ufw default "$policy" incoming; then error=1; fi
    if [[ "$fw" == inactive ]]; then sudo ufw --force disable || error=1
    else sudo ufw --force enable || error=1; fi
    if [[ "$error" == 0 ]]; then
        rm -- "$STATE"
        msg 'RESTORE FINISHED: previous saved settings applied; inspect [1] Status to verify.'
    else
        msg 'RESTORE INCOMPLETE: backup retained; inspect errors and retry only the affected steps.'
    fi
    return "$error"
}

confirm(){
    local answer
    read -r -p "$1 [y/N]: " answer
    [[ "$answer" == [Yy] ]]
}

case "${1:-menu}" in
    status) if [[ "${2:-}" == --details ]]; then check; else check_short; fi;;
    apply)
        # A pending recovery must be resolved before requesting another approval.
        if [[ -f "$STATE" ]]; then
            apply
        elif [[ "${2:-}" == --confirmed ]] || confirm 'Apply remote lockdown? SSH or remote-desktop sessions may disconnect'; then
            apply
        else
            msg 'Cancelled: no changes requested.'
            exit 10
        fi;;
    restore)
        # BlackOut owns any remote snapshot created during its own activation.
        # Its own undo uses --confirmed and must still work in the correct order.
        if [[ -f "$STATE_DIR/blackout-session-v66.tsv" && "${2:-}" != --confirmed ]]; then
            msg 'NOT RESTORED: GS BlackOut session exists. Use main menu [19] Turn It All On.'
            exit 3
        elif [[ ! -f "$STATE" ]]; then
            restore
        elif [[ "${2:-}" == --confirmed ]] || confirm 'Restore previously saved remote services and UFW policy'; then
            restore
        else
            msg 'Cancelled: no changes requested.'
            exit 10
        fi;;
    menu)
        msg 'GHOST STRATEGIST — REMOTE ACCESS LOCKDOWN'
        msg '1) Check recognized services and sockets (read-only)'
        msg '2) Apply remote lockdown (can disconnect services)'
        msg '3) Restore previously saved service and firewall state'
        msg '0) Back'
        read -r -p 'Choose: ' choice
        case "$choice" in
            1) check_short;;
            2) if confirm 'Apply Remote Access Lockdown? May disconnect remote sessions'; then apply; else msg 'Cancelled: no changes requested.'; exit 10; fi;;
            3) if confirm 'Restore settings saved before lockdown'; then restore; else msg 'Cancelled: no changes requested.'; exit 10; fi;;
            0) exit 0;;
            *) msg 'Unknown option';;
        esac;;
    *) usage;;
esac
