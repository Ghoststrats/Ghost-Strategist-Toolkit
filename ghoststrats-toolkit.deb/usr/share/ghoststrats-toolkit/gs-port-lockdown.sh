#!/usr/bin/env bash
# Ghost Strategist Tool — defensive incoming-connection firewall controls.
# UFW, not a port/service killer. Designed for Linux Mint with UFW installed.
set -u
set -o pipefail
umask 077

STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/ghost-strategist-tool"
STATE="$STATE_DIR/port-lockdown-v22.state"
REMOTE_STATE="$STATE_DIR/remote-lockdown-state.tsv"
TAG_ALL='GST_PORT_ALL_V22'
TAG_COMMON='GST_PORT_COMMON_V22'
PURPLE=$'\033[38;5;141m'; RESET=$'\033[0m'
COMMON_PORTS=(21/tcp 22/tcp 23/tcp 111/tcp 135/tcp 139/tcp 445/tcp 2049/tcp 3389/tcp 5900:5910/tcp)

info() {
  local line="$*"
  if [[ -t 1 && -z "${NO_COLOR+x}" ]]; then
    line="${line//GS/${PURPLE}GS${RESET}}"
  fi
  printf '%s\n' "$line"
}
brand() { printf '%sGS%s Port Lockdown\n' "$PURPLE" "$RESET"; }
confirm() { local a; read -r -p "$1 [y/N]: " a || return 1; [[ "$a" == y || "$a" == Y ]]; }
requires() { command -v "$1" >/dev/null 2>&1; }
active() { LC_ALL=C sudo -n ufw status 2>/dev/null | grep -q '^Status: active'; }

# Extract only rule numbers with OUR unique comment tags. Remove highest-numbered
# rules first, so indexes remain stable while deleting. No unrelated rule deleted.
our_numbers() {
  local status
  status="$(LC_ALL=C sudo ufw status numbered 2>/dev/null)" || return 1
  printf '%s\n' "$status" | python3 -c '
import re,sys
for line in sys.stdin:
    m=re.match(r"^\[\s*(\d+)\]\s+", line)
    if m and re.search(r"#\s+GST_PORT_(?:ALL|COMMON)_V22(?:\s|$)", line):
        print(int(m.group(1)))
' | sort -rn
}

show_listening() {
  brand
  info 'READ-ONLY: sockets listening locally (not necessarily reachable remotely).'
  if requires ss; then ss -tuln || true; else info 'Missing ss command (provided by iproute2).'; fi
  info ''
  info 'TCP LISTEN means a process listens. Firewall blocking does not stop that process.'
  info 'UDP sockets may also be shown. A port list does not prove external reachability.'
}
show_firewall() {
  brand
  info 'Current UFW status and inbound rules (read-only).'
  if ! requires ufw; then info 'UFW not installed: sudo apt install ufw'; return 1; fi
  if ! sudo -v; then info 'Administrator authorization needed for full firewall status.'; return 1; fi
  sudo ufw status verbose || true
  info ''
  sudo ufw status numbered || true
  info ''
  if [[ -f "$STATE" ]]; then info 'Saved port-lockdown state exists (restore available).'; fi
  info 'UFW may have rules ahead of user rules; forwarded traffic/outbound connections are separate.'
}
ensure_backup() {
  [[ -f "$STATE" ]] && return 0
  mkdir -p "$STATE_DIR" || return 1
  local fw=inactive tmp
  if active; then fw=active; fi
  tmp="$(mktemp "$STATE_DIR/.port-lockdown.XXXXXX")" || return 1
  printf 'PREV_UFW|%s\n' "$fw" > "$tmp"
  # Atomic state write before any rule is added. Mode 600 via umask.
  if ! ln -- "$tmp" "$STATE"; then rm -f -- "$tmp"; return 1; fi
  rm -f -- "$tmp"
}
check_ipv6_for_all() {
  # If UFW IPv6 coverage is switched off, an 'all incoming' claim would be false.
  if [[ -r /etc/default/ufw ]] && grep -Eq '^IPV6=yes([[:space:]]|$)' /etc/default/ufw; then
    return 0
  fi
  info 'Cannot request all-incoming lockdown: UFW IPv6 coverage is not confirmed enabled.'
  info 'Review /etc/default/ufw and IPv6 networking manually before using this action.'
  return 1
}
apply_all() {
  brand
  info 'This requests a UFW deny for new inbound connections.'
  info 'Outbound traffic remains allowed by this action. Local listening services remain running.'
  info 'It may break SSH, LAN sharing, Remote Desktop and other inbound services.'
  info 'Existing established sessions, loopback, routing, non-UFW filtering and'
  info 'rules in UFW before.rules may not be covered. It is NOT total port closure.'
  requires ufw || { info 'UFW missing. On Mint, install ufw separately.'; return 1; }
  requires python3 || { info 'Python 3 required for safe tagged-rule restoration.'; return 1; }
  check_ipv6_for_all || return 1
  if [[ "${1:-}" != --confirmed ]] && ! confirm 'Block new inbound connections now?'; then info 'Cancelled.'; return 0; fi
  sudo -v || { info 'Administrator access denied.'; return 1; }
  ensure_backup || { info 'Could not create restorable state. No changes made.'; return 1; }
  local n
  n="$(our_numbers | wc -l)"
  if LC_ALL=C sudo ufw status numbered 2>/dev/null | grep -q "# $TAG_ALL"; then
    info 'Block-all rule already present. No duplicate added.'
  else
    # `ufw insert 1` fails with `Invalid position '1'` on an empty ruleset.
    # Use a normal append if there is no numbered rule to insert before.
    # When rules already exist, inserting at position one gives deny precedence
    # over ordinary later user rules (UFW before.rules may still supersede).
    if LC_ALL=C sudo ufw status numbered 2>/dev/null | grep -Eq '^\[[[:space:]]*1\]'; then
      if ! sudo ufw insert 1 deny in from any to any comment "$TAG_ALL"; then
        info 'FAILED: could not insert the deny rule. No protection claimed.'; return 1
      fi
    elif ! sudo ufw deny in from any to any comment "$TAG_ALL"; then
      info 'FAILED: could not add the deny rule. No protection claimed.'; return 1
    fi
  fi
  if ! sudo ufw --force enable; then info 'UFW failed to enable. Rule may exist; inspect and restore.'; return 1; fi
  if ! active; then
    info 'WARNING: UFW does not report an active firewall; do not assume ports are blocked.'
    return 1
  fi
  if ! LC_ALL=C sudo ufw status numbered 2>/dev/null | grep -Fq "# $TAG_ALL"; then
    info 'WARNING: The tagged all-incoming deny rule could not be verified in UFW.'
    return 1
  fi
  info 'VERIFIED: UFW is active and the GS all-incoming deny rule is listed.'
  info 'This blocks inbound traffic covered by UFW; it does NOT stop listening services.'
  info 'All-incoming rule is removable using Restore GS Port Rules.'
}
apply_common() {
  brand
  info 'Blocks new inbound connections to common remote-service ports only:'
  info "${COMMON_PORTS[*]}"
  info 'Does not stop services, block outgoing traffic, or close every open port.'
  requires ufw || { info 'UFW missing. Install ufw separately.'; return 1; }
  requires python3 || { info 'Python 3 required for tagged-rule restoration.'; return 1; }
  if ! confirm 'Block these incoming ports? May interrupt your local services'; then info 'Cancelled.'; return 0; fi
  sudo -v || return 1
  ensure_backup || return 1
  local port err=0
  # Avoid duplicate installation of a full common set. Partial errors remain
  # visible and saved, so the user can restore safely.
  if LC_ALL=C sudo ufw status numbered 2>/dev/null | grep -q "# $TAG_COMMON"; then
    info 'Some common-port rules already present; restore first before reapplying.'; return 1
  fi
  local added=0 verified=0
  for port in "${COMMON_PORTS[@]}"; do
    # Never use `insert 1` on an empty firewall: UFW rejects the position.
    # Explicitly scoped TCP inbound denies are supported by regular UFW rules.
    if sudo ufw deny in "$port" comment "$TAG_COMMON"; then
      ((added+=1))
    else
      info "FAILED to add $port"; err=1
    fi
  done
  if ! sudo ufw --force enable; then
    info 'FAILED: UFW could not be enabled.'; err=1
  fi
  if ! active; then
    info 'FAILED: UFW is not active. No firewall protection is confirmed.'
    return 1
  fi
  # Verify *each* intended port, not a total line count (IPv6 can add pairs).
  # A successful UFW command alone is NOT proof that a rule was installed.
  local status
  status="$(LC_ALL=C sudo ufw status numbered 2>/dev/null)" || {
    info 'FAILED: UFW rule verification unavailable.'; return 1;
  }
  for port in "${COMMON_PORTS[@]}"; do
    if printf '%s\n' "$status" | grep -F "$port" | grep -F 'DENY IN' | grep -Fq "# $TAG_COMMON"; then
      ((verified+=1))
    else
      info "NOT VERIFIED: $port"
      err=1
    fi
  done
  info "Commands accepted: $added/${#COMMON_PORTS[@]} | Tagged deny rules verified: $verified/${#COMMON_PORTS[@]}"
  if ((err)); then
    info 'WARNING: INCOMPLETE port lockdown. Do not assume these ports are protected.'
    info 'Review Firewall Status; the saved restore state was preserved.'
    return 1
  fi
  info 'VERIFIED: UFW active and all requested tagged TCP deny rules are listed.'
  info 'An earlier ALLOW rule, UFW before.rules, or another firewall may affect enforcement.'
  return 0
}
restore_rules() {
  local unattended="${1:-}"
  brand
  if [[ ! -f "$STATE" ]]; then info 'No saved GS Port Lockdown state to restore.'; return 1; fi
  info 'Restore removes ONLY tagged GS Port Lockdown rules.'
  info 'It does not undo unrelated UFW policies or stopped system services.'
  if [[ "$unattended" != --confirmed ]] && ! confirm 'Restore port-lockdown rules and previous UFW on/off state where safe?'; then info 'Cancelled.'; return 0; fi
  sudo -v || return 1
  local fw line indexes num error=0
  fw="$(sed -n 's/^PREV_UFW|\(active\|inactive\)$/\1/p' "$STATE" | head -n 1)"
  [[ "$fw" == active || "$fw" == inactive ]] || { info 'Invalid state. Cannot restore safely.'; return 1; }
  # UFW status numbered needs UFW active in some distributions. Do not flip
  # the firewall on for cleanup unexpectedly; explain instead.
  if ! active; then
    info 'UFW is currently inactive. Do not toggle it blindly.'
    info 'Tagged rules may still exist in configuration; re-enable UFW then retry restoration.'
    return 1
  fi
  indexes="$(our_numbers)" || { info 'Could not query UFW numbered rules; unchanged.'; return 1; }
  while IFS= read -r num; do
    [[ -n "$num" ]] || continue
    [[ "$num" =~ ^[0-9]+$ ]] || { error=1; continue; }
    if ! sudo ufw --force delete "$num"; then error=1; info "Could not remove rule $num"; fi
  done <<< "$indexes"
  if [[ -n "$(our_numbers)" ]]; then
    info 'Tagged rules remain; state retained for retry.'; return 1
  fi
  if [[ "$fw" == inactive && -f "$REMOTE_STATE" ]]; then
    info 'Remote Access Lockdown is still active. Leaving UFW enabled to avoid undoing it.'
    info 'Restore Remote Access Lockdown separately if desired.'
  elif [[ "$fw" == inactive ]]; then
    if ! sudo ufw --force disable; then info 'Could not restore inactive firewall state.'; error=1; fi
  fi
  if [[ "$error" == 0 ]]; then
    rm -f -- "$STATE"
    info 'GS port rules removed. Firewall state restored where safe.'
  else
    info 'Restoration incomplete; state preserved for retry.'
  fi
  return "$error"
}

menu() {
  printf '%sGS%s PORT LOCKDOWN — LINUX MINT\n' "$PURPLE" "$RESET"
  info 'Ports are endpoints used by services. This tool filters incoming traffic;'
  info 'it does not stop or uninstall processes, and does not guarantee anonymity.'
  info ''
  info '[1] View Listening Ports — see TCP/UDP sockets (read-only)'
  info '[2] Block Common Remote Ports — deny FTP/SSH/SMB/RDP/VNC/NFS inbound'
  info '[3] Block ALL Incoming Ports — explicit high-priority inbound deny'
  info '[4] Firewall Status — inspect active rules and defaults'
  info '[5] Restore GS Port Rules — remove this tool’s firewall changes'
  info '[0] Back'
  local ans
  read -r -p 'Choose: ' ans || return 0
  case "$ans" in
    1) show_listening;;
    2) apply_common;;
    3) apply_all;;
    4) show_firewall;;
    5) restore_rules;;
    0) return 0;;
    *) info 'Unknown option.';;
  esac
}

case "${1:-menu}" in
  menu) menu;;
  status) show_firewall;;
  listen) show_listening;;
  apply-all) apply_all "${2:-}";;
  apply-common) apply_common;;
  restore) restore_rules "${2:-}";;
  *) info 'Usage: gs-port-lockdown.sh [menu|status|listen|apply-all|restore]'; exit 2;;
esac
