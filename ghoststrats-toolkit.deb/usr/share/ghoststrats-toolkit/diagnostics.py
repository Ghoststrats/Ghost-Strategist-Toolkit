#!/usr/bin/env python3
"""GS Toolkit Diagnostics — non-invasive local readiness report, no root or installs.

This tool does not call potentially disruptive commands, network connections, or
service status actions. It only checks available binaries, syntax and file states.
"""
from __future__ import annotations
from gs_brand import print_gs as print
import ast
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import gs_platform

BASE = Path(__file__).resolve().parent
REQUIRED = ('python3', 'bash', 'ps')
OPTIONAL = {
    'nmcli': 'Wi-Fi/device management and network profile controls',
    'bluetoothctl': 'Bluetooth discovery and controller power',
    'rfkill': 'Wi-Fi/Bluetooth hardware or software radio blocks',
    'pactl': 'Microphone and speaker software mute',
    'ip': 'Interface addresses and neighbor-cache inspection',
    'ss': 'Local TCP/UDP socket and port inspection',
    'ufw': 'UFW firewall and port controls',
    'sudo': 'Privileged, user-confirmed device or firewall changes',
    'systemctl': 'Service control and optional inactivity poweroff',
}


def inspection(base=BASE, which=shutil.which):
    """Return structured results for testing and safe display."""
    good=[]; warnings=[]; errors=[]
    for name in REQUIRED:
        (good if which(name) else errors).append(
            f'Required command {name}: ' + ('available' if which(name) else 'MISSING'))
    for name, role in OPTIONAL.items():
        (good if which(name) else warnings).append(
            f'{name}: ' + ('available' if which(name) else f'unavailable — {role} may be limited'))
    if sys.platform != 'linux':
        warnings.append('This toolkit requires Linux; current OS is '+sys.platform)
    else:
        family = gs_platform.detect()
        good.append('Linux detected: ' + gs_platform.label(family))
        if family == 'tails':
            warnings.append('Tails restricted session: only read-only inspection tools enabled; install may be temporary')
        if family == 'other-linux':
            warnings.append('Distribution unverified: device controls may be unsupported')
    session=os.getenv('XDG_SESSION_TYPE','unknown').lower()
    if session=='x11' and os.getenv('DISPLAY'):
        good.append('X11 desktop reported (GS NullOut may work; test idle detection separately)')
    else:
        warnings.append('X11 desktop not confirmed: GS NullOut is unavailable or unverified')
    if not (os.getenv('DISPLAY') or os.getenv('WAYLAND_DISPLAY')):
        warnings.append('No graphical desktop session reported: some appearance controls may not work')

    for path in sorted(base.glob('*.sh')):
        try:
            result=subprocess.run(['bash','-n',str(path)],capture_output=True,
                                  timeout=3,check=False)
            (good if result.returncode==0 else errors).append(
                f'Bash syntax {path.name}: ' + ('OK' if result.returncode==0 else 'ERROR'))
        except (OSError,subprocess.TimeoutExpired) as exc:
            errors.append(f'Bash syntax {path.name}: unavailable ({exc})')
    for path in sorted(base.glob('*.py')):
        try:
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
            good.append(f'Python syntax {path.name}: OK')
        except (OSError,UnicodeError,SyntaxError) as exc:
            errors.append(f'Python syntax {path.name}: ERROR ({exc})')

    state=Path(os.getenv('XDG_STATE_HOME',str(Path.home()/'.local/state')))/'ghost-strategist-tool'
    for filename in ('blackout-devices-v23.tsv','remote-lockdown-state.tsv',
                     'port-lockdown-v22.state','wifi-mac-backup.json',
                     'ip-changer-v42.json'):
        path=state/filename
        try:
            mode=path.lstat().st_mode
        except FileNotFoundError:
            continue
        except OSError as exc:
            warnings.append('Cannot inspect saved state '+filename+': '+str(exc))
            continue
        if stat.S_ISLNK(mode):
            warnings.append('State path is a symlink (inspect before trusting): '+filename)
        elif stat.S_ISREG(mode):
            if stat.S_IMODE(mode)&0o077:
                warnings.append('State file permissions are wider than user-only: '+filename)
            else:
                good.append('Saved toolkit settings file found, user-only permissions: '+filename)
        else:
            warnings.append('State path is not a regular file: '+filename)
    return good, warnings, errors


def run():
    print('\nGS TOOLKIT DIAGNOSTICS — READ ONLY')
    print('Checks local command availability, desktop compatibility, source syntax, and backup permissions.')
    print('It does NOT install anything, inspect private file contents, change devices, or certify safety.')
    good, warnings, errors = inspection()
    for title, results in (('READY / VALID',good),('LIMITATIONS / WARNINGS',warnings),('ERRORS',errors)):
        print(f'\n{title} ({len(results)})')
        for item in results: print('  - '+item)
    print(f'\nSUMMARY: {len(errors)} error(s), {len(warnings)} warning(s).')
    print('Some unavailable tools may be optional on your installation.')
    print('A passing check is NOT proof that hardware changes, shutdown, or firewall rules will work.')
    return 'Diagnostics completed; no settings changed.'


if __name__=='__main__':
    run()
