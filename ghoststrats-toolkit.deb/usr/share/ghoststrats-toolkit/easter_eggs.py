"""Read-only GhostStrats creator/community easter eggs.

A recognized phrase prints a small scene in the main-menu terminal. Easter
 eggs never spawn processes, inspect private user data, or change device state.
"""
import os
import re
import sys
import time
import select
import textwrap
import termios
import tty

PURPLE = '\033[38;5;141m'
GRAY = '\033[38;5;245m'
RESET = '\033[0m'

# Keep the original hidden commands and their KJV wording intact.
VERSE_RESPONSES = {
    '316': ('JOHN 3:16 | KJV',
        'For God so loved the world, that he gave his only begotten Son, '
        'that whosoever believeth in him should not perish, but have everlasting life.'),
    '828': ('ROMANS 8:28 | KJV',
        'And we know that all things work together for good to them that love God, '
        'to them who are the called according to his purpose.'),
    '413': ('PHILIPPIANS 4:13 | KJV',
        'I can do all things through Christ which strengtheneth me.'),
    '356': ('PROVERBS 3:5-6 | KJV',
        'Trust in the LORD with all thine heart; and lean not unto thine own understanding. '
        'In all thy ways acknowledge him, and he shall direct thy paths.'),
    '1414': ('EXODUS 14:14 | KJV',
        'The LORD shall fight for you, and ye shall hold your peace.'),
    'psalm461': ('PSALM 46:1 | KJV',
        'God is our refuge and strength, a very present help in trouble.'),
    'isaiah4110': ('ISAIAH 41:10 | KJV',
        'Fear thou not; for I am with thee: be not dismayed; for I am thy God: '
        'I will strengthen thee; yea, I will help thee; yea, I will uphold thee '
        'with the right hand of my righteousness.'),
    'joshua19': ('JOSHUA 1:9 | KJV',
        'Have not I commanded thee? Be strong and of a good courage; be not '
        'afraid, neither be thou dismayed: for the LORD thy God is with thee '
        'whithersoever thou goest.'),
    '2timothy17': ('2 TIMOTHY 1:7 | KJV',
        'For God hath not given us the spirit of fear; but of power, and of love, '
        'and of a sound mind.'),
    'psalm234': ('PSALM 23:4 | KJV',
        'Yea, though I walk through the valley of the shadow of death, I will '
        'fear no evil: for thou art with me; thy rod and thy staff they comfort me.'),
    'proverbs2712': ('PROVERBS 27:12 | KJV',
        'A prudent man foreseeth the evil, and hideth himself; but the simple '
        'pass on, and are punished.'),
    '1thessalonians521': ('1 THESSALONIANS 5:21 | KJV',
        'Prove all things; hold fast that which is good.'),
    'john832': ('JOHN 8:32 | KJV',
        'And ye shall know the truth, and the truth shall make you free.'),
    'romans1218': ('ROMANS 12:18 | KJV',
        'If it be possible, as much as lieth in you, live peaceably with all men.'),

}

# Title, then readable lines. References celebrate the creator's public work;
# no real name, location, employer, family information, or credentials appear.
SCENES = {
    'collective': ('DIGITAL GHOST COLLECTIVE // ROLL CALL',
        'WATCHERS  •  ENFORCERS  •  CONSTRUCTORS  •  COUNCIL',
        'Your voice is as good as mine. We build this together.'),
    'hangout': ('THE CYBER HANGOUT // SEASON ONE',
        '15 episodes. Real conversations. Live questions. A real community.',
        'Season two? The signal is never truly gone.'),
    'tower': ('GHOST TOWER 1 // MESH SIGNAL',
        '    NODE A  ~~~  RELAY  ~~~  NODE B',
        'No cell tower required for a local mesh link.',
        'Keep learning. Stay connected. Build your own infrastructure.'),
    'offgrid': ('OFF-GRID MODE // SIGNAL BEFORE SERVICE',
        'When the internet disappears, understanding radio still matters.',
        'Know your frequencies, limits, battery and local rules.'),
    'wardrive': ('WARDriving // PASSIVE SURVEY',
        'SIGNALS DETECTED. CURIOSITY ACTIVATED.',
        'Map the spectrum. Respect privacy. Never assume access.'),
    'wardrift': ('WARDRIFT // ACHIEVEMENT UNLOCKED',
        '+50 XP   |   +1 SIDE QUEST   |   0 REASONS TO STOP LEARNING',
        'The real reward is the knowledge you take home.'),
    'fighter': ('STIGNAL FIGHTER // CHARACTER SELECT',
        '[ GHOSTSTRATS ]  vs.  [ THE UNKNOWN SIGNAL ]',
        'ROUND 1 ... LEARN!'),
    'cyberdeck': ('CYBERDECK // BUILD SOMETHING USEFUL',
        'One screen. One small computer. Two power banks.',
        'No 3D printer required. Reuse parts. Make it yours.'),
    'halftop': ('PROJECT HALF TOP // STILL ALIVE',
        'Broken laptop screen? That is not the end of the computer.',
        'HALF THE TOP. ALL THE POSSIBILITIES.'),
    'nullout': ('GS NULLOUT // IDLE TIMER',
        '60 seconds of supported desktop inactivity -> shutdown request.',
        'No magic wipe. Just a deliberate, simple failsafe.'),
    'blackout': ('GS BLACKOUT // REDUCE EXPOSURE',
        'Radio, network, service and device controls are separate layers.',
        'Privacy is not one switch. Check results after every change.'),
    'bugout': ('GS BUGOUT // EXIT PLAN',
        'This is only an easter egg. No cleanup or shutdown was started.',
        'The real Full BugOut is menu [4] and requires confirmation.'),
    'computer': ('THE GHOST COMPUTER // BUILD PHILOSOPHY',
        'Keep it portable. Keep it understandable. Keep what you need.',
        'Less mystery in the machine. More control in your hands.'),
    'study': ('STUDY SEPTEMBER // COMMUNITY QUEST',
        'A month of learning, sharing, giveaways and showing up.',
        'Knowledge stays with you long after the prizes are gone.'),
    'biscuit': ('THE BISCUIT SHOP // FRESH SIGNALS',
        'Pro. Ultra. Crumb. Welcome to the cyber bakery.',
        'Remember: good tools are useful because you understand them.'),
    'compliance': ('COMPLIANCE, NOT RELIANCE.',
        'Follow the rules. Ask the questions. Verify the technology.',
        'Do not confuse a security label with a security guarantee.'),
    'milestone': ('GHOSTSTRATS // MILESTONE ARCHIVE',
        '100K subscribers  ->  200K subscribers  ->  10M views',
        'The numbers are milestones. The people are the mission.'),
    'eyes': ('GHOST MODE // NO FACE REVEAL',
        '          .-----------------.',
        '         /     HOOD UP     \\',
        '        |    < >   < >     |',
        '         \\___  GHOST  ___/',
        'Only the purple eyes are watching.'),
    'privacy': ('PRIVACY IS AN ILLUSION.',
        'Awareness is the first defense.',
        'Learn what a tool really does before trusting its claims.'),
    'face': ('FACE REVEAL // ACCESS DENIED',
        '3 ... 2 ... 1 ... NICE TRY.',
        'Hood stays up. Purple eyes stay on. The mission continues.'),
    'four04': ('ERROR 404 // PRIVACY NOT FOUND',
        'Did you check the permissions, radios, apps and network?',
        'Privacy Is an Illusion. Awareness is not.'),
    'secondary': ('GHOSTSTRATS SEC // DEFEND FIRST',
        'Knowledge over gimmicks. Learn how the systems work.',
        'Question the claims. Test responsibly.'),
    'youtube': ('GHOSTSTRATS // YOUTUBE CHANNEL',
        'https://www.youtube.com/@GhostStrats',
        'Cybersecurity, survival tech, privacy awareness, off-grid communications.'),
    'ghostcrew': ('DIGITAL GHOSTS // NEVER ALONE',
        'Watchers learn. Constructors build. Enforcers keep the peace.',
        'The Collective is stronger because everyone brings something different.'),
    'privacycode': ('PRIVACY / SAFETY IS AN ILLUSION',
        'Compliance, not reliance. Awareness, not fear.',
        'The best tool you carry is the knowledge you earned.'),
    'radiocheck': ('RADIO CHECK // DO YOU COPY?',
        'Portable power. Spare antennas. Off-grid practice.',
        'A network you understand is worth more than one you simply trust.'),
    'survival': ('SURVIVAL TECH // SKILLS BEFORE GEAR',
        'Charge batteries. Learn the basics. Test your backup plan.',
        'An expensive device does not replace preparation.'),
    'build': ('GHOSTSTRATS LAB // REUSE. REPAIR. REBUILD.',
        'Half Top to cyberdeck: a broken part does not have to end the project.',
        'Build it so someone else can learn from it.'),
    'watchers': ('THE WATCHERS // KEEP YOUR EYES OPEN',
        'The first step in protecting yourself is understanding your environment.'),
    'anomalysignal': ('ANOMALY DETECTED // GS404',
        'The machine knows your IP. It still cannot guess your next project.',
        'WE ARE THE ANOMALY.'),
    'quietsignal': ('GHOSTSTRATS // QUIET SIGNAL',
        'No noise. No promises. Just learning, testing and understanding.'),
    'hints': ('HIDDEN SIGNALS // FREQUENCIES TO EXPLORE',
        'Try the community, a radio tower, a stripped laptop,',
        'a cyber hangout, a biscuit, or an unexpected fighter.',
        'Find the YouTube channel, a few extra verses, or a hidden survival message.',
        'Try safety is an illusion for a full-screen letter-by-letter message.',
        'Type a related word at the MAIN MENU. These are harmless messages.'),
}

# Exact phrases or compact variations. Normalize spacing/punctuation to make
# commands forgiving without hijacking ordinary numbered menu selections.
ALIASES = {
    'digitalghostcollective':'collective', 'dgc':'collective', 'ghostcollective':'collective',
    'cyberhangout':'hangout', 'thecyberhangout':'hangout',
    'ghosttower':'tower', 'ghosttower1':'tower',
    'offgrid':'offgrid', 'meshtastic':'offgrid',
    'wardrive':'wardrive', 'wardriving':'wardrive',
    'wardrift':'wardrift', 'wdgwars':'wardrift',
    'stignalfighter':'fighter', 'stignal':'fighter',
    'cyberdeck':'cyberdeck', 'buildacyberdeck':'cyberdeck',
    'halftop':'halftop', 'projecthalftop':'halftop',
    'nullout':'nullout', 'gsnullout':'nullout',
    'blackout':'blackout', 'gsblackout':'blackout',
    'bugout':'bugout', 'gsbugout':'bugout',
    'ghostcomputer':'computer', 'zimablade':'computer',
    'studyseptember':'study', 'studysep':'study',
    'biscuit':'biscuit', 'biscuitshop':'biscuit', 'crumb':'biscuit',
    'compliancenotreliance':'compliance', 'compliance':'compliance',
    'milestone':'milestone', '10million':'milestone',
    'ghostmode':'eyes', 'purpleeyes':'eyes',
    'privacy':'privacy', 'privacyisanillusion':'privacy',
    'facereveal':'face', 'showyourface':'face',
    '404':'four04', 'gs404':'four04',
    'ghoststratssec':'secondary',
    'youtube':'youtube', 'ghoststratsyoutube':'youtube', 'ghoststratschannel':'youtube',
    'digitalghosts':'ghostcrew', 'ghostcrew':'ghostcrew',
    'privacycode':'privacycode', 'missionstatement':'privacycode',
    'radiocheck':'radiocheck', 'copythat':'radiocheck',
    'survival':'survival', 'survivaltech':'survival',
    'ghostlab':'build', 'reuse':'build', 'repair':'build',
    'watchers':'watchers', 'watcher':'watchers',
    'anomalysignal':'anomalysignal', 'gs404signal':'anomalysignal',
    'quietsignal':'quietsignal', 'quietmode':'quietsignal',
    'ghostsignal':'hints', 'hiddensignals':'hints',
}

VERSE_ALIASES = {
    'john316':'316', 'romans828':'828', 'philippians413':'413',
    'proverbs356':'356', 'exodus1414':'1414',
    'psalm461':'psalm461', 'isaiah4110':'isaiah4110', 'joshua19':'joshua19',
    '2timothy17':'2timothy17', 'iitimothy17':'2timothy17',
    'psalm234':'psalm234', 'proverbs2712':'proverbs2712',
    '1thessalonians521':'1thessalonians521',
    'john832':'john832', 'romans1218':'romans1218',
}


def _normalize(value):
    return re.sub(r'[\s.:_\-/]+', '', (value or '').strip().lower())


def _print_scene(title, lines, out, color):
    purple = PURPLE if color else ''
    gray = GRAY if color else ''
    reset = RESET if color else ''
    out('\n' + purple + '  ━━  ' + title + '  ━━' + reset)
    for line in lines:
        if not line:
            out('')
        else:
            # Bound wraps so hidden messages display comfortably in small terminals.
            for part in textwrap.wrap(line, width=68, subsequent_indent='   ',
                                      replace_whitespace=False, drop_whitespace=False) or ['']:
                out('   ' + gray + part + reset)
    out('')


def run(command, out=print, *, color=None):
    """Print only exact known secret responses; True if matched.

    Never performs any action beyond emitting the lines through ``out``.
    ``color`` is optional so tests and NO_COLOR shells produce plain text.
    """
    key = _normalize(command)
    if not key:
        return False
    if color is None:
        color = os.getenv('NO_COLOR') is None and sys.stdout.isatty()
    if key in {'ghostrats', 'ghoststrats', 'ghoststrategist'}:
        _print_scene('SAFETY IS AN ILLUSION.',
            ('Stay aware. Question assumptions. Privacy Is an Illusion.',), out, color)
        return True
    verse = VERSE_ALIASES.get(key, key)
    if verse in VERSE_RESPONSES:
        title, quote = VERSE_RESPONSES[verse]
        _print_scene(title, (quote,), out, color)
        return True
    if key in {'anomaly', 'wearetheanomaly'}:
        _print_scene('>>> WE ARE THE ANOMALY <<<',
                     ('Privacy Is an Illusion.',), out, color)
        return True
    scene = ALIASES.get(key)
    if scene is None:
        return False
    title, *lines = SCENES[scene]
    _print_scene(title, lines, out, color)
    return True


# Creator-supplied reading, kept separate from system-changing features.
MANIFESTO = "SAFETY IS AN ILLUSION.\n*A Message from GhostStrats*\nThey told us technology would make us safer.\nThat more cameras meant more protection. That more surveillance meant less danger. That surrendering pieces of our privacy was simply the price of living in a connected world.\nAnd we believed them.\nWe built our lives around systems we do not control. Trusted companies we've never met. Handed over our information to machines we barely understand.\nAnd somewhere along the way, we confused being watched with being protected.\n**But surveillance is not security. Convenience is not freedom. And dependence is not survival.**\nEvery network has a weakness. Every device can be compromised. Every system can fail.\nAnd history has shown us that the very technology created to protect humanity can just as easily be turned against it.\nYet we continue to believe someone is watching over us. Someone has a plan. Someone will come when everything falls apart.\nBut what happens when nobody comes?\nWhat happens when the towers go silent? When the networks collapse? When the technology you've depended on your entire life suddenly becomes nothing more than useless machinery?\n**Who are you when everything you rely on stops working?**\nAnd perhaps that is the greatest tragedy of our generation.\nWe have become so obsessed with securing our place in this world that we've forgotten this world was never our permanent home.\nWe are only passing through.\nAnd somewhere in the noise, we lost sight of what truly matters.\n**Our families. Our faith. Our purpose. Our salvation.**\nSo hear me when I say this.\n**Do not fight. The battle has already been won.**\nWe are not here to wage war against the world. We do not need to conquer its systems or challenge every authority.\n**Compliance is not reliance.**\nYou can follow the rules without surrendering your independence. You can respect authority without placing your survival entirely in its hands.\nLearn how technology works. Learn how to protect your privacy. Learn how to communicate without the infrastructure you've grown comfortable with.\nUnderstand the systems around you before those systems become the only things you know how to depend on.\n**Learn what you can, while you still can.**\nBecause there may come a time when the greatest threat to a world built on dependence is simply a person who knows how to survive without it.\nI don't say these things to frighten you.\nI say them because I believe knowledge should be shared, not hidden. Because I believe preparation is wisdom, not paranoia.\nAnd because I refuse to believe that humanity's future should be built on helplessness disguised as convenience.\n**You cannot hide from everything. You cannot prevent every disaster. And you cannot guarantee your own safety.**\nBut you can prepare.\nYou can learn.\nYou can become someone your family can depend on when the world they know begins to disappear.\nBecause one day, the machines will stop. The screens will go dark. The voices promising protection will fall silent.\nAnd in that silence, the illusion will finally break.\nThere will be no algorithm to guide you. No notification to warn you. No system to tell you what comes next.\nJust you.\nYour knowledge.\nYour preparation.\nAnd the truth you chose to understand before everyone else was forced to face it.\n**So don't spend your life trying to escape the eyes watching you. Spend it learning to stand when everything watching you finally goes blind.**\n**BECAUSE THE MOST DANGEROUS MOMENT ISN'T WHEN THE SYSTEM IS WATCHING YOU...**\n**IT'S WHEN THE SYSTEM STOPS WATCHING, AND YOU REALIZE YOU NEVER LEARNED HOW TO LIVE WITHOUT IT.**\n— **GhostStrats**"

def is_manifesto_command(command):
    """Match the complete hidden trigger; don't accept shell-like suffixes."""
    return _normalize(command) == 'safetyisanillusion'


def format_manifesto(text, *, color=True, width=84):
    """Wrap readable paragraphs; render markdown bold/italic as terminal style."""
    lines=[]
    for index, raw in enumerate(text.splitlines()):
        clean = raw.replace('**', '').replace('*', '')
        wrapped = textwrap.wrap(clean, width=width, break_long_words=False,
                                break_on_hyphens=False) or ['']
        for line in wrapped:
            if color and (raw.startswith('**') or raw.startswith('— **')):
                lines.append('\033[1m\033[38;5;141m' + line + RESET)
            elif color and index <= 1:
                lines.append(PURPLE + line + RESET)
            else:
                lines.append(line)
        # Extra paragraph spacing makes long reading easier to follow.
        if index not in (0,1):
            lines.append('')
    return '\n'.join(lines).rstrip()+'\n'


def play_manifesto(*, stream=None, input_stream=None, delay=0.015, sleeper=time.sleep):
    """Clear TERMINAL DISPLAY only; type creator text. Space/Enter skips typing.

    No filesystem writes, subprocesses, network actions or system mutations.
    Return True if skipped, False if fully typed. Ctrl+C cancels safely.
    """
    stream = stream if stream is not None else sys.stdout
    input_stream = input_stream if input_stream is not None else sys.stdin
    interactive = bool(getattr(stream, 'isatty', lambda: False)() and
                       getattr(input_stream, 'isatty', lambda: False)())
    color = os.getenv('NO_COLOR') is None and interactive
    width = max(45, min(94, os.get_terminal_size().columns - 4)) if interactive else 84
    message = format_manifesto(MANIFESTO, color=color, width=width)
    stream.write('\033[2J\033[H')
    stream.write('  GHOSTSTRATS // HIDDEN TRANSMISSION\n')
    stream.write('  Press SPACE or ENTER to display the rest instantly. Ctrl+C cancels.\n\n')
    stream.flush()
    if os.getenv('GHOSTSTRAT_TEST_MODE') == '1' or not interactive:
        stream.write(message)
        stream.flush()
        return False
    fd=None; previous=None; skipped=False
    try:
        fd=input_stream.fileno()
        previous=termios.tcgetattr(fd)
        tty.setcbreak(fd)
        # ANSI formatting is immediate; only visible characters are delayed.
        index = 0
        while index < len(message):
            if message[index] == '\x1b':
                match = re.match(r'\x1b\[[0-9;]*m', message[index:])
                if match:
                    stream.write(match.group(0))
                    index += len(match.group(0))
                    continue
            char = message[index]
            stream.write(char)
            stream.flush()
            index += 1
            if delay:
                sleeper(delay * 3 if char in '.?!' else delay)
            if select.select([fd], [], [], 0)[0]:
                # Avoid buffered Python stdin reads: leftover prefetched keys
                # must remain available when the main toolkit menu resumes.
                key = os.read(fd, 1).decode('utf-8', 'replace')
                if key in (' ', '\r', '\n'):
                    stream.write(message[index:])
                    skipped = True
                    break
                if key == '\x03':
                    raise KeyboardInterrupt
        stream.write('\n')
    except KeyboardInterrupt:
        stream.write('\n\n  Transmission interrupted.\n')
    finally:
        if fd is not None and previous is not None:
            termios.tcsetattr(fd, termios.TCSADRAIN, previous)
        stream.flush()
    return skipped
