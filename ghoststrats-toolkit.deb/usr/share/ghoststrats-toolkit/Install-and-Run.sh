#!/usr/bin/env bash
# GhostStrats Toolkit V81: unprivileged cross-distro installer & launcher.
# Never invokes apt/sudo, modifies the firewall, or flips any network/radio settings.
set -Eeuo pipefail

PURPLE='\033[1;35m'; RESET='\033[0m'; RED='\033[1;31m'
usage() {
  cat <<'HELP'
GS TOOLKIT / LINUX INSTALLER
Usage: ./Install-and-Run.sh [--check | --install-only | --help]

  (default)       Install for this user, register desktop launcher, and run
  --install-only  Install without opening the toolkit
  --check         Show detected Linux, desktop and restrictions; change nothing
  --help          Print these instructions

For Linux Mint, Kali, Parrot and compatible Debian-family desktop Linux.
Tails receives a restricted, normally nonpersistent user-local installation.
No sudo or dependency package installation is performed by this script.
HELP
}
mode=launch
case "${1:-}" in
  '') ;;
  --install-only|--no-launch) mode=install-only ;;
  --check) mode=check ;;
  -h|--help) usage; exit 0 ;;
  *) usage >&2; exit 2 ;;
esac
if (( EUID == 0 )); then
  printf '%b\n' "${RED}Use a normal user account, not sudo or root.${RESET}" >&2
  exit 1
fi
if [[ "$(uname -s)" != Linux ]]; then
  echo 'GhostStrats Toolkit requires Linux.' >&2
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Python 3 is required. Please install python3 using your distribution package manager.' >&2
  exit 1
fi
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ ! -f "$SOURCE_DIR/gs.py" || ! -f "$SOURCE_DIR/gs.sh" || ! -f "$SOURCE_DIR/gs_platform.py" ]]; then
  echo 'Required toolkit files are missing. Extract the complete ZIP and run this script from that folder.' >&2
  exit 1
fi
PLATFORM="$(python3 "$SOURCE_DIR/gs_platform.py" --id)"
printf '%b\n' "${PURPLE}GHOSTSTRATS TOOLKIT / LINUX INSTALLER${RESET}"
python3 "$SOURCE_DIR/gs_platform.py" --check
if [[ "$mode" == check ]]; then
  command -v bash >/dev/null || echo 'Warning: bash command missing.'
  command -v ps >/dev/null || echo 'Warning: ps command missing.'
  exit 0
fi
if ! command -v bash >/dev/null 2>&1; then
  echo 'Bash is required.' >&2
  exit 1
fi
if [[ "$PLATFORM" == tails ]]; then
  echo
  printf '%b\n' "${RED}TAILS RESTRICTED SESSION${RESET}"
  echo 'The toolkit will disable disruptive controls such as BlackOut, BugOut, NullOut, active scanning, device toggles and firewall modifications.'
  echo 'Tails privacy protection is not guaranteed by this program.'
  echo 'Files installed into your home directory are normally lost at shutdown unless explicitly stored in persistent storage.'
  echo 'Do not use the .deb system installer on Tails.'
fi
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}"
APP_DIR="$DATA_DIR/ghoststrats-toolkit"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$DATA_DIR/applications"
mkdir -p -- "$DATA_DIR" "$BIN_DIR" "$DESKTOP_DIR"

if [[ "$SOURCE_DIR" != "$APP_DIR" ]]; then
  TEMP_DIR="$(mktemp -d "$DATA_DIR/.ghoststrats-install.XXXXXXXX")"
  BACKUP_DIR=''
  cleanup() {
    if [[ -n "${TEMP_DIR:-}" && -d "$TEMP_DIR" ]]; then rm -rf -- "$TEMP_DIR"; fi
  }
  trap cleanup EXIT
  cp -a -- "$SOURCE_DIR/." "$TEMP_DIR/"
  if [[ -e "$APP_DIR" ]]; then
    BACKUP_DIR="$(mktemp -d "$DATA_DIR/.ghoststrats-backup.XXXXXXXX")"
    rmdir -- "$BACKUP_DIR"
    mv -- "$APP_DIR" "$BACKUP_DIR"
  fi
  if ! mv -- "$TEMP_DIR" "$APP_DIR"; then
    if [[ -n "$BACKUP_DIR" ]]; then mv -- "$BACKUP_DIR" "$APP_DIR"; fi
    echo 'Installation failed; previous installation restored.' >&2
    exit 1
  fi
  TEMP_DIR=''
  if [[ -n "$BACKUP_DIR" ]]; then rm -rf -- "$BACKUP_DIR"; fi
fi
chmod u+x -- "$APP_DIR/gs.sh" "$APP_DIR/gs-drone-detector.sh"
printf -v APP_SHELL '%q' "$APP_DIR/gs.sh"
printf '#!/usr/bin/env bash\nexec bash %s "$@"\n' "$APP_SHELL" > "$BIN_DIR/ghoststrats-toolkit"
chmod 755 "$BIN_DIR/ghoststrats-toolkit"
DESKTOP_EXEC="${BIN_DIR//\\/\\\\}/ghoststrats-toolkit"
DESKTOP_EXEC="${DESKTOP_EXEC//\"/\\\"}"
cat > "$DESKTOP_DIR/ghoststrats-toolkit.desktop" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=Ghost Strategist Toolkit
GenericName=Linux Privacy and Network Toolkit
Comment=Linux terminal privacy, diagnostics and wireless tools
Exec="$DESKTOP_EXEC"
Terminal=true
Icon=utilities-terminal
Categories=Utility;System;
StartupNotify=false
EOF
chmod 644 "$DESKTOP_DIR/ghoststrats-toolkit.desktop"
printf '%b\n' "${PURPLE}INSTALLATION COMPLETED${RESET}"
printf 'Linux: %s\nInstalled to: %s\nCommand: %s\n' "$PLATFORM" "$APP_DIR" "$BIN_DIR/ghoststrats-toolkit"
echo 'Desktop entry: Ghost Strategist Toolkit'
echo 'No packages, firewall, network, radio or service settings were changed.'
if [[ "$PLATFORM" == tails ]]; then
  echo 'Tails mode is restricted; the installation will normally not survive a reboot.'
fi
if [[ "$mode" == launch ]]; then
  if [[ ! -t 0 || ! -t 1 ]]; then
    echo 'Installation completed, but launch requires an interactive terminal.'
    echo "Launch with: $BIN_DIR/ghoststrats-toolkit"
    exit 0
  fi
  echo 'Starting the toolkit...'
  exec "$BIN_DIR/ghoststrats-toolkit"
fi
