# V81 — BLE scan enabled by default

- GS Drone Detector v2.6 starts passive Bluetooth LE discovery automatically in its single Turbo scan, with supported Wi-Fi/Remote ID detection.
- Removed the `--no-ble` BLE-disable option and the obsolete `--ble-only` mode.
- Missing BLE hardware/dependencies now reports **BLE unavailable**, not **BLE disabled**; Wi-Fi scanning continues.
- No Bluetooth radio toggling or pairing is performed automatically.
- [6] still starts Turbo directly; one Esc stops and returns to the main toolkit menu.
- All other toolkit features remain unchanged.
