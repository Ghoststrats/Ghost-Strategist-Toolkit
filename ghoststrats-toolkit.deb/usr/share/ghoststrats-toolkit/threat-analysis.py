#!/usr/bin/env python3
"""GS Threat Analysis: read-only, local exposure audit for Linux Mint.

No shell=True, sudo, package installation, network probing, or state changes.
No malware diagnosis or security guarantee. Reports local observable signals only.
"""
from gs_brand import print_gs as print
import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import textwrap
from dataclasses import dataclass

SENSITIVE_PORTS = {
    21: ('FTP', 'FTP may transmit credentials without encryption. Prefer SFTP or disable unused FTP.'),
    22: ('SSH', 'Remote login may be intended. Restrict to trusted hosts, prefer keys, update the service.'),
    23: ('Telnet', 'Unencrypted remote login. Stop the service if unnecessary; prefer SSH.'),
    111: ('RPCbind', 'RPC service discovery may expose network service information. Restrict network access.'),
    135: ('MS RPC', 'Remote procedure-call services deserve access restrictions.'),
    137: ('NetBIOS', 'Older Windows-style file-sharing discovery. Disable if unused.'),
    138: ('NetBIOS', 'Legacy file-sharing discovery. Disable if unused.'),
    139: ('SMB/NetBIOS', 'File-sharing service: restrict to trusted local networks.'),
    445: ('SMB', 'File sharing can disclose files if exposed. Limit access to trusted networks.'),
    2049: ('NFS', 'Network file sharing: restrict exports and trusted clients.'),
    3389: ('RDP', 'Remote desktop: restrict access, use strong authentication and updates.'),
    5900: ('VNC', 'Remote screen sharing: disable if unused; restrict or tunnel connections.'),
}
REMOTE_SERVICES = ('ssh', 'sshd', 'xrdp', 'vncserver', 'tigervnc', 'vino', 'wayvnc',
                   'rustdesk', 'anydesk', 'teamviewer', 'x11vnc', 'gnome-remote-desktop')
PURPLE = '\x1b[38;5;141m'
RED = '\x1b[91m'
AMBER = '\x1b[93m'
GREEN = '\x1b[92m'
RESET = '\x1b[0m'

@dataclass
class Finding:
    severity: str
    title: str
    evidence: str
    meaning: str
    action: str
    points: int = 0


def shell_read(argv, timeout=6):
    if not shutil.which(argv[0]):
        return None, 'missing utility: ' + argv[0]
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
        if p.returncode:
            return None, (p.stderr or p.stdout or f'exit {p.returncode}').strip()[:180]
        return p.stdout, None
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, str(exc)[:180]


def parse_firewall(output):
    if output is None:
        return 'UNKNOWN'
    m = re.search(r'^Status:\s*(active|inactive)', output, re.I | re.M)
    return m.group(1).upper() if m else 'UNKNOWN'


def parse_ports(output):
    """Parse `ss -H -ltnu`: proto, local-address:port, wildcard/loopback.

    ss columns: Netid State Recv-Q Send-Q Local Address:Port Peer Address:Port
    """
    ports = []
    if not output:
        return ports
    for line in output.splitlines():
        parts = line.split()
        if len(parts) < 6:
            continue
        proto, local = parts[0].lower(), parts[4]
        if proto not in ('tcp', 'udp'):
            continue
        m = re.match(r'^(.*):(\d+)$', local)
        if not m:
            continue
        bind = m.group(1).strip('[]')
        port = int(m.group(2))
        if port == 0:
            continue
        loopback = bind in ('127.0.0.1', '::1') or bind.startswith('127.')
        wildcard = bind in ('*', '0.0.0.0', '::')
        scope = 'LOOPBACK' if loopback else ('ALL INTERFACES' if wildcard else 'INTERFACE-BOUND')
        ports.append((proto, bind, port, scope))
    return sorted(set(ports), key=lambda x: (x[2], x[0], x[1]))


def risk_for_ports(ports, firewall):
    findings = []
    seen = set()
    for proto, bind, port, scope in ports:
        # Keep duplicate protocols and v4/v6 bind findings grouped by service/port.
        key = (proto, port, scope)
        if key in seen:
            continue
        seen.add(key)
        if scope == 'LOOPBACK':
            continue
        notable = port in SENSITIVE_PORTS or 5900 <= port <= 5909
        if notable:
            if port in SENSITIVE_PORTS:
                name, advice = SENSITIVE_PORTS[port]
                if proto == 'udp' and port in (21, 22, 23, 139, 445):
                    # Port numbers are conventions, NOT reliable service identity.
                    name = 'Unidentified UDP service'
                    advice = ('Check which application binds this UDP port; its number alone '
                              'does not establish the service protocol. Restrict it if unneeded.')
            else:
                name, advice = 'VNC', 'Remote screen sharing should be restricted to trusted clients.'
            if firewall == 'INACTIVE':
                severity, points = 'HIGH', 24
            elif firewall == 'ACTIVE':
                severity, points = 'MEDIUM', 9
            else:
                severity, points = 'MEDIUM', 12
            findings.append(Finding(severity, f'{name} listening on {proto.upper()} {port}',
                f'{bind}:{port} ({scope.lower()}); UFW {firewall.lower()}',
                'The machine accepts local socket connections on this interface. This alone does not prove an internet-reachable port or vulnerability.',
                advice + ' Check firewall rule exceptions and which application owns the port with sudo ss -ltnup.', points))
        elif firewall == 'INACTIVE' and scope == 'ALL INTERFACES':
            findings.append(Finding('MEDIUM', f'Other network-facing listener, port {port}',
                f'{proto.upper()} on {bind}:{port}',
                'A service appears to listen beyond localhost, but its purpose and external reachability are unverified.',
                'Identify its process using sudo ss -ltnup. If unused, stop the service or limit it to localhost/trusted networks.', 8))
    # Limit repeated identical-class alerts so machines with development servers are not exaggerated.
    extras = [f for f in findings if f.title.startswith('Other network-facing')]
    if len(extras) > 4:
        findings = [f for f in findings if not f.title.startswith('Other network-facing')] + extras[:4]
        findings.append(Finding('INFO', 'Additional listeners not itemized',
            f'{len(extras)-4} additional lower-priority network-facing listener(s)',
            'The report abbreviates repetitive non-sensitive port findings.',
            'Review the complete listening-port list in GS Port Lockdown.', 0))
    return findings


def run_audit(run=shell_read):
    findings = []
    checked = []
    unknown = []

    ufw, ufw_err = run(['ufw', 'status'])
    fw = parse_firewall(ufw)
    if fw == 'ACTIVE':
        checked.append('UFW reports active (rules not exhaustively evaluated)')
    elif fw == 'INACTIVE':
        findings.append(Finding('MEDIUM', 'UFW firewall is inactive', 'ufw status: inactive',
            'Mint is not enforcing UFW inbound rules. Another firewall, router, or NAT might still offer protection.',
            'Review your firewall policy; consider enabling UFW after checking the services you need. Do not change firewall rules while connected through SSH.', 10))
    else:
        unknown.append('UFW status unavailable: ' + (ufw_err or 'unrecognized response'))

    ss, ss_err = run(['ss', '-H', '-ltnu'])
    ports = parse_ports(ss)
    if ss is None:
        unknown.append('Listening ports could not be checked: ' + (ss_err or 'unknown'))
    else:
        checked.append(f'{len(ports)} local TCP/UDP listening socket endpoints reported by ss')
        findings.extend(risk_for_ports(ports, fw))
        if not any(p[3] != 'LOOPBACK' for p in ports):
            checked.append('No non-loopback listening sockets visible to this user')

    # Inspect remote software by running process names. Do not confuse mere installation with active use.
    ps, ps_err = run(['ps', '-eo', 'comm='])
    if ps is None:
        unknown.append('Running process names unavailable: ' + (ps_err or 'unknown'))
    else:
        running = set(x.strip().lower() for x in ps.splitlines())
        remote = sorted(running.intersection(REMOTE_SERVICES))
        if remote:
            findings.append(Finding('MEDIUM', 'Remote access software appears active',
                ', '.join(remote), 'Recognized remote-access processes are running. They may be legitimate and may not accept incoming connections.',
                'If you did not expect these services, inspect their configuration and active connections, then stop or disable only those you do not need.', 10))
        else:
            checked.append('No recognized remote-access process names in current process snapshot')

    # Read-only network interface summary. Radio enabled does not equal breach.
    nm, nm_err = run(['nmcli', 'radio', 'wifi'])
    if nm is not None:
        checked.append('Wi-Fi radio: ' + nm.strip()[:45])
    else:
        unknown.append('Wi-Fi status unavailable (' + str(nm_err)[:80] + ')')

    ip_addr, ip_err = run(['ip', '-br', 'addr'])
    if ip_addr is not None:
        entries = [line.strip() for line in ip_addr.splitlines() if line.strip()]
        checked.append(f'Network interfaces visible: {len(entries)}; inspect details with Network Adapters')
    else:
        unknown.append('Network interfaces unavailable: ' + (ip_err or 'unknown'))

    # MAC addresses visible on the local machine are not proof of spoofing or tracking.
    ip_link, link_err = run(['ip', '-br', 'link'])
    if ip_link is not None:
        checked.append('Network link/MAC status available via Network Adapters / MAC Address Inspector')
    else:
        unknown.append('Network link/MAC information unavailable: ' + (link_err or 'unknown'))

    rf, rf_err = run(['rfkill', '--noheadings', '-o', 'TYPE,SOFT,HARD'])
    if rf is None:
        unknown.append('Bluetooth radio status unavailable: ' + (rf_err or 'unknown'))
    else:
        bluetooth_lines = [line.strip() for line in rf.splitlines() if 'bluetooth' in line.lower()]
        checked.append('Bluetooth rfkill: ' + ('; '.join(bluetooth_lines)[:100] if bluetooth_lines else 'no Bluetooth radio listed'))

    # PulseAudio/PipeWire through pactl; no hardware disable guarantees.
    for kind, ident, label in (('source', '@DEFAULT_SOURCE@', 'Microphone'), ('sink', '@DEFAULT_SINK@', 'Speakers')):
        pa, pa_err = run(['pactl', f'get-{kind}-mute', ident])
        if pa is None:
            unknown.append(f'{label} mute state unavailable: {pa_err or "unknown"}')
        else:
            muted = re.search(r'\b(yes|no)\b', pa.lower())
            checked.append(f'{label} default audio mute: ' + ({'yes':'MUTED', 'no':'UNMUTED'}.get(muted.group(1), 'UNKNOWN') if muted else 'UNKNOWN'))

    video = glob.glob('/dev/video[0-9]*')
    checked.append(f'Camera device nodes: {len(video)} detected' if video else 'Camera device nodes: none detected (not proof of no camera)')

    conn, conn_err = run(['ss', '-H', '-tn', 'state', 'established'])
    if conn is not None:
        checked.append(f'{len([x for x in conn.splitlines() if x.strip()])} established TCP connections visible (not automatically suspicious)')
    else:
        unknown.append('Established TCP connection count unavailable: ' + (conn_err or 'unknown'))

    # Score represents prioritized observations only, not probability of compromise.
    score = min(100, sum(f.points for f in findings))
    if score >= 60:
        rating = 'HIGH EXPOSURE'
    elif score >= 35:
        rating = 'ELEVATED EXPOSURE'
    elif score >= 15:
        rating = 'MODERATE EXPOSURE'
    else:
        rating = 'LOW OBSERVED EXPOSURE'
    if ss is None and fw == 'UNKNOWN' and ps is None:
        rating = 'INCOMPLETE — INSUFFICIENT DATA'
    order = {'HIGH':0, 'MEDIUM':1, 'LOW':2, 'INFO':3}
    findings.sort(key=lambda x: (order.get(x.severity, 4), -x.points, x.title))
    return rating, score, findings, checked, unknown


def wrap(s, cols=80, indent='    '):
    return '\n'.join(textwrap.wrap(str(s), width=max(50, cols)-len(indent),
                                   initial_indent=indent, subsequent_indent=indent,
                                   break_long_words=False, break_on_hyphens=False))


def report(rating, score, findings, checked, unknown, color=True):
    cols = min(max(shutil.get_terminal_size((82, 24)).columns, 64), 110)
    use_color = color and sys.stdout.isatty() and not os.getenv('NO_COLOR')
    p = PURPLE if use_color else ''
    reset = RESET if use_color else ''
    warn = RED if use_color and score >= 60 else (AMBER if use_color and score >= 15 else (GREEN if use_color else ''))
    print('\n' + p + 'GS THREAT ANALYSIS — LOCAL SECURITY REVIEW' + reset)
    print('=' * min(cols, 75))
    print(wrap('Purpose: review local exposure and common privacy settings. This is a read-only educational audit, not a malware scanner, penetration test, or proof of anonymity.', cols, '  '))
    print(f'\n  SUMMARY: {len(findings)} prioritized finding(s) | {len(checked)} observations | {len(unknown)} incomplete checks')
    print('  Findings are listed by priority; an observation is not a confirmed attack.')
    print('\n  FINDINGS & RECOMMENDED ACTIONS')
    if not findings:
        print('  No prioritized exposure findings from the checks that succeeded.')
    for index, f in enumerate(findings, 1):
        print(f'\n  {index}. [{f.severity}] {f.title}')
        print(wrap('Observed: ' + f.evidence, cols))
        print(wrap('Meaning: ' + f.meaning, cols))
        print(wrap('Action: ' + f.action, cols))
    print('\n  OTHER OBSERVATIONS')
    for item in checked:
        print(wrap('- ' + item, cols, '  '))
    if unknown:
        print('\n  NOT VERIFIED / INCOMPLETE CHECKS')
        for item in unknown:
            print(wrap('- ' + item, cols, '  '))
    print('\n' + '=' * min(cols, 75))
    print('  ' + warn + f'OVERALL THREAT LEVEL (OBSERVED EXPOSURE): {rating}' + reset)
    print(f'  Review score: {score}/100 (illustrative heuristic, NOT a probability of compromise)')
    print(f'  Checks with unknown results: {len(unknown)}; unknown does not mean safe.')
    print(wrap('Rating combines visible network listeners, UFW status and known remote-access process names. It cannot determine internet reachability, firewall rule effectiveness, malware infections, patched vulnerabilities or all possible privacy leaks.', cols, '  '))
    print('\n  STRICTLY FOR EDUCATIONAL PURPOSES ONLY.')
    print('  Privacy Is an Illusion — learn what the settings really do.\n')


def detail_ports():
    """Show current local listeners without guessing actual service identity."""
    out, err = shell_read(['ss', '-H', '-ltnu'])
    if out is None:
        print('Listening port inventory unavailable:', err)
        return
    rows = parse_ports(out)
    print('\nGS THREAT ANALYSIS — LISTENING PORT INVENTORY (READ ONLY)')
    print('A listening socket does NOT prove internet reachability or a vulnerability.\n')
    print(f'{"TYPE":<6} {"LOCAL ADDRESS":<34} {"PORT":<7} SCOPE')
    print('-'*75)
    for proto, addr, port, scope in rows[:150]:
        print(f'{proto.upper():<6} {addr[:34]:<34} {port:<7} {scope}')
    if len(rows) > 150:
        print(f'... {len(rows)-150} additional entries not shown')
    print(f'\nTotal visible listening endpoints: {len(rows)}')
    print('For process ownership (may need sudo): ss -ltnup')


def detail_connections():
    out, err = shell_read(['ss', '-H', '-tn', 'state', 'established'])
    print('\nGS THREAT ANALYSIS — ESTABLISHED TCP CONNECTIONS (READ ONLY)')
    print('An established connection is not necessarily suspicious. Addresses may be sensitive.\n')
    if out is None:
        print('Unavailable:', err)
        return
    lines = [x.strip() for x in out.splitlines() if x.strip()]
    print(f'Connections visible: {len(lines)}')
    for line in lines[:40]:
        print('  '+line[:160])
    if len(lines)>40:
        print(f'... {len(lines)-40} more not shown')
    print('Look up an unfamiliar process locally before drawing conclusions.')


def detail_privacy():
    print('\nGS THREAT ANALYSIS — DEVICE & PRIVACY STATUS (READ ONLY)')
    checks = [
        ('Wi-Fi radio', ['nmcli','radio','wifi']),
        ('WWAN radio', ['nmcli','radio','wwan']),
        ('Radio blocks', ['rfkill','--noheadings','-o','TYPE,SOFT,HARD']),
        ('Default input mute', ['pactl','get-source-mute','@DEFAULT_SOURCE@']),
        ('Default output mute', ['pactl','get-sink-mute','@DEFAULT_SINK@']),
        ('Network DNS configuration', ['nmcli','-g','IP4.DNS,IP6.DNS','device','show']),
    ]
    for label, command in checks:
        out, err = shell_read(command)
        if out is None:
            print(f'  {label}: UNKNOWN ({err})')
        else:
            value='; '.join(x.strip() for x in out.splitlines() if x.strip())
            print(f'  {label}: {(value or "not reported")[:240]}')
    print(f'  Camera device nodes: {len(glob.glob("/dev/video[0-9]*"))}')
    print('Software mute is not a physical microphone or camera disconnect.')
    print('DNS server configuration does not prove whether DNS queries are encrypted.')


def main():
    parser = argparse.ArgumentParser(description='Read-only Ghost Strategist exposure report')
    parser.add_argument('--explain', action='store_true', help='Explain the scoring method')
    parser.add_argument('--ports', action='store_true', help='Show listening sockets')
    parser.add_argument('--connections', action='store_true', help='Show TCP connections')
    parser.add_argument('--privacy', action='store_true', help='Show device and privacy settings')
    args = parser.parse_args()
    if args.ports:
        return detail_ports()
    if args.connections:
        return detail_connections()
    if args.privacy:
        return detail_privacy()
    if args.explain:
        print('GS THREAT ANALYSIS: HOW THE RATING WORKS\n')
        print('The score is a heuristic severity total, capped at 100.')
        print('0–14 Low observed exposure, 15–34 Moderate, 35–59 Elevated, 60–100 High.')
        print('An inactive UFW firewall and exposed sensitive listeners increase the score.')
        print('Localhost-only ports are not scored; process presence is not proof of compromise.')
        print('Other firewalls may exist; UFW active does not prove every port is blocked.')
        print('Wi-Fi on, unmuted mic or detected camera are informational, not evidence of attack.')
        print('No CVE check, virus scan, external scan, or network traffic interception occurs.')
        return
    report(*run_audit())

if __name__ == '__main__':
    main()
