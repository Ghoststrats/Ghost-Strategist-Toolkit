#!/usr/bin/env python3
"""Read-only, keyboard-friendly live process viewer for Ghost Strategist Tool.

Uses only the standard library and the commonly installed Linux `ps` utility.
Unlike htop/top this view returns control to the enclosing submenu directly.
"""

from gs_brand import print_gs as print
import os
import select
import shutil
import subprocess
import sys
import termios
import time
import tty
from datetime import datetime

PURPLE = '\033[38;5;141m'
RESET = '\033[0m'
ALT_ON = '\033[?1049h\033[?25l'
ALT_OFF = '\033[?25h\033[?1049l'
REFRESH_SECONDS = 2.5


def fetch_processes():
    """Get one snapshot; never alter or signal processes."""
    try:
        result = subprocess.run(
            ['ps', '-eo', 'pid,user,stat,pcpu,pmem,comm', '--sort=-pcpu'],
            capture_output=True, text=True, errors='replace', timeout=5,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return [], f'Could not read the process list: {exc}'
    if result.returncode:
        detail = result.stderr.strip().splitlines()
        return [], 'ps failed: ' + (detail[0] if detail else f'exit {result.returncode}')
    return result.stdout.splitlines(), None


def display_snapshot(lines, error=None, live=False):
    columns, rows = shutil.get_terminal_size((90, 24))
    width = max(40, columns)
    limit = max(3, rows - 13) if live else None
    body = lines[1:1 + limit] if limit is not None else lines[1:]
    out = [
        'GHOST STRATEGIST  /  TASK MANAGER  •  V37',
        'Read-only process inspection  |  No changes to running processes',
        '─' * min(width, 72),
    ]
    if live:
        out.append(f'Live view — refreshed every {REFRESH_SECONDS:g} seconds  |  {datetime.now():%H:%M:%S}')
        out.append('Press 0 or Q to return immediately. Press R to refresh now.')
        out.append('Ctrl+C also returns safely. You do NOT have to press Enter.')
    out.extend(['', '   PID   USER           STATE  %CPU  %MEM  COMMAND'])
    if error:
        out.append('ERROR: ' + error)
    elif not lines:
        out.append('No process data available.')
    else:
        # ps formats each row itself; use a terminal-width limit for long names.
        out.extend(line[:width] for line in body)
        if live and len(lines) > (1 + len(body)):
            out.append(f'  ... {len(lines) - 1 - len(body)} additional processes not shown')
    out += [
        '',
        'STATE: R=running, S=sleeping, D=I/O wait, Z=zombie, T=stopped.',
        'CPU values from ps are averages over a process lifetime, not instantaneous.',
    ]
    return '\n'.join(out) + '\n'


def snapshot():
    """A single screen for users who do not want a continuously updating viewer."""
    lines, error = fetch_processes()
    print('\n' + display_snapshot(lines, error, live=False))
    return 'Process snapshot complete.'


def live(idle_check=None, refresh_seconds=REFRESH_SECONDS):
    """Show processes in alternate terminal screen, restore terminal on any exit.

    The main menu's optional GS NullOut idle callback is checked while live.
    """
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print('Live Task Manager requires an interactive terminal.')
        print('Choose [2] Process Snapshot for a non-interactive display.')
        return 'Live viewer was not started.'

    fd = sys.stdin.fileno()
    try:
        original = termios.tcgetattr(fd)
    except (OSError, termios.error):
        return 'Terminal input is unavailable; use Process Snapshot instead.'

    use_alt = os.environ.get('TERM', '') not in ('', 'dumb')
    entered_alt = False
    try:
        tty.setcbreak(fd)
        if use_alt:
            sys.stdout.write(ALT_ON)
            entered_alt = True
        next_redraw = 0.0
        while True:
            now = time.monotonic()
            if now >= next_redraw:
                lines, error = fetch_processes()
                text = display_snapshot(lines, error, live=True)
                if use_alt:
                    sys.stdout.write('\033[H\033[2J')
                else:
                    sys.stdout.write('\n' + '=' * 40 + '\n')
                sys.stdout.write(text)
                sys.stdout.flush()
                next_redraw = time.monotonic() + refresh_seconds
            if idle_check is not None:
                idle_check()
            delay = min(0.25, max(0.0, next_redraw - time.monotonic()))
            try:
                ready, _, _ = select.select([sys.stdin], [], [], delay)
            except (OSError, ValueError):
                return 'Terminal input interrupted; returned to Task Manager menu.'
            if ready:
                # Read directly from the TTY, not Python's buffered text stream.
                # Buffered prefetch can swallow the next toolkit menu selection.
                key = os.read(fd, 1).decode('utf-8', 'replace')
                if key in ('0', 'q', 'Q', '\x1b') or not key:
                    break
                if key in ('r', 'R'):
                    next_redraw = 0.0
    except KeyboardInterrupt:
        pass
    finally:
        # Restore cbreak/cursor/screen even if an error or Ctrl+C occurs.
        termios.tcsetattr(fd, termios.TCSADRAIN, original)
        # If someone pressed 0 followed by Enter, do not feed that extra
        # newline into the parent submenu as an accidental blank choice.
        termios.tcflush(fd, termios.TCIFLUSH)
        if entered_alt:
            sys.stdout.write(ALT_OFF)
            sys.stdout.flush()
    return 'Live Task Manager closed. Choose another option or [0] Back.'


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--snapshot':
        snapshot()
    else:
        live()
