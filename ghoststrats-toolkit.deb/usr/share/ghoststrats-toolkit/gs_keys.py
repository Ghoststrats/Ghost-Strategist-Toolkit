"""Shared, dependency-free prompt reader: Esc returns to the toolkit home menu.

Only takes over keyboard input at an interactive TTY prompt. It never intercepts
sudo passwords, program subprocesses, or active command output.
"""
from __future__ import annotations

import codecs
import os
import select
import sys
import termios


class HomeRequested(Exception):
    """A bare Escape key was pressed at a GhostStrats-owned prompt."""


def escape_pressed(fd: int, delay: float = 0.04) -> bool:
    """True for bare Esc, false for arrow/function keys with Esc prefixes.

    Consume an ANSI key sequence so its trailing characters never accidentally
    select menu options. Terminal escape sequences are not home requests.
    """
    readable, _, _ = select.select([fd], [], [], delay)
    if not readable:
        return True
    prefix = os.read(fd, 1)
    if prefix in (b'[', b'O'):
        for _ in range(20):
            readable, _, _ = select.select([fd], [], [], delay)
            if not readable:
                break
            part = os.read(fd, 1)
            if not part or (65 <= part[0] <= 90) or (97 <= part[0] <= 122) or part == b'~':
                break
    return False


def read_line(prompt: str = '', *, watchdog=None, interval: float = 0.2, max_chars: int = 4096) -> str:
    """Read line input; Esc immediately raises HomeRequested, no Enter needed.

    Falls back to normal input for pipes, redirected output, and unit tests.
    This reader uses a single prompt line (rather than cursor repositioning),
    so status timers can't overwrite partially typed text.
    """
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return input(prompt)
    try:
        fd = sys.stdin.fileno()
        state = termios.tcgetattr(fd)
    except (ValueError, OSError, termios.error):
        return input(prompt)

    new = termios.tcgetattr(fd)
    new[3] &= ~(termios.ICANON | termios.ECHO)
    new[6][termios.VMIN] = 1
    new[6][termios.VTIME] = 0
    result = []
    decoder = codecs.getincrementaldecoder('utf-8')('replace')
    sys.stdout.write(prompt)
    sys.stdout.flush()
    try:
        termios.tcsetattr(fd, termios.TCSADRAIN, new)
        while True:
            ready, _, _ = select.select([fd], [], [], interval)
            if not ready:
                if watchdog is not None:
                    watchdog()
                continue
            data = os.read(fd, 1)
            if not data:
                raise EOFError
            key = data[0]
            if key in (10, 13):
                sys.stdout.write('\n')
                sys.stdout.flush()
                return ''.join(result)
            if key == 27:
                if escape_pressed(fd):
                    sys.stdout.write('\n')
                    sys.stdout.flush()
                    raise HomeRequested
                continue
            if key == 3:
                raise KeyboardInterrupt
            if key == 4 and not result:
                raise EOFError
            if key in (127, 8):
                if result:
                    result.pop()
                    sys.stdout.write('\b \b')
            elif key == 21:  # Ctrl+U: clear line
                while result:
                    result.pop()
                    sys.stdout.write('\b \b')
            elif key >= 32 and len(result) < max_chars:
                char = decoder.decode(data)
                if char:
                    result.append(char)
                    sys.stdout.write(char)
            sys.stdout.flush()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, state)
