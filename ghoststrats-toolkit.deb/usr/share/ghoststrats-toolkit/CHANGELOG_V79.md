# Ghost Strategist Toolkit V79 — Stable Menu Input

## Fixed

- Removed the main menu's separate raw-keypress and cursor-jumping timer renderer.
- Main menu and toolkit submenus now use the same direct terminal reader.
- Empty Enter and Esc on the home menu no longer clear and redraw the whole screen.
- GS NullOut's inactivity watchdog remains active during timed menu input.
- Existing 19 tool routes, current GS Drone Detector, and other actions are retained.
- Safer across small and scrolling terminals; the timer is a snapshot on the home screen rather than an in-place animation.

## Verification

- 204 automated tests passed (200 inherited + 4 new stability tests).
- Three cycles of interactive Home → GS Drone Detector → Home → Task Manager → Home completed on a non-root pseudoterminal.
- Hardware-dependent features were not operated during verification.

## Recovering a damaged old terminal

Exit using Ctrl+C. If typing is invisible, run `stty sane`. If Ctrl+S froze
terminal output, press Ctrl+Q. Then start the new program. On a supported
desktop, use an 80x24 or larger terminal for the main dashboard.
