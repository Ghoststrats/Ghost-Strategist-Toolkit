#!/usr/bin/env bash
# Turn It All On: reverse ONLY a recorded GS BlackOut activation.
# Never restore the toolkit startup baseline or standalone tool backups.
set -u
umask 077
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$BASE" || exit 1
DIR="${XDG_STATE_HOME:-$HOME/.local/state}/ghost-strategist-tool"
STATE="$DIR/blackout-session-v66.tsv"
REMOTE="$DIR/remote-lockdown-state.tsv"
PORT="$DIR/port-lockdown-v22.state"
EXTRA="$DIR/blackout-extra-v47.tsv"
export GS_BLACKOUT_DEVICE_STATE="$STATE"
msg(){ printf '%s\n' "$*"; }
get(){ local key="$1"; sed -n "s/^${key}|//p" "$STATE" | head -1; }
msg 'GS TURN IT ALL ON — UNDO BLACKOUT ONLY'
msg 'Reverses saved GS BlackOut changes, not GS BugOut, DHCP identity,'
msg 'independent firewall controls, system logs, or other toolkit settings.'
msg 'Features that were already OFF before BlackOut are left OFF.'
msg ''
if [[ -L "$DIR" || -L "$STATE" || ! -f "$STATE" ]]; then
  msg 'No GS BlackOut activation backup. Nothing will be changed.'
  exit 2
fi
for name in WIFI MIC_MUTE REMOTE_PREEXIST PORT_PREEXIST EXTRA_PREEXIST; do
  if ! grep -q "^${name}|" "$STATE"; then
    msg "Incomplete BlackOut backup ($name missing). No changes attempted."
    exit 3
  fi
done
for name in REMOTE_PREEXIST PORT_PREEXIST EXTRA_PREEXIST; do
  case "$(get "$name")" in yes|no) ;; *) msg "Invalid BlackOut ownership value: $name"; exit 3;; esac
done
msg 'Recorded states:'
while IFS='|' read -r key value; do
 case "$key" in CAPTURED_AT|WIFI|BT_BLOCK|BT_POWER|MIC_MUTE|SPK_MUTE|UVC|REMOTE_PREEXIST|PORT_PREEXIST|EXTRA_PREEXIST)
   printf '  %-19s %s\n' "$key" "$value";; esac
done < "$STATE"
msg ''
msg 'Restoration may reconnect networking, microphones, cameras, or remote services.'
read -r -p 'Turn It All On and reverse this GS BlackOut session? [y/N] ' ans || exit 10
if [[ "$ans" != y && "$ans" != Y ]]; then msg 'Cancelled; no changes changed.'; exit 10; fi
errors=0
# Reverse in safe order; only backups that DID NOT preexist BlackOut are eligible.
if [[ "$(get PORT_PREEXIST)" == no && -f "$PORT" && ! -L "$PORT" ]]; then
 msg '[1] Undoing GS BlackOut-added firewall rules...'
 bash ./gs-port-lockdown.sh restore --confirmed || errors=1
else msg '[1] No GS BlackOut-owned port rules to undo.'; fi
if [[ "$(get REMOTE_PREEXIST)" == no && -f "$REMOTE" && ! -L "$REMOTE" ]]; then
 msg '[2] Undoing GS BlackOut-added remote-access restrictions...'
 bash ./remote-lockdown.sh restore --confirmed || errors=1
else msg '[2] No GS BlackOut-owned remote restrictions to undo.'; fi
if [[ "$(get EXTRA_PREEXIST)" == no && -f "$EXTRA" && ! -L "$EXTRA" ]]; then
 msg '[3] Undoing GS BlackOut-added network, WWAN and service changes...'
 bash ./blackout-extra.sh restore || errors=1
else msg '[3] No GS BlackOut-owned extra-control changes to undo.'; fi
msg '[4] Restoring recorded GS BlackOut radio, audio and supported camera states...'
bash ./device-controls.sh restore || errors=1
if [[ "$errors" == 0 ]]; then
  if ! rm -f -- "$STATE"; then errors=1; fi
fi
if [[ "$errors" == 0 ]]; then
 msg 'GS BlackOut restoration commands completed. Verify actual device and firewall status.'
else
 msg 'Partial restoration: GS BlackOut backup preserved for another attempt.'
fi
exit "$errors"
